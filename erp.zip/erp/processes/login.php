<?php
spl_autoload_register(function ($class) {
    $path = $_SERVER['DOCUMENT_ROOT']. '/erp/classes/';
    $extension = ".php";
    $fullpath = $path . $class . $extension;
    include_once $fullpath;
});
$admin = new admin_class();
$accountant = new accountants_class();
$instructor = new instructors_class();
$student = new students_class();
$parent = new parents_class();
$liberian = new liberians_class();
$role = $_POST["role"];
$login_id = $admin->Mysqli_Object->real_escape_string($_POST["login_id"]);
$password = $admin->Mysqli_Object->real_escape_string($_POST["password"]);
switch ($role) {
  case 'admin':

  $admin->Login($login_id,$password);
    break;
    case 'student':

    $student->Login($login_id,$password);
      break;
      case 'instructor':

    $instructor->Login($login_id,$password);
        break;
        case 'parent':
    $parent->Login($login_id,$password);
          break;
          case 'accountant':
    $accountant->Login($login_id,$password);
            break;
            case 'liberian':
    $liberian->Login($login_id,$password);
              break;
  default:
    # code...
    break;
}

?>

<?php
spl_autoload_register(function ($class) {
    $path = $_SERVER['DOCUMENT_ROOT']. '/erp/classes/';
    $extension = ".php";
    $fullpath = $path . $class . $extension;
    include_once $fullpath;
});
$invoice = new invoice_receipts_class();
$admission_id = $invoice->Mysqli_Object->real_escape_string($_POST["inv-id"]);
$type = $invoice->Mysqli_Object->real_escape_string($_POST["inv-type"]);
$amount = $invoice->Mysqli_Object->real_escape_string($_POST["inv-amount"]);
$session = $invoice->Mysqli_Object->real_escape_string($_POST["inv-session"]);
$term = $invoice->Mysqli_Object->real_escape_string($_POST["inv-term"]);
$class = $invoice->Mysqli_Object->real_escape_string($_POST["inv-class"]);
$created = date("Y-m-d");
$status = 0;
$n = explode("/",$session);
$na =$n[0];
$r = rand();
$invoice_no = "inv-".$na."-".$r;
if($admission_id == "multiple"){
$invoice->CreateMultipleInvoice($invoice_no,$type,$session,$term,$class,$admission_id,$created,$status,$amount);
}
else{
  $invoice->CreateInvoice($invoice_no,$type,$session,$term,$class,$admission_id,$created,$status,$amount);
}
?>

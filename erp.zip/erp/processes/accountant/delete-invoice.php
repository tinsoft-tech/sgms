<?php
spl_autoload_register(function ($class) {
    $path = $_SERVER['DOCUMENT_ROOT']. '/erp/classes/';
    $extension = ".php";
    $fullpath = $path . $class . $extension;
    include_once $fullpath;
});
$invoice = new invoice_receipts_class();
$id = $invoice->Mysqli_Object->real_escape_string($_POST["id"]);
$invoice->DeleteInvoice($id);
?>

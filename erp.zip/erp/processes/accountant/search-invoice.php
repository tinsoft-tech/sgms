<?php
spl_autoload_register(function ($class) {
    $path = $_SERVER['DOCUMENT_ROOT']. '/erp/classes/';
    $extension = ".php";
    $fullpath = $path . $class . $extension;
    include_once $fullpath;
});
$invoice = new invoice_receipts_class();
$class = $invoice->Mysqli_Object->real_escape_string($_POST["class"]);
$type = $invoice->Mysqli_Object->real_escape_string($_POST["invoice_type"]);
$session = $invoice->Mysqli_Object->real_escape_string($_POST["session"]);
$term = $invoice->Mysqli_Object->real_escape_string($_POST["term"]);
$status = $invoice->Mysqli_Object->real_escape_string($_POST["status"]);
$invoice->SearchInvoicesForAccountant($type,$class,$session,$term,$status);
?>

<?php
spl_autoload_register(function ($class) {
    $path = $_SERVER['DOCUMENT_ROOT']. '/erp/classes/';
    $extension = ".php";
    $fullpath = $path . $class . $extension;
    include_once $fullpath;
});
$exam = new ca_class();
$subject_name = $exam->Mysqli_Object->real_escape_string($_POST["subject_name"]);
$subject_combination = $exam->Mysqli_Object->real_escape_string($_POST["subject_combination"]);
$from = $exam->Mysqli_Object->real_escape_string($_POST["from"]);
$to = $exam->Mysqli_Object->real_escape_string($_POST["to"]);
$session = $exam->Mysqli_Object->real_escape_string($_POST["ca_session"]);
$class = $exam->Mysqli_Object->real_escape_string($_POST["ca_class"]);
$term = $exam->Mysqli_Object->real_escape_string($_POST["ca_term"]);
$date = $exam->Mysqli_Object->real_escape_string($_POST["date"]);
$duration = $exam->Mysqli_Object->real_escape_string($_POST["ca_duration"]);

$time = $from ."-".$to;
$exam->AddCaTest($subject_name,$subject_combination,$time,$class,$session,$term,$date,$duration);
?>

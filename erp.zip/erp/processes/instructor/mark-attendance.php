<?php
spl_autoload_register(function ($class) {
    $path = $_SERVER['DOCUMENT_ROOT']. '/erp/classes/';
    $extension = ".php";
    $fullpath = $path . $class . $extension;
    include_once $fullpath;
});
$attendance = new attendance_class();
$id = $attendance->Mysqli_Object->real_escape_string($_POST["id"]);
$attendance->MarkAttendanceByID($id);
?>

<?php
spl_autoload_register(function ($class) {
    $path = $_SERVER['DOCUMENT_ROOT']. '/erp/classes/';
    $extension = ".php";
    $fullpath = $path . $class . $extension;
    include_once $fullpath;
});
$attendance = new attendance_class();
$class = $attendance->Mysqli_Object->real_escape_string($_POST["class"]);
$session = $attendance->Mysqli_Object->real_escape_string($_POST["session"]);
$section = $attendance->Mysqli_Object->real_escape_string($_POST["section"]);
$date = $attendance->Mysqli_Object->real_escape_string($_POST["date"]);
$attendance->GenerateAttendance($class,$section,$date,$session);
?>

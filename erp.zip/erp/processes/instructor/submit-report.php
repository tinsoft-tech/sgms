<?php
spl_autoload_register(function ($class) {
    $path = $_SERVER['DOCUMENT_ROOT']. '/erp/classes/';
    $extension = ".php";
    $fullpath = $path . $class . $extension;
    include_once $fullpath;
});
$exam = new assignment_class();
$ass_id = $exam->Mysqli_Object->real_escape_string($_POST["id"]);
$admission_id = $exam->Mysqli_Object->real_escape_string($_POST["admission_id"]);
$score = $exam->Mysqli_Object->real_escape_string($_POST["score"]);
$session = $exam->Mysqli_Object->real_escape_string($_POST["session"]);
$subject = $exam->Mysqli_Object->real_escape_string($_POST["subject"]);
$total = $exam->Mysqli_Object->real_escape_string($_POST["total"]);
$type = $exam->Mysqli_Object->real_escape_string($_POST["type"]);
$term = $exam->Mysqli_Object->real_escape_string($_POST["term"]);

$exam->SubmitAssignmentReport($ass_id,$type,$subject,$admission_id,$session,$score,$total,$term)
?>

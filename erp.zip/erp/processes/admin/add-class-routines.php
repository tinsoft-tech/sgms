<?php
spl_autoload_register(function ($class) {
    $path = $_SERVER['DOCUMENT_ROOT']. '/erp/classes/';
    $extension = ".php";
    $fullpath = $path . $class . $extension;
    include_once $fullpath;
});
$class = new class_and_routine_class();
$class_name = $class->Mysqli_Object->real_escape_string($_POST["class_name"]);
$section = $class->Mysqli_Object->real_escape_string($_POST["section"]);
$subject = $class->Mysqli_Object->real_escape_string($_POST["subject"]);
$from = $class->Mysqli_Object->real_escape_string($_POST["from"]);
$to = $class->Mysqli_Object->real_escape_string($_POST["to"]);
$instructor = $class->Mysqli_Object->real_escape_string($_POST["instructor"]);
$date = $class->Mysqli_Object->real_escape_string($_POST["date"]);
$class->AddClassRoutine($class_name,$section,$from,$to,$subject,$instructor,$date);

?>

<?php
spl_autoload_register(function ($class) {
    $path = $_SERVER['DOCUMENT_ROOT']. '/erp/classes/';
    $extension = ".php";
    $fullpath = $path . $class . $extension;
    include_once $fullpath;
});
$valid_extensions = array('jpeg', 'jpg', 'png', 'gif', 'bmp'); // valid extensions
$imgpath = 'uploads/'; // upload directory
if(!empty($_FILES['image']))
{
$img = $_FILES['image']['name'];
$tmp = $_FILES['image']['tmp_name'];
// get uploaded file's extension
$ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
// can upload same image using rand function
$final_image = rand(1000,1000000).$img;
// check's valid format
//  $data = array();
if(in_array($ext, $valid_extensions))
{
$imgpath = $imgpath.strtolower($final_image);
if(move_uploaded_file($tmp,"../../".$imgpath))
{
  $accountants = new accountants_class();
  $firstname = $accountants->Mysqli_Object->real_escape_string($_POST["firstname"]);
  $middlename = $accountants->Mysqli_Object->real_escape_string($_POST["middlename"]);
  $lastname = $accountants->Mysqli_Object->real_escape_string($_POST["lastname"]);
  $email= $accountants->Mysqli_Object->real_escape_string($_POST["email"]);
  $passport = $imgpath;
  $bloodgroup = $accountants->Mysqli_Object->real_escape_string($_POST["bloodgroup"]);
  $address = $accountants->Mysqli_Object->real_escape_string($_POST["address"]);
  //$dob = $accountants->Mysqli_Object->real_escape_string($_POST["dob"]);
  //$occupation = $accountants->Mysqli_Object->real_escape_string($_POST["occupation"]);
  $employment_id = $accountants->Mysqli_Object->real_escape_string($_POST["employment_id"]);
  $phone = $accountants->Mysqli_Object->real_escape_string($_POST["phone"]);
  $religion = $accountants->Mysqli_Object->real_escape_string($_POST["religion"]);
  $gender = $accountants->Mysqli_Object->real_escape_string($_POST["gender"]);
  //$short_bio = $accountants->Mysqli_Object->real_escape_string($_POST["bio"]);
  $accountants->SignUp($firstname,$middlename,$lastname,$phone,$bloodgroup,$religion,$email,$address,$employment_id,$gender,$passport);

}
}
else
{
//  $data['message']= 'Error Processing Image';
//   $data['code']= 0;
}
//  echo json_encode($data);
}

?>

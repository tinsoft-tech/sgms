<?php
spl_autoload_register(function ($class) {
    $path = $_SERVER['DOCUMENT_ROOT']. '/erp/classes/';
    $extension = ".php";
    $fullpath = $path . $class . $extension;
    include_once $fullpath;
});
$instructor = new instructors_class();
$id = $instructor->Mysqli_Object->real_escape_string($_POST["id"]);
$firstname = $instructor->Mysqli_Object->real_escape_string($_POST["firstname"]);
$middlename = $instructor->Mysqli_Object->real_escape_string($_POST["middlename"]);
$lastname = $instructor->Mysqli_Object->real_escape_string($_POST["lastname"]);
$email= $instructor->Mysqli_Object->real_escape_string($_POST["email"]);
$bloodgroup = $instructor->Mysqli_Object->real_escape_string($_POST["bloodgroup"]);
$address = $instructor->Mysqli_Object->real_escape_string($_POST["address"]);
$dob = $instructor->Mysqli_Object->real_escape_string($_POST["dob"]);
$class = $instructor->Mysqli_Object->real_escape_string($_POST["class"]);
$phone = $instructor->Mysqli_Object->real_escape_string($_POST["phone"]);
$religion = $instructor->Mysqli_Object->real_escape_string($_POST["religion"]);
$gender = $instructor->Mysqli_Object->real_escape_string($_POST["gender"]);
$instructor->UpdateProfile($id,$firstname,$middlename,$lastname,$class,$phone,$bloodgroup,$religion,$email,$address,$gender,$dob);

?>

<?php
spl_autoload_register(function ($class) {
    $path = $_SERVER['DOCUMENT_ROOT']. '/erp/classes/';
    $extension = ".php";
    $fullpath = $path . $class . $extension;
    include_once $fullpath;
});
$exams = new exams_class();
  $id = $exams->Mysqli_Object->real_escape_string($_POST["id"]);

  switch ($id) {
    case '1':
    $key = $exams->Mysqli_Object->real_escape_string($_POST["searchkey"]);
    $subjects->ShowExams();
      break;
    case '2':
    $key = $exams->Mysqli_Object->real_escape_string($_POST["searchkey"]);
    $exams->ShowExamsbyClass($key);
        break;

        case '4':
        $key = $exams->Mysqli_Object->real_escape_string($_POST["studid"]);
        $exams->ShowExamById($key);
            break;
    default:
    $exams->ShowExams();
      break;
  }
?>

<?php
spl_autoload_register(function ($class) {
    $path = $_SERVER['DOCUMENT_ROOT']. '/erp/classes/';
    $extension = ".php";
    $fullpath = $path . $class . $extension;
    include_once $fullpath;
});
$liberians = new liberians_class();
$id = $liberians->Mysqli_Object->real_escape_string($_POST["id"]);
$firstname = $liberians->Mysqli_Object->real_escape_string($_POST["firstname"]);
$middlename = $liberians->Mysqli_Object->real_escape_string($_POST["middlename"]);
$lastname = $liberians->Mysqli_Object->real_escape_string($_POST["lastname"]);
$email= $liberians->Mysqli_Object->real_escape_string($_POST["email"]);
$bloodgroup = $liberians->Mysqli_Object->real_escape_string($_POST["bloodgroup"]);
$address = $liberians->Mysqli_Object->real_escape_string($_POST["address"]);
//$dob = $liberians->Mysqli_Object->real_escape_string($_POST["dob"]);
//$occupation = $liberians->Mysqli_Object->real_escape_string($_POST["occupation"]);
$phone = $liberians->Mysqli_Object->real_escape_string($_POST["phone"]);
$religion = $liberians->Mysqli_Object->real_escape_string($_POST["religion"]);
$gender = $liberians->Mysqli_Object->real_escape_string($_POST["gender"]);
$liberians->UpdateProfile($id,$firstname,$middlename,$lastname,$phone,$bloodgroup,$religion,$email,$address,$gender);

?>

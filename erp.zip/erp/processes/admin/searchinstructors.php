<?php
spl_autoload_register(function ($class) {
    $path = $_SERVER['DOCUMENT_ROOT']. '/erp/classes/';
    $extension = ".php";
    $fullpath = $path . $class . $extension;
    include_once $fullpath;
});
$instructor = new instructors_class();
  $id = $instructor->Mysqli_Object->real_escape_string($_POST["id"]);

  switch ($id) {
    case '1':
    $key = $instructor->Mysqli_Object->real_escape_string($_POST["searchkey"]);
    $instructor->ShowInstructorsbyLastName($key);
      break;
    case '2':
    $key = $instructor->Mysqli_Object->real_escape_string($_POST["searchkey"]);
    $instructor->ShowInstructorsbyClass($key);
        break;
    case '3':
    $key = $instructor->Mysqli_Object->real_escape_string($_POST["searchkey"]);
    $instructor->ShowInstructorsbyGender($key);
        break;
        case '4':
        $key = $instructor->Mysqli_Object->real_escape_string($_POST["studid"]);
        $instructor->ShowProfile($key);
            break;
    default:
    $instructor->ShowInstructors();
      break;
  }
?>

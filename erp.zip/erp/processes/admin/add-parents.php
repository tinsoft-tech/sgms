<?php
spl_autoload_register(function ($class) {
    $path = $_SERVER['DOCUMENT_ROOT']. '/erp/classes/';
    $extension = ".php";
    $fullpath = $path . $class . $extension;
    include_once $fullpath;
});
$valid_extensions = array('jpeg', 'jpg', 'png', 'gif', 'bmp'); // valid extensions
$imgpath = 'uploads/'; // upload directory
if(!empty($_FILES['image']))
{
$img = $_FILES['image']['name'];
$tmp = $_FILES['image']['tmp_name'];
// get uploaded file's extension
$ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
// can upload same image using rand function
$final_image = rand(1000,1000000).$img;
// check's valid format
//  $data = array();
if(in_array($ext, $valid_extensions))
{
$imgpath = $imgpath.strtolower($final_image);
if(move_uploaded_file($tmp,"../../".$imgpath))
{
  $parents = new parents_class();
  $firstname = $parents->Mysqli_Object->real_escape_string($_POST["firstname"]);
  $middlename = $parents->Mysqli_Object->real_escape_string($_POST["middlename"]);
  $lastname = $parents->Mysqli_Object->real_escape_string($_POST["lastname"]);
  $email= $parents->Mysqli_Object->real_escape_string($_POST["email"]);
  $passport = $imgpath;
  $bloodgroup = $parents->Mysqli_Object->real_escape_string($_POST["bloodgroup"]);
  $address = $parents->Mysqli_Object->real_escape_string($_POST["address"]);
  //$dob = $parents->Mysqli_Object->real_escape_string($_POST["dob"]);
  $occupation = $parents->Mysqli_Object->real_escape_string($_POST["occupation"]);
  //$admission_id = $parents->Mysqli_Object->real_escape_string($_POST["employment_id"]);
  $phone = $parents->Mysqli_Object->real_escape_string($_POST["phone"]);
  $religion = $parents->Mysqli_Object->real_escape_string($_POST["religion"]);
  $gender = $parents->Mysqli_Object->real_escape_string($_POST["gender"]);
  //$short_bio = $parents->Mysqli_Object->real_escape_string($_POST["bio"]);
  $parents->SignUp($firstname,$middlename,$lastname,$occupation,$phone,$bloodgroup,$religion,$email,$address,$gender,$passport);

}
}
else
{
//  $data['message']= 'Error Processing Image';
//   $data['code']= 0;
}
//  echo json_encode($data);
}

?>

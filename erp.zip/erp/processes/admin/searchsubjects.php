<?php
spl_autoload_register(function ($class) {
    $path = $_SERVER['DOCUMENT_ROOT']. '/erp/classes/';
    $extension = ".php";
    $fullpath = $path . $class . $extension;
    include_once $fullpath;
});
$subjects = new subjects_class();
  $id = $subjects->Mysqli_Object->real_escape_string($_POST["id"]);

  switch ($id) {
    case '1':
    $key = $subjects->Mysqli_Object->real_escape_string($_POST["searchkey"]);
    $subjects->ShowSubjectsbyName($key);
      break;
    case '2':
    $key = $subjects->Mysqli_Object->real_escape_string($_POST["searchkey"]);
    $subjects->ShowSubjectsbyClass($key);
        break;

        case '4':
        $key = $subjects->Mysqli_Object->real_escape_string($_POST["studid"]);
        $subjects->ShowId($key);
            break;
    default:
    $subjects->ShowSubjects();
      break;
  }
?>

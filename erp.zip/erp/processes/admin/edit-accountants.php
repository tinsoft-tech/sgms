<?php
spl_autoload_register(function ($class) {
    $path = $_SERVER['DOCUMENT_ROOT']. '/erp/classes/';
    $extension = ".php";
    $fullpath = $path . $class . $extension;
    include_once $fullpath;
});
$accountants = new accountants_class();
$id = $accountants->Mysqli_Object->real_escape_string($_POST["id"]);
$firstname = $accountants->Mysqli_Object->real_escape_string($_POST["firstname"]);
$middlename = $accountants->Mysqli_Object->real_escape_string($_POST["middlename"]);
$lastname = $accountants->Mysqli_Object->real_escape_string($_POST["lastname"]);
$email= $accountants->Mysqli_Object->real_escape_string($_POST["email"]);
$bloodgroup = $accountants->Mysqli_Object->real_escape_string($_POST["bloodgroup"]);
$address = $accountants->Mysqli_Object->real_escape_string($_POST["address"]);
//$dob = $accountants->Mysqli_Object->real_escape_string($_POST["dob"]);
//$occupation = $accountants->Mysqli_Object->real_escape_string($_POST["occupation"]);
$phone = $accountants->Mysqli_Object->real_escape_string($_POST["phone"]);
$religion = $accountants->Mysqli_Object->real_escape_string($_POST["religion"]);
$gender = $accountants->Mysqli_Object->real_escape_string($_POST["gender"]);
$accountants->UpdateProfile($id,$firstname,$middlename,$lastname,$phone,$bloodgroup,$religion,$email,$address,$gender);

?>

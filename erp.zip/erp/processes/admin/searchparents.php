<?php
spl_autoload_register(function ($class) {
    $path = $_SERVER['DOCUMENT_ROOT']. '/erp/classes/';
    $extension = ".php";
    $fullpath = $path . $class . $extension;
    include_once $fullpath;
});
$parents = new parents_class();
  $id = $parents->Mysqli_Object->real_escape_string($_POST["id"]);

  switch ($id) {
    case '1':
    $key = $parents->Mysqli_Object->real_escape_string($_POST["searchkey"]);
    $parents->ShowparentsbyLastName($key);
      break;
    case '2':
    $key = $parents->Mysqli_Object->real_escape_string($_POST["searchkey"]);
    $parents->ShowparentsbyClass($key);
        break;
    case '3':
    $key = $parents->Mysqli_Object->real_escape_string($_POST["searchkey"]);
    $parents->ShowparentsbyGender($key);
        break;
        case '4':
        $key = $parents->Mysqli_Object->real_escape_string($_POST["studid"]);
        $parents->ShowProfile($key);
            break;
    default:
    $parents->Showparents();
      break;
  }
?>

<?php
spl_autoload_register(function ($class) {
    $path = $_SERVER['DOCUMENT_ROOT']. '/erp/classes/';
    $extension = ".php";
    $fullpath = $path . $class . $extension;
    include_once $fullpath;
});
$class = new class_and_routine_class();
$id = $class->Mysqli_Object->real_escape_string($_POST["id"]);
$class->DeleteClassRoutine($id);

?>

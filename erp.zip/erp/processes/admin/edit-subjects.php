<?php
spl_autoload_register(function ($class) {
    $path = $_SERVER['DOCUMENT_ROOT']. '/erp/classes/';
    $extension = ".php";
    $fullpath = $path . $class . $extension;
    include_once $fullpath;
});
$subjects = new subjects_class();
$id = $subjects->Mysqli_Object->real_escape_string($_POST["id"]);
$subjectname = $subjects->Mysqli_Object->real_escape_string($_POST["subjectname"]);
$subjectlevel = $subjects->Mysqli_Object->real_escape_string($_POST["subjectlevel"]);
$subjects->UpdateSubject($id,$subjectname,$subjectlevel);

?>

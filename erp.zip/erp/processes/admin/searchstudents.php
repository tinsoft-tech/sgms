<?php
spl_autoload_register(function ($class) {
    $path = $_SERVER['DOCUMENT_ROOT']. '/erp/classes/';
    $extension = ".php";
    $fullpath = $path . $class . $extension;
    include_once $fullpath;
});
$student = new students_class();
  $id = $student->Mysqli_Object->real_escape_string($_POST["id"]);

  switch ($id) {
    case '1':
    $key = $student->Mysqli_Object->real_escape_string($_POST["searchkey"]);
    $student->ShowStudentsbyLastName($key);
      break;
    case '2':
    $key = $student->Mysqli_Object->real_escape_string($_POST["searchkey"]);
    $student->ShowStudentsbyClass($key);
        break;
    case '3':
    $key = $student->Mysqli_Object->real_escape_string($_POST["searchkey"]);
    $student->ShowStudentsbyGender($key);
        break;
        case '4':
        $key = $student->Mysqli_Object->real_escape_string($_POST["studid"]);
        $student->ShowProfile($key);
            break;
    default:
    $student->ShowStudents();
      break;
  }
?>

<?php
spl_autoload_register(function ($exam) {
    $path = $_SERVER['DOCUMENT_ROOT']. '/erp/classes/';
    $extension = ".php";
    $fullpath = $path . $exam . $extension;
    include_once $fullpath;
});
$exam = new exams_class();
$id = $exam->Mysqli_Object->real_escape_string($_POST["id"]);
$subject = $exam->Mysqli_Object->real_escape_string($_POST["subject"]);
$time = $exam->Mysqli_Object->real_escape_string($_POST["time"]);
$class = $exam->Mysqli_Object->real_escape_string($_POST["classname"]);
$session = $exam->Mysqli_Object->real_escape_string($_POST["session"]);
$term = $exam->Mysqli_Object->real_escape_string($_POST["term"]);
$date = $exam->Mysqli_Object->real_escape_string($_POST["date"]);
$exam->UpdateExam($id,$subject,$time,$class,$session,$term,$date);

?>

<?php
spl_autoload_register(function ($class) {
    $path = $_SERVER['DOCUMENT_ROOT']. '/erp/classes/';
    $extension = ".php";
    $fullpath = $path . $class . $extension;
    include_once $fullpath;
});
$acountants = new accountants_class();
  $id = $acountants->Mysqli_Object->real_escape_string($_POST["id"]);

  switch ($id) {
    case '1':
    $key = $acountants->Mysqli_Object->real_escape_string($_POST["searchkey"]);
    $acountants->ShowAcountantsbyLastName($key);
      break;
    case '2':
    $key = $acountants->Mysqli_Object->real_escape_string($_POST["searchkey"]);
    $acountants->ShowAcountantsbyClass($key);
        break;
    case '3':
    $key = $acountants->Mysqli_Object->real_escape_string($_POST["searchkey"]);
    $acountants->ShowAcountantsbyGender($key);
        break;
        case '4':
        $key = $acountants->Mysqli_Object->real_escape_string($_POST["studid"]);
        $acountants->ShowProfile($key);
            break;
    default:
    $acountants->ShowAcountants();
      break;
  }
?>

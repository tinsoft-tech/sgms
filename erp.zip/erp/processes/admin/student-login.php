<?php
spl_autoload_register(function ($class) {
    $path = $_SERVER['DOCUMENT_ROOT']. '/erp/classes/';
    $extension = ".php";
    $fullpath = $path . $class . $extension;
    include_once $fullpath;
});
$student = new Student_Class();
$login_id = $staff->Mysqli_Object->real_escape_string($_POST["email"]);
$password = $staff->Mysqli_Object->real_escape_string($_POST["admission_id"]);
$student->Login($login_id,$password);
//$staff->SetPwd();

?>

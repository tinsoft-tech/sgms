<?php
spl_autoload_register(function ($class) {
    $path = $_SERVER['DOCUMENT_ROOT']. '/erp/classes/';
    $extension = ".php";
    $fullpath = $path . $class . $extension;
    include_once $fullpath;
});
$liberians = new liberians_class();
  $id = $liberians->Mysqli_Object->real_escape_string($_POST["id"]);

  switch ($id) {
    case '1':
    $key = $liberians->Mysqli_Object->real_escape_string($_POST["searchkey"]);
    $liberians->ShowLiberiansbyLastName($key);
      break;
    case '2':
    $key = $liberians->Mysqli_Object->real_escape_string($_POST["searchkey"]);
    $liberians->ShowliberiansbyClass($key);
        break;
    case '3':
    $key = $liberians->Mysqli_Object->real_escape_string($_POST["searchkey"]);
    $liberians->ShowLiberiansbyGender($key);
        break;
        case '4':
        $key = $liberians->Mysqli_Object->real_escape_string($_POST["studid"]);
        $liberians->ShowProfile($key);
            break;
    default:
    $liberians->ShowLiberians();
      break;
  }
?>

<?php
spl_autoload_register(function ($exam) {
    $path = $_SERVER['DOCUMENT_ROOT']. '/erp/classes/';
    $extension = ".php";
    $fullpath = $path . $exam . $extension;
    include_once $fullpath;
});
$exam = new exams_class();
$subject = $exam->Mysqli_Object->real_escape_string($_POST["subject"]);
$from = $exam->Mysqli_Object->real_escape_string($_POST["from"]);
$to = $exam->Mysqli_Object->real_escape_string($_POST["to"]);
$class = $exam->Mysqli_Object->real_escape_string($_POST["classname"]);
$session = $exam->Mysqli_Object->real_escape_string($_POST["session"]);
$term = $exam->Mysqli_Object->real_escape_string($_POST["term"]);
$date = $exam->Mysqli_Object->real_escape_string($_POST["date"]);
$time = $from."-".$to;
$exam->AddExam($subject,$time,$class,$session,$term,$date);

?>

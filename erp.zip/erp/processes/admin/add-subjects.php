<?php
spl_autoload_register(function ($class) {
    $path = $_SERVER['DOCUMENT_ROOT']. '/erp/classes/';
    $extension = ".php";
    $fullpath = $path . $class . $extension;
    include_once $fullpath;
});
$subject = new subjects_class();
$subjectname = $instructor->Mysqli_Object->real_escape_string($_POST["subjectname"]);
$subjectlevel = $instructor->Mysqli_Object->real_escape_string($_POST["subjectlevel"]);
$subject->AddSubject($subjectname,$subjectlevel);

?>

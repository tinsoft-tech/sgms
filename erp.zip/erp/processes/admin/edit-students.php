<?php
spl_autoload_register(function ($class) {
    $path = $_SERVER['DOCUMENT_ROOT']. '/erp/classes/';
    $extension = ".php";
    $fullpath = $path . $class . $extension;
    include_once $fullpath;
});
$student = new students_class();
$id = $student->Mysqli_Object->real_escape_string($_POST["id"]);
$firstname = $student->Mysqli_Object->real_escape_string($_POST["firstname"]);
$middlename = $student->Mysqli_Object->real_escape_string($_POST["middlename"]);
$lastname = $student->Mysqli_Object->real_escape_string($_POST["lastname"]);
$email= $student->Mysqli_Object->real_escape_string($_POST["email"]);
$bloodgroup = $student->Mysqli_Object->real_escape_string($_POST["bloodgroup"]);
$address = $student->Mysqli_Object->real_escape_string($_POST["address"]);
$dob = $student->Mysqli_Object->real_escape_string($_POST["dob"]);
$class = $student->Mysqli_Object->real_escape_string($_POST["class"]);
$phone = $student->Mysqli_Object->real_escape_string($_POST["phone"]);
$religion = $student->Mysqli_Object->real_escape_string($_POST["religion"]);
$gender = $student->Mysqli_Object->real_escape_string($_POST["gender"]);
$student->UpdateProfile($id,$firstname,$middlename,$lastname,$class,$phone,$bloodgroup,$religion,$email,$address,$gender,$dob);

?>

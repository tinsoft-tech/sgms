<?php
spl_autoload_register(function ($class) {
    $path = $_SERVER['DOCUMENT_ROOT']. '/erp/classes/';
    $extension = ".php";
    $fullpath = $path . $class . $extension;
    include_once $fullpath;
});
$parents = new parents_class();
$id = $parents->Mysqli_Object->real_escape_string($_POST["id"]);
$firstname = $parents->Mysqli_Object->real_escape_string($_POST["firstname"]);
$middlename = $parents->Mysqli_Object->real_escape_string($_POST["middlename"]);
$lastname = $parents->Mysqli_Object->real_escape_string($_POST["lastname"]);
$email= $parents->Mysqli_Object->real_escape_string($_POST["email"]);
$bloodgroup = $parents->Mysqli_Object->real_escape_string($_POST["bloodgroup"]);
$address = $parents->Mysqli_Object->real_escape_string($_POST["address"]);
//$dob = $parents->Mysqli_Object->real_escape_string($_POST["dob"]);
$occupation = $parents->Mysqli_Object->real_escape_string($_POST["occupation"]);
$phone = $parents->Mysqli_Object->real_escape_string($_POST["phone"]);
$religion = $parents->Mysqli_Object->real_escape_string($_POST["religion"]);
$gender = $parents->Mysqli_Object->real_escape_string($_POST["gender"]);
$parents->UpdateProfile($id,$firstname,$middlename,$lastname,$occupation,$phone,$bloodgroup,$religion,$email,$address,$gender);

?>

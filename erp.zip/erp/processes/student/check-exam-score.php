<?php
spl_autoload_register(function ($class) {
    $path = $_SERVER['DOCUMENT_ROOT']. '/erp/classes/';
    $extension = ".php";
    $fullpath = $path . $class . $extension;
    include_once $fullpath;
});
$exam = new exams_class();
$exam_id = $exam->Mysqli_Object->real_escape_string($_POST["exam_id"]);
$admission_id = $exam->Mysqli_Object->real_escape_string($_POST["admission_id"]);
$num = $exam->Mysqli_Object->real_escape_string($_POST["num"]);
$exam->ShowExamScore($exam_id,$admission_id,$num);
?>

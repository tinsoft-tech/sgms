<?php
spl_autoload_register(function ($class) {
    $path = $_SERVER['DOCUMENT_ROOT']. '/erp/classes/';
    $extension = ".php";
    $fullpath = $path . $class . $extension;
    include_once $fullpath;
});
$assignment = new assignment_class();
$id = $assignment->Mysqli_Object->real_escape_string($_POST["id"]);
$assignment->DeleteSubmittedAssignment($id);
?>

<!-- Sidenav -->
<nav class="sidenav navbar navbar-vertical  fixed-left  navbar-expand-xs navbar-light bg-white" id="sidenav-main">
   <div class="scrollbar-inner">
     <!-- Brand -->
     <div class="sidenav-header  align-items-center">
    <img src="../../assets/img/student2.png" style="margin-top:40px;"  />
     </div>
     <div class="navbar-inner">
       <!-- Collapse -->
       <div class="collapse navbar-collapse" id="sidenav-collapse-main">
         <!-- Nav items -->
         <ul class="navbar-nav">
           <li class="nav-item" style="display:none;">
             <a class="nav-link active" href="index.php">
               <i class="ni ni-tv-2 text-dark"></i>
               <span class="nav-link-text">Dashboard</span>
             </a>
           </li>
           <li class="nav-item">
             <a class="nav-link"  href="index.php">
               <i class="ni ni-circle-08 text-dark"></i>
               <span class="nav-link-text">My Profile</span>
             </a>
           </li>
           <li class="nav-item">
             <a class="nav-link" href="attendance.php">
               <i class="ni ni-check-bold text-dark"></i>
               <span class="nav-link-text">Attendance</span>
             </a>
           </li>
           <li class="nav-item">
             <a class="nav-link"  href="assignments.php">
               <i class="ni ni-badge text-dark"></i>
               <span class="nav-link-text">Assignments</span>
             </a>

           </li>
           <li class="nav-item">
             <a class="nav-link"  href="tests.php">
               <i class="ni ni-paper-diploma text-dark"></i>
               <span class="nav-link-text">C A Test</span>
             </a>

           </li>
           <li class="nav-item">
             <a class="nav-link" href="exams.php">
               <i class="ni ni-paper-diploma text-dark"></i>
               <span class="nav-link-text">Exams</span>
             </a>

           </li>

           <li class="nav-item">
             <a class="nav-link"  href="reports.php">
               <i class="ni ni-single-copy-04 text-dark"></i>
               <span class="nav-link-text">Reports</span>
             </a>

           </li>
           

         </ul>
         <!-- Divider -->
         <hr class="my-3">

       </div>
     </div>
   </div>
 </nav>

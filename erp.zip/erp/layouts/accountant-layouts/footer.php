 <!-- Footer -->
      <footer class="footer pt-0">
        <div class="row align-items-center justify-content-lg-between">
          <div class="col-lg-6">

          </div>
          <div class="col-lg-6">

          </div>
        </div>
      </footer>
  <!-- Argon Scripts -->
  <!-- Core -->

  <script src="../../assets/vendor/jquery/dist/jquery.min.js"></script>
  <script src="../../assets/js/students.js"></script>
  <script src="../../assets/js/assignments.js"></script>
    <script src="../../assets/js/parents.js"></script>
  <script src="../../assets/js/liberians.js"></script>
  <script src="../../assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <script src="../../assets/vendor/js-cookie/js.cookie.js"></script>
  <script src="../../assets/vendor/jquery.scrollbar/jquery.scrollbar.min.js"></script>
  <script src="../../assets/vendor/jquery-scroll-lock/dist/jquery-scrollLock.min.js"></script>
  <!--
  <script src="../../assets/vendor/chart.js/dist/Chart.min.js"></script>
  <script src="../../assets/vendor/chart.js/dist/Chart.extension.js"></script>
-->
  <!-- Argon JS -->
  <script src="../../assets/js/argon.min.js?v=1.2.0"></script>

  <script>
      $(document).ready(function(){
       $("#student-link").click(function(){
        $("#sub-student-menu").toggle();
      });
      $("#instructor-link").click(function(){
       $("#sub-instructor-menu").toggle();
     });
     $("#parent-link").click(function(){
      $("#sub-parent-menu").toggle();
    });
    $("#accountant-link").click(function(){
     $("#sub-accountant-menu").toggle();
   });
   $("#liberian-link").click(function(){
    $("#sub-liberian-menu").toggle();
  });
   $("#subject-link").click(function(){
    $("#sub-subject-menu").toggle();
  });
  $("#class-link").click(function(){
   $("#sub-class-menu").toggle();
 });
 $("#exam-link").click(function(){
  $("#sub-exam-menu").toggle();
});
$("#message-link").click(function(){
 $("#sub-message-menu").toggle();
});









      });

</script>


</body>

</html>

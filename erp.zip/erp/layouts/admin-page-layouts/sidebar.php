 <!-- Sidenav -->
 <nav class="sidenav navbar navbar-vertical  fixed-left  navbar-expand-xs navbar-light bg-white" id="sidenav-main">
    <div class="scrollbar-inner">
      <!-- Brand -->
      <div class="sidenav-header  align-items-center">
          <img src="../../assets/img/student2.png" style="margin-top:40px;"  />

      </div>
      <div class="navbar-inner">
        <!-- Collapse -->
        <div class="collapse navbar-collapse" id="sidenav-collapse-main">
          <!-- Nav items -->
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link active" href="index.php">
                <i class="ni ni-tv-2 text-dark"></i>
                <span class="nav-link-text">Dashboard</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" id="student-link" href="#">
                <i class="ni ni-circle-08 text-dark"></i>
                <span class="nav-link-text">Students</span>
              </a>
              <ul class="nav sub-group-menu" style="display:none;" id="sub-student-menu">
                                <li class="nav-item">
                                    <a href="all-students.php" class="nav-link"> <i class="ni ni-bold-right"></i>All
                                        Students</a>
                                </li>
                              <!--  <li class="nav-item">
                                    <a href="student-details.html" class="nav-link"><i class="ni ni-bold-right"></i>Student Details</a>
                                </li> -->
                                <li class="nav-item">
                                    <a href="add-new-student.php" class="nav-link"><i class="ni ni-bold-right"></i>Admission Form</a>
                                </li>
                              <!--  <li class="nav-item">
                                    <a href="student-promotion.html" class="nav-link"><i class="ni ni-bold-right"></i>Student Promotion</a>
                                </li> -->
             </ul>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#" id="instructor-link">
                <i class="ni ni-circle-08 text-dark"></i>
                <span class="nav-link-text">Instructors</span>
              </a>
              <ul class="nav sub-group-menu" style="display:none;" id="sub-instructor-menu">
                                <li class="nav-item">
                                    <a href="all-instructors.php" class="nav-link"> <i class="ni ni-bold-right"></i>All
                                        Instructors</a>
                                </li>
                                <!--<li class="nav-item">
                                    <a href="student-details.html" class="nav-link"><i class="ni ni-bold-right"></i>Student Details</a>
                                </li> -->
                                <li class="nav-item">
                                    <a href="add-instructors.php" class="nav-link"><i class="ni ni-bold-right"></i>Add Instructor</a>
                                </li>

             </ul>
            </li>
            <li class="nav-item">
              <a class="nav-link" id="parent-link" href="#">
                <i class="ni ni-single-02 text-dark"></i>
                <span class="nav-link-text">Parents</span>
              </a>
              <ul class="nav sub-group-menu" style="display:none;" id="sub-parent-menu">
                                <li class="nav-item">
                                    <a href="all-parents.php" class="nav-link"> <i class="ni ni-bold-right"></i>All
                                        Parents</a>
                                </li>

                                <li class="nav-item">
                                    <a href="add-parent.php" class="nav-link"><i class="ni ni-bold-right"></i>Add Parent</a>
                                </li>
                                <li class="nav-item">
                                    <a href="assign-children.php" class="nav-link"><i class="ni ni-bold-right"></i>Assign Children</a>
                                </li>

             </ul>
            </li>
            <li class="nav-item">
              <a class="nav-link" id="accountant-link" href="#">
                <i class="ni ni-money-coins text-dark"></i>
                <span class="nav-link-text">Accountants</span>
              </a>
              <ul class="nav sub-group-menu" style="display:none;" id="sub-accountant-menu">
                                <li class="nav-item">
                                    <a href="all-accountants.php" class="nav-link"> <i class="ni ni-bold-right"></i>All
                                        Accountant</a>
                                </li>

                                <li class="nav-item">
                                    <a href="add-accountant.php" class="nav-link"><i class="ni ni-bold-right"></i>Add Accountant</a>
                                </li>

             </ul>
            </li>
            <li class="nav-item">
              <a class="nav-link" id="liberian-link" href="#">
                <i class="ni ni-box-2 text-dark"></i>
                <span class="nav-link-text">Liberians</span>
              </a>
              <ul class="nav sub-group-menu" style="display:none;" id="sub-liberian-menu">
                                <li class="nav-item">
                                    <a href="all-liberians.php" class="nav-link"> <i class="ni ni-bold-right"></i>All
                                        Liberians</a>
                                </li>

                                <li class="nav-item">
                                    <a href="add-liberian.php" class="nav-link"><i class="ni ni-bold-right"></i>Add Liberians</a>
                                </li>

             </ul>
            </li>
            <li class="nav-item">
              <a class="nav-link" id="subject-link" href="#">
                <i class="ni ni-single-copy-04 text-dark"></i>
                <span class="nav-link-text">Subjects</span>
              </a>
              <ul class="nav sub-group-menu" style="display:none;" id="sub-subject-menu">
                                <li class="nav-item">
                                    <a href="all-subjects.php" class="nav-link"> <i class="ni ni-bold-right"></i>All
                                        Subject</a>
                                </li>

                                <li class="nav-item">
                                    <a href="add-subject.php" class="nav-link"><i class="ni ni-bold-right"></i>Add Subject</a>
                                </li>

             </ul>
            </li>
            <li class="nav-item">
              <a class="nav-link" id="class-link" href="#">
                <i class="ni ni-calendar-grid-58 text-dark"></i>
                <span class="nav-link-text">Classes</span>
              </a>
              <ul class="nav sub-group-menu" style="display:none;" id="sub-class-menu">
                                <li class="nav-item">
                                    <a href="all-class-routine.php" class="nav-link"> <i class="ni ni-bold-right"></i>All
                                       Class Routines</a>
                                </li>

                                <li class="nav-item">
                                    <a href="add-class-routine.php" class="nav-link"><i class="ni ni-bold-right"></i>Add Class Routine</a>
                                </li>

             </ul>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#" id="exam-link">
                <i class="ni ni-ruler-pencil text-dark"></i>
                <span class="nav-link-text">Exams</span>
              </a>
              <ul class="nav sub-group-menu" style="display:none;" id="sub-exam-menu">
                                <li class="nav-item">
                                    <a href="all-exams.php" class="nav-link"> <i class="ni ni-bold-right"></i>All
                                        Exams</a>
                                </li>

                                <li class="nav-item">
                                    <a href="add-exam.php" class="nav-link"><i class="ni ni-bold-right"></i>Add Exam</a>
                                </li>

             </ul>
            </li>
            <li style="display:none;" class="nav-item">
              <a class="nav-link" href="#" id="message-link">
                <i class="ni ni-send text-dark"></i>
                <span class="nav-link-text">Message</span>
              </a>
              <ul class="nav sub-group-menu" style="display:none;" id="sub-message-menu">
                                <li class="nav-item">
                                    <a href="all-messages.php" class="nav-link"> <i class="ni ni-bold-right"></i>All
                                  Messages</a>
                                </li>

                                <li class="nav-item">
                                    <a href="add-messages.php" class="nav-link"><i class="ni ni-bold-right"></i>Add Message</a>
                                </li>

             </ul>
            </li>
          </ul>
          <!-- Divider -->
          <hr class="my-3">

        </div>
      </div>
    </div>
  </nav>

<?php
define('SERVER', "localhost");
define('USER', "root");
define('PASSWORD', "@Hidemyass2");
define('SCHOOL_DATABASE', "school_erp");
/*define('NISRN_DATABASE', "db_nisrn");
define('IT_DATABASE', "db_it");
define('LEAVE_DATABASE', "db_leave");
define('STAFF_DATABASE', "db_user");
define('HR_DATABASE', "db_hr");
define('HELPERS_DATABASE', "db_helpers");
define('TIMESHEET_DATABASE', "db_timesheet");
//define('FINANCE_DATABASE', "db_finance");
*/

?>

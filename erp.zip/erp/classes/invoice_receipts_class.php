<?php
$config = $_SERVER['DOCUMENT_ROOT']. '/erp/config/config.php';

//require_once "Mysqli_Class.php";
require_once $config;
spl_autoload_register(function ($class) {
    $path = "classes/";
    $extension = ".php";
    $fullpath = $class . $extension;
    include_once $fullpath;
});


class invoice_receipts_class{
public $Mysqli_Object;
public function __construct(){
    $instanceconnection = new mysqli_class(SERVER,USER,PASSWORD,SCHOOL_DATABASE);
    $instanceconnection->OpenConnection();
    $this->Mysqli_Object =$instanceconnection->obj;
}

public function CreateMultipleInvoice($invoice_no,$type,$session,$term,$class,$admission_id,$created,$status,$amount){
  $sql = "SELECT * FROM students WHERE class = '$class'";
  $result = $this->Mysqli_Object->query($sql);
    $muldata = array();
//  $row = $result->fetch_assoc();
  if ($result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
    $admission_id = $row["admission_id"];

      $this->CreateInvoice($invoice_no,$type,$session,$term,$class,$admission_id,$created,$status,$amount);
  }

   $muldata['message']= 'Created Successfully';
   $muldata['code']= 1;
  }
  echo json_encode($muldata);
}
public function randomNumber($length){
  $res = 0;
  for ($i=0; $i < $length; $i++) {
    $res .= mt_rand(0,9);
  }
  return $res;
}
public function CreateInvoice($invoice_no,$type,$session,$term,$class,$admission_id,$created,$status,$amount){
    $sql = "SELECT * FROM invoices WHERE  invoice_no ='$invoice_no' AND invoice_type='$type' AND admission_id='$admission_id' and term='$term' and session ='$session'";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    $data = array();
    if($invoice_no == "" || $type == "" ||$admission_id == ""  ||$term == "" ||$class == "" ||
       $session == "" ||$created == ""
    )
    {
      $data['message']= 'Some fields are empty please correct and resubmit';
       $data['code']= 0;
    }
  else if ($result->num_rows == 1) {

  $data['message']= 'Duplicate Entry Found';
   $data['code']= 0;
    }
    else{
      $n = explode("/",$session);
      $na =$n[0];
      $res = 0;
      for ($i=0; $i < 8; $i++) {
        $res .= mt_rand(0,9);
      }
      $r = $res;
      $invoice_no = "inv-".$na."-".$r;
      $newsql = "INSERT INTO invoices(`id`, `invoice_no`, `invoice_type`,`amount`, `session`, `term`, `class`, `admission_id`, `created`,`status`)
      VALUES(NULL,'$invoice_no','$type','$amount','$session','$term','$class','$admission_id','$created','$status')";
      if($resulty = $this->Mysqli_Object->query($newsql))
      {
          $data['message']= 'Created Successfully';
           $data['code']= 1;
      }
      else{
          $data['message']= 'An Error has Occured';
          $data['code']= 0;
      }
    }
        echo json_encode($data);
}

public function CreateReceipt($id,$reference){
    $sql = "SELECT * FROM invoices WHERE  id ='$id' ";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    $data = array();
    if ($result->num_rows == 1) {
      $type = $row["invoice_type"];
      $invoice_no = $row["invoice_no"];
      $amount = $row["amount"];
      $session = $row["session"];
      $admission_id = $row["admission_id"];
      $term = $row["term"];
      $newsql = "INSERT INTO receipts(`id`,`reference_no`, `invoice_no`, `invoice_type`,`amount`, `session`, `term`,`admission_id`, `created`)
      VALUES(NULL,'$reference','$invoice_no','$type','$amount','$session','$term','$admission_id',CURDATE())";
      if($resulty = $this->Mysqli_Object->query($newsql))
      {
          $data['message']= 'Created Successfully';
           $data['code']= 1;
      }
      else{
          $data['message']= 'An Error has Occured';
          $data['code']= 0;
      }

    }
    else{
      $data['message']= 'No Entry Found';
       $data['code']= 0;

    }
        echo json_encode($data);
}
public function UpdateInvoice($id){
  $sql = "UPDATE  invoices SET status = 1 where id='$id'";
  $result = $this->Mysqli_Object->query($sql);
}
public function DeleteInvoice($id){
  $sql = "DELETE FROM  invoices where id='$id'";
    $data = array();
    if($result = $this->Mysqli_Object->query($sql)){
      $data['message']='Deleted Successfully';
      $data['code'] = 1;
    }
    else{
      $data['message']='An Error has Occured';
      $data['code'] = 0;
    }

}
public function ShowAllInvoices(){
    $sql = "SELECT * FROM invoices";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      require '../../components/invoices/show-invoices-component.php';
    }


    }
}

public function ShowAllInvoicesForAccountant(){
    $sql = "SELECT * FROM invoices";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      require '../../components/invoices/show-full-invoices-component.php';
    }


    }
}

public function SearchInvoicesForAccountant($type,$class,$session,$term,$status){
    $sql = "SELECT * FROM invoices where id > 0";
    if($class != "n/a"){
       $sql .= " AND `class`='$class'";
    }
    if($type != "n/a"){
       $sql .= " AND `invoice_type`='$type'";
    }
    if($session != "n/a"){
       $sql .= " AND `session`='$session'";
    }
    if($term != "n/a"){
       $sql .= " AND `term`='$term'";
    }
    if($status != "n/a"){
       $sql .= " AND `status`='$status'";
    }
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      require '../../components/invoices/show-full-invoices-component.php';
    }


    }
}


public function ShowAllInvoicesForAccountantByClass($class){
    $sql = "SELECT * FROM invoices where class ='$class'";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      require '../../components/invoices/show-full-invoices-component.php';
    }


    }
}
public function ShowInvoiceByAdm($admission_id){
    $sql = "SELECT * FROM invoices where admission_id ='$admission_id'";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      require '../../components/invoices/show-invoices-component.php';
    }


    }
}

public function ShowReceiptByAdm($admission_id){
    $sql = "SELECT * FROM receipts where admission_id ='$admission_id'";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      require '../../components/receipts/show-receipts-component.php';
    }


    }
}
public function ShowAllReceipt(){
    $sql = "SELECT * FROM receipts ";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      require '../../components/receipts/show-receipts-component.php';
    }


    }
}
}
?>

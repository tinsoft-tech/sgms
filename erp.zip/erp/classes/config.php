<?php
require_once 'vendor/autoload.php';
require_once "zoom_api_class.php";

define('CLIENT_ID', 'uZyNp7tVT9ml8xmoWiYxMA');
define('CLIENT_SECRET', 'C8W69XLd6hWchlMzzx6o5537eGSHZQH9');
define('REDIRECT_URI', 'https://092a1f7ff23f.ngrok.io/school-erp/callback.php');

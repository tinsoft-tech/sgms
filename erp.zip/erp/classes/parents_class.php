<?php
$config = $_SERVER['DOCUMENT_ROOT']. '/erp/config/config.php';

//require_once "Mysqli_Class.php";
require_once $config;
spl_autoload_register(function ($class) {
    $path = "classes/";
    $extension = ".php";
    $fullpath = $class . $extension;
    include_once $fullpath;
});


class parents_class extends invoice_receipts_class{
public $Mysqli_Object;
public function __construct(){
    $instanceconnection = new mysqli_class(SERVER,USER,PASSWORD,SCHOOL_DATABASE);
    $instanceconnection->OpenConnection();
    $this->Mysqli_Object =$instanceconnection->obj;
}


public function SignUp($firstname,$middlename,$lastname,$occupation,$phone,$blood_group,$religion,$email,$address,$gender,$passport){
    $sql = "SELECT * FROM parents WHERE  firstname ='$firstname' AND middlename='$middlename' AND lastname='$lastname'";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    $data = array();
    if($firstname == "" || $middlename == "" ||$lastname == ""  ||$blood_group == "" ||$religion == "" ||
       $email == "" ||$address == "" ||$gender == ""
    )
    {
      $data['message']= 'Some fields are empty please correct and resubmit';
       $data['code']= 0;
    }
  else if ($result->num_rows == 1) {

  $data['message']= 'Duplicate Entry Found';
   $data['code']= 0;
    }
    else{
      $id =  $row["id"];


      $newsql = "INSERT INTO parents(`id`, `firstname`, `middlename`, `lastname`, `email`, `passport`, `bloodgroup`, `address`, `occupation`, `phone`, `religion`, `gender`)
      VALUES(NULL,'$firstname','$middlename','$lastname','$email','$passport','$blood_group','$address','$occupation','$phone','$religion','$gender')";
      if($resulty = $this->Mysqli_Object->query($newsql))
      {
          $data['message']= 'Registered Successfully';
           $data['code']= 1;
      }
      else{
          $data['message']= 'An Error has Occured';
          $data['code']= 0;
      }
    }
        echo json_encode($data);
}

public function UpdateProfile($id,$firstname,$middlename,$lastname,$occupation,$phone,$bloodgroup,$religion,$email,$address,$gender){
  $data = array();
  $newsql = "UPDATE parents SET firstname ='$firstname', middlename ='$middlename' , lastname ='$lastname' , email ='$email' , bloodgroup ='$bloodgroup' , address ='$address' , occupation ='$occupation'
,   phone ='$phone', religion ='$religion', gender ='$gender' WHERE id = '$id'";
  if($resulty = $this->Mysqli_Object->query($newsql))
  {
      $data['message']= 'Updated Successfully';
       $data['code']= 1;
  }
  else{
      $data['message']= 'An Error has Occured';
      $data['code']= 0;
  }
    echo json_encode($data);
}

public function DeleteProfile($id){
  $data = array();
  $newsql = "DELETE from parents WHERE id = '$id'";
  if($resulty = $this->Mysqli_Object->query($newsql))
  {
      $data['message']= 'Deleted Successfully';
       $data['code']= 1;
  }
  else{
      $data['message']= 'An Error has Occured';
      $data['code']= 0;
  }
    echo json_encode($data);
}
public function ShowPassport($email){
    $sql = "SELECT * FROM staffs WHERE email='$email'";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    if ($result->num_rows == 1) {

        $fullname =  $row["passport"];
        return $fullname;
    }
}
public function ShowCount(){
    $sql = "SELECT COUNT(*) as count FROM parents ";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {

        $count =  $row["count"];
        return $count;
    }
}
public function UpdatePassport($employment_id,$url){
    $sql = "SELECT * FROM parents WHERE employment_id='$employment_id'";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    if ($result->num_rows == 1) {

        $id =  $row["id"];
        $data = array();

        $newsql = "UPDATE parents SET passport ='$url' where id = '$id'";
        if($resulty = $this->Mysqli_Object->query($newsql))
        {
            $data['message']= 'Uploaded Successfully';
        }
        else{
            $data['message']= 'An Error has Occured';
        }

    }
}
public function ShowParents(){
    $sql = "SELECT * FROM parents ORDER BY id desc";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $fullname =  $row["lastname"]." ". $row["firstname"]." ". $row["middlename"];
        require '../../components/parents/show-parents-component.php';
    }


    }
}
public function ShowparentsbyLastName($lname){
    $sql = "SELECT * FROM parents WHERE lastname LIKE'$lname%' ORDER BY id desc";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $fullname =  $row["lastname"]." ". $row["firstname"]." ". $row["middlename"];
        require '../../components/parents/show-parents-component.php';
    }


    }
}
public function ShowparentsbyClass($cname){
    $sql = "SELECT * FROM parents WHERE class = '$cname' ORDER BY id desc";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $fullname =  $row["lastname"]." ". $row["firstname"]." ". $row["middlename"];
        require '../../components/parents/show-parents-component.php';
    }


    }
}
public function ShowparentsbyGender($gname){
    $sql = "SELECT * FROM parents WHERE gender = '$gname' ORDER BY id desc";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $fullname =  $row["lastname"]." ". $row["firstname"]." ". $row["middlename"];
        require '../../components/parents/show-parents-component.php';
    }


    }
}
public function ShowProfile($id){
    $sql = "SELECT * FROM parents WHERE id='$id'";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    if ($result->num_rows == 1) {

      require_once '../../components/parents/edit-parent-component.php';


    }
}

public function ShowFullProfile($id){
    $sql = "SELECT * FROM parents WHERE id='$id'";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    if ($result->num_rows == 1) {

      require_once '../../components/parents/parents-profile-component.php';


    }
}
public function ShowParentsStudents($id){
    $sql = "SELECT * FROM parents_students where parent_id ='$id'";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      $adm = $row["admission_id"];
      echo "<option value='$adm'>$adm</option>";
    }


    }
}
public function ShowMyChildren($id){
    $sql = "SELECT * FROM parents_students where parent_id ='$id'";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      $adm = $row["admission_id"];
      $this->ShowParentsStudentsbyID($adm);
    }


    }
}
public function ShowMyChildrenInvoices($id){
    $sql = "SELECT * FROM parents_students where parent_id ='$id'";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      $adm = $row["admission_id"];
      $this->ShowInvoiceByAdm($adm);
    }


    }
}
public function ShowMyChildrenReceipts($id){
    $sql = "SELECT * FROM parents_students where parent_id ='$id'";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      $adm = $row["admission_id"];
      $this->ShowReceiptByAdm($adm);
    }


    }
}
public function ShowParentsStudentsbyID($id){
    $sql = "SELECT * FROM students WHERE admission_id = '$id'";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $fullname =  $row["lastname"]." ". $row["firstname"]." ". $row["middlename"];
        require '../../components/students/show-pstudents-component.php';
    }


    }
}
public function Login($email,$password){
    $sql = "SELECT * FROM parents WHERE email='$email'";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    $data = array();
    if ($result->num_rows == 1) {

    //  $class =  $row["class"];
    //  $section =  $row["section"];
      $fullname =  $row["firstname"]." ". $row["lastname"];
      $email =  $row["email"];
      $passport =  $row["passport"];
      $id =  $row["id"];
    //  $admid =  $row["admission_id"];
    //  $sub_com =  $row["subject_combination"];
            session_start();
            $_SESSION["LOGGED_IN_PARENT"] = $email;
            $_SESSION["LOGGED_IN_PARENT_ID"] = $id;
            $_SESSION["FULLNAME"] = $fullname;
            $_SESSION["EMAIL"] = $email;
            $_SESSION["PASSPORT"] = $passport;
            $data['message']='<script>window.location="pages/parent"</script>';
            $data['code'] = 1;

    } else {
      $data['message'] = 'Wrong Login_ID Entered!';
      $data['code'] = 0;
    }
    echo json_encode($data);
   // $this->Mysqli_Object->close();
}

}
?>

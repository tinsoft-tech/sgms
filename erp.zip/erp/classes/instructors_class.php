<?php
$config = $_SERVER['DOCUMENT_ROOT']. '/erp/config/config.php';

//require_once "Mysqli_Class.php";
require_once $config;
spl_autoload_register(function ($class) {
    $path = "classes/";
    $extension = ".php";
    $fullpath = $class . $extension;
    include_once $fullpath;
});


class instructors_class{
public $Mysqli_Object;
public function __construct(){
    $instanceconnection = new mysqli_class(SERVER,USER,PASSWORD,SCHOOL_DATABASE);
    $instanceconnection->OpenConnection();
    $this->Mysqli_Object =$instanceconnection->obj;
}


public function SignUp($firstname,$middlename,$lastname,$class,$employment_id,$phone,$blood_group,$religion,$email,$address,$gender,$dob,$bio,$passport){
    $sql = "SELECT * FROM instructors WHERE employment_id='$employment_id'  AND firstname ='$firstname' AND middlename='$middlename' AND lastname='$lastname'";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    $data = array();
    if($firstname == "" || $middlename == "" ||$lastname == "" ||$class == "" ||$employment_id == "" ||$blood_group == "" ||$religion == "" ||
       $email == "" ||$address == "" ||$gender == "" ||$dob == "" ||$bio == ""
    )
    {
      $data['message']= 'Some fields are empty please correct and resubmit';
       $data['code']= 0;
    }
  else if ($result->num_rows == 1) {

  $data['message']= 'Duplicate Entry Found';
   $data['code']= 0;
    }
    else{
      $id =  $row["id"];


      $newsql = "INSERT INTO instructors(`id`, `firstname`, `middlename`, `lastname`, `email`, `passport`, `bloodgroup`, `address`, `dob`, `class`, `employment_id`, `phone`, `religion`, `gender`, `short_bio`)
      VALUES(NULL,'$firstname','$middlename','$lastname','$email','$passport','$blood_group','$address','$dob','$class','$employment_id','$phone','$religion','$gender','$bio')";
      if($resulty = $this->Mysqli_Object->query($newsql))
      {
          $data['message']= 'Registered Successfully';
           $data['code']= 1;
      }
      else{
          $data['message']= 'An Error has Occured';
          $data['code']= 0;
      }
    }
        echo json_encode($data);
}
public function ShowLatestInstructors(){
    $sql = "SELECT * FROM instructors  ORDER BY id desc Limit 1,5";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $fullname =  $row["lastname"]." ". $row["firstname"]." ". $row["middlename"];
        require '../../components/instructors/latest-instructors-component.php';
    }


    }
}
public function UpdateProfile($id,$firstname,$middlename,$lastname,$class,$phone,$bloodgroup,$religion,$email,$address,$gender,$dob){
  $data = array();
  $newsql = "UPDATE instructors SET firstname ='$firstname', middlename ='$middlename' , lastname ='$lastname' , email ='$email' , bloodgroup ='$bloodgroup' , address ='$address' , dob ='$dob', class ='$class'
,   phone ='$phone', religion ='$religion', gender ='$gender' WHERE id = '$id'";
  if($resulty = $this->Mysqli_Object->query($newsql))
  {
      $data['message']= 'Updated Successfully';
       $data['code']= 1;
  }
  else{
      $data['message']= 'An Error has Occured';
      $data['code']= 0;
  }
    echo json_encode($data);
}

public function DeleteProfile($id){
  $data = array();
  $newsql = "DELETE from instructors WHERE id = '$id'";
  if($resulty = $this->Mysqli_Object->query($newsql))
  {
      $data['message']= 'Deleted Successfully';
       $data['code']= 1;
  }
  else{
      $data['message']= 'An Error has Occured';
      $data['code']= 0;
  }
    echo json_encode($data);
}
public function ShowPassport($email){
    $sql = "SELECT * FROM staffs WHERE email='$email'";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    if ($result->num_rows == 1) {

        $fullname =  $row["passport"];
        return $fullname;
    }
}
public function ShowCount(){
    $sql = "SELECT COUNT(*) as count FROM instructors ";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {

        $count =  $row["count"];
        return $count;
    }
}
public function UpdatePassport($employment_id,$url){
    $sql = "SELECT * FROM instructors WHERE employment_id='$employment_id'";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    if ($result->num_rows == 1) {

        $id =  $row["id"];
        $data = array();

        $newsql = "UPDATE instructors SET passport ='$url' where id = '$id'";
        if($resulty = $this->Mysqli_Object->query($newsql))
        {
            $data['message']= 'Uploaded Successfully';
        }
        else{
            $data['message']= 'An Error has Occured';
        }

    }
}
public function Showinstructors(){
    $sql = "SELECT * FROM instructors ORDER BY id desc";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $fullname =  $row["lastname"]." ". $row["firstname"]." ". $row["middlename"];
        require '../../components/instructors/show-instructors-component.php';
    }


    }
}
public function ShowInstructorsbyLastName($lname){
    $sql = "SELECT * FROM instructors WHERE lastname LIKE'$lname%' ORDER BY id desc";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $fullname =  $row["lastname"]." ". $row["firstname"]." ". $row["middlename"];
        require '../../components/instructors/show-instructors-component.php';
    }


    }
}
public function ShowInstructorsbyClass($cname){
    $sql = "SELECT * FROM instructors WHERE class = '$cname' ORDER BY id desc";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $fullname =  $row["lastname"]." ". $row["firstname"]." ". $row["middlename"];
        require '../../components/instructors/show-instructors-component.php';
    }


    }
}
public function ShowInstructorsbyGender($gname){
    $sql = "SELECT * FROM instructors WHERE gender = '$gname' ORDER BY id desc";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $fullname =  $row["lastname"]." ". $row["firstname"]." ". $row["middlename"];
        require '../../components/instructors/show-instructors-component.php';
    }


    }
}
public function ShowProfile($id){
    $sql = "SELECT * FROM instructors WHERE id='$id'";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    if ($result->num_rows == 1) {

      require_once '../../components/instructors/edit-instructor-component.php';


    }
}

public function ShowFullProfile(){
    $sql = "SELECT * FROM instructors";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $fullname =  $row["lastname"]." ". $row["firstname"]." ". $row["middlename"];
        echo "<option value='$fullname'>$fullname</option>";
    }
  }
}


public function ShowFullInstructorProfile($id){
    $sql = "SELECT * FROM instructors WHERE email='$id'";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    if ($result->num_rows == 1) {

      require_once '../../components/instructors/instructors-profile-component.php';


    }
}

public function Login($email,$password){
    $sql = "SELECT * FROM instructors WHERE email='$email'";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    $data = array();
    if ($result->num_rows == 1) {

      $class =  $row["class"];
      $section =  $row["section"];
      $fullname =  $row["firstname"]." ". $row["lastname"];
      $email =  $row["email"];
      $passport =  $row["passport"];
            session_start();
            $_SESSION["LOGGED_IN_INSTRUCTOR"] = $email;
            $_SESSION["CLASS"]= $class;
            $_SESSION["SECTION"]= $section;
            $_SESSION["SUBJECT"]= $row["subject"];
            $_SESSION["FULLNAME"] = $fullname;
            $_SESSION["EMAIL"] = $email;
            $_SESSION["PASSPORT"] = $passport;
            $data['message']='<script>window.location="pages/instructor"</script>';
            $data['code'] = 1;

            } else {
            $data['message'] = 'Wrong Login_ID Entered!';
            $data['code'] = 0;
            }
            echo json_encode($data);
   // $this->Mysqli_Object->close();
}

}
?>

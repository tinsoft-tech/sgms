<?php
$config = $_SERVER['DOCUMENT_ROOT']. '/erp/config/config.php';

//require_once "Mysqli_Class.php";
require_once $config;
spl_autoload_register(function ($class) {
    $path = "classes/";
    $extension = ".php";
    $fullpath = $class . $extension;
    include_once $fullpath;
});


class subjects_class{
public $Mysqli_Object;
public function __construct(){
    $instanceconnection = new mysqli_class(SERVER,USER,PASSWORD,SCHOOL_DATABASE);
    $instanceconnection->OpenConnection();
    $this->Mysqli_Object =$instanceconnection->obj;
}


public function AddSubject($subjectname,$subjectlevel){
    $sql = "SELECT * FROM subjects WHERE  subjectname ='$subjectname'";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    $data = array();
    if($subjectname == "" || $subjectlevel == ""
    )
    {
      $data['message']= 'Some fields are empty please correct and resubmit';
       $data['code']= 0;
    }
  else if ($result->num_rows == 1) {

  $data['message']= 'Duplicate Entry Found';
   $data['code']= 0;
    }
    else{
      $id =  $row["id"];


      $newsql = "INSERT INTO subjects(`id`, `subject_name`, `subject_level`)
      VALUES(NULL,'$subjectname','$subjectlevel')";
      if($resulty = $this->Mysqli_Object->query($newsql))
      {
          $data['message']= 'Registered Successfully';
           $data['code']= 1;
      }
      else{
          $data['message']= 'An Error has Occured';
          $data['code']= 0;
      }
    }
        echo json_encode($data);
}

public function UpdateSubject($id,$subjectname,$subjectlevel){
  $data = array();
  $newsql = "UPDATE subjects SET subject_name ='$subjectname', subject_level ='$subjectlevel'  WHERE id = '$id'";
  if($resulty = $this->Mysqli_Object->query($newsql))
  {
      $data['message']= 'Updated Successfully';
       $data['code']= 1;
  }
  else{
      $data['message']= 'An Error has Occured';
      $data['code']= 0;
  }
    echo json_encode($data);
}

public function DeleteSubject($id){
  $data = array();
  $newsql = "DELETE from subjects WHERE id = '$id'";
  if($resulty = $this->Mysqli_Object->query($newsql))
  {
      $data['message']= 'Deleted Successfully';
       $data['code']= 1;
  }
  else{
      $data['message']= 'An Error has Occured';
      $data['code']= 0;
  }
    echo json_encode($data);
}

public function ShowCount(){
    $sql = "SELECT COUNT(*) as count FROM subjects ";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {

        $count =  $row["count"];
        return $count;
    }
}

public function ShowSubjects(){
    $sql = "SELECT * FROM subjects ORDER BY id desc";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {

        require '../../components/subjects/show-subjects-component.php';
    }


    }
}

public function ShowFullSubjects(){
    $sql = "SELECT * FROM subjects ORDER BY id desc";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
$subject = $row["subject_name"];
          echo "<option value='$subject'>$subject</option>";
    }


    }
}

public function ShowSubjectsbyClass($cname){
    $sql = "SELECT * FROM subjects WHERE subject_level = '$cname' ORDER BY id desc";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {

        require '../../components/subjects/show-subjects-component.php';
    }


    }
}
public function ShowSubjectsbyName($cname){
    $sql = "SELECT * FROM subjects WHERE subject_name LIKE '$cname%' ORDER BY id desc";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {

        require '../../components/subjects/show-subjects-component.php';
    }


    }
}

public function ShowId($id){
    $sql = "SELECT * FROM subjects WHERE id='$id'";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    if ($result->num_rows == 1) {

      require_once '../../components/subjects/edit-subjects-component.php';


    }
}



}
?>

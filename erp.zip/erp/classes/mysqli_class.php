<?php
class mysqli_class {
private $servername;
private $username;
private $password;
private $database;
public $obj;

public function __construct($s,$u,$p,$d){
$this->servername = $s;
$this->username = $u;
$this->password = $p;
$this->database = $d;
}

public function OpenConnection(){
    $this->obj =  $mysqli = new mysqli($this->servername, $this->username, $this->password, $this->database);
    if ($mysqli->connect_errno) {
    echo "Failed to connect to MySQL: " . $mysqli->connect_error;
    }
    else {
      //  echo "connected successfully";
    }
}


}

?>

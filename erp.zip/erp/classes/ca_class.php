<?php
$config = $_SERVER['DOCUMENT_ROOT']. '/erp/config/config.php';

//require_once "Mysqli_Class.php";
require_once $config;
spl_autoload_register(function ($class) {
    $path = "classes/";
    $extension = ".php";
    $fullpath = $class . $extension;
    include_once $fullpath;
});


class ca_class{
public $Mysqli_Object;
public function __construct(){
    $instanceconnection = new mysqli_class(SERVER,USER,PASSWORD,SCHOOL_DATABASE);
    $instanceconnection->OpenConnection();
    $this->Mysqli_Object =$instanceconnection->obj;
}


public function AddCaTest($subject,$com,$time,$class,$session,$term,$date,$duration){
    $sql = "SELECT * FROM ca_test WHERE subject_name='$subject' AND subject_combination='$com'  AND ca_session ='$session' AND ca_term='$term'";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    $data = array();
    if($subject == "" || $class == "" ||$session == "" ||$term == "" || $date == ""
    )
    {
      $data['message']= 'Some fields are empty please correct and resubmit';
       $data['code']= 0;
    }
  else if ($result->num_rows == 1) {

  $data['message']= 'Duplicate Entry Found';
   $data['code']= 0;
    }
    else{
      $id =  $row["id"];

      $newsql = "INSERT INTO ca_test(`id`, `subject_name`,`subject_combination`, `ca_time`, `ca_class`, `ca_session`, `ca_term`, `date`,`ca_duration`)
      VALUES(NULL,'$subject','$com','$time','$class','$session','$term','$date','$duration')";
      if($resulty = $this->Mysqli_Object->query($newsql))
      {
          $data['message']= 'Registered Successfully';
           $data['code']= 1;
      }
      else{
          $data['message']= 'An Error has Occured';
          $data['code']= 0;
      }
    }
        echo json_encode($data);
}
public function SubmitCaTest($ca_id,$admission_id,$q_number,$answer){
    $sql = "SELECT * FROM ca_submitted_answers WHERE ca_id='$ca_id' AND admission_id='$admission_id' AND question_number = '$q_number'";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    $data = array();
    if($ca_id == "" || $admission_id == "" ||$q_number == "" ||$answer == ""
    )
    {
      $data['message']= 'Some fields are empty please correct and resubmit';
       $data['code']= 0;
    }
  else if ($result->num_rows == 1) {
  $data['message']= 'Duplicate Entry Found';
   $data['code']= 0;
    }
    else{
      $newsql = "INSERT INTO ca_submitted_answers(`id`, `ca_id`,`admission_id`, `question_number`, `answer`)
      VALUES(NULL,'$ca_id','$admission_id','$q_number','$answer')";
      if($resulty = $this->Mysqli_Object->query($newsql))
      {
          $data['message']= 'Submitted Successfully';
           $data['code']= 1;
      }
      else{
          $data['message']= 'An Error has Occured';
          $data['code']= 0;
      }
    }
        echo json_encode($data);
}

/*public function UpdateExam($id,$subject,$time,$class,$session,$term,$date){
  $data = array();
  $newsql = "UPDATE ca_test SET subject_name ='$subject', exam_time ='$time' , exam_class ='$class' , exam_session ='$session' , exam_term ='$term' , date ='$date'  WHERE id = '$id'";
  if($resulty = $this->Mysqli_Object->query($newsql))
  {
      $data['message']= 'Updated Successfully';
       $data['code']= 1;
  }
  else{
      $data['message']= 'An Error has Occured';
      $data['code']= 0;
  }
    echo json_encode($data);
}
*/
public function DeleteCaTest($id){
  $data = array();
  $newsql = "DELETE from ca_test WHERE id = '$id'";
  if($resulty = $this->Mysqli_Object->query($newsql))
  {
      $data['message']= 'Deleted Successfully';
       $data['code']= 1;
  }
  else{
      $data['message']= 'An Error has Occured';
      $data['code']= 0;
  }
    echo json_encode($data);
}

public function ShowCount(){
    $sql = "SELECT COUNT(*) as count FROM ca_test ";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {

        $count =  $row["count"];
        return $count;
    }
}

public function ShowCaTest(){
    $sql = "SELECT * FROM ca_test ORDER BY id desc";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      //  $fullname =  $row["lastname"]." ". $row["firstname"]." ". $row["middlename"];
        require '../../components/ca/show-ca-test-component.php';
    }


    }
}

public function ShowFullCaTest($id,$sub){
    $sql = "SELECT * FROM ca_test where ca_class='$id' and subject_combination = '$sub'  ORDER BY id desc";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      //  $fullname =  $row["lastname"]." ". $row["firstname"]." ". $row["middlename"];
        require '../../components/ca/show-ca-test-component.php';
    }


    }
}

public function ShowInstructorFullCaTest($sub){
    $sql = "SELECT * FROM ca_test  where subject_name ='$sub'";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      //  $fullname =  $row["lastname"]." ". $row["firstname"]." ". $row["middlename"];
        require '../../components/ca/show-ins-ca-component.php';
    }


    }
}

public function ShowSubjectCombinations(){
    $sql = "SELECT * FROM subject_combinations";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
    $com =  $row["sub_combination"];
    $id = $row["id"];
    echo "<option value='$id'>$com</option>";
    }


    }
}

public function ShowSubmittedCaTest($id){
    $sql = "SELECT * FROM ca_submitted_answers  where subject_name ='$sub'";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      //  $fullname =  $row["lastname"]." ". $row["firstname"]." ". $row["middlename"];
        require '../../components/ca/show-ins-ca-component.php';
    }


    }
}

public function ShowExamById($id){
    $sql = "SELECT * FROM ca_test WHERE id='$id'";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    if ($result->num_rows == 1) {

      require_once '../../components/ca_test/edit-ca_test-component.php';


    }
}
public function ShowCaQuestionsCount($id){
    $sql = "SELECT COUNT(*) as count FROM ca_questions WHERE ca_id='$id'";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {

        $count =  $row["count"];
        return $count;
    }
}
public function ShowCaQuestions($id,$admission_id){
  $rsql = "SELECT * FROM ca_submitted_answers WHERE ca_id='$id' AND admission_id='$admission_id'";
  $rresult = $this->Mysqli_Object->query($rsql);
  if ($rresult->num_rows > 0) {
    echo "<div class='alert alert-success'>Test Taken Before</div>";
  }
  else{
    $sql = "SELECT * FROM ca_questions WHERE ca_id='$id'";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {

      while ($row = $result->fetch_assoc()) {
        //  $fullname =  $row["lastname"]." ". $row["firstname"]." ". $row["middlename"];
          require '../../components/ca/show-ca-questions-component.php';

      }
    echo"  </tbody>
    </table><hr/>";
echo "<button id='submit-ans' class='btn btn-md btn-primary'>submit</button>";
    }
  }

}

}
?>

<?php
$config = $_SERVER['DOCUMENT_ROOT']. '/erp/config/config.php';

//require_once "Mysqli_Class.php";
require_once $config;
spl_autoload_register(function ($class) {
    $path = "classes/";
    $extension = ".php";
    $fullpath = $class . $extension;
    include_once $fullpath;
});


class exams_class{
public $Mysqli_Object;
public function __construct(){
    $instanceconnection = new mysqli_class(SERVER,USER,PASSWORD,SCHOOL_DATABASE);
    $instanceconnection->OpenConnection();
    $this->Mysqli_Object =$instanceconnection->obj;
}


public function AddExam($subject,$time,$class,$session,$term,$date){
    $sql = "SELECT * FROM exams WHERE subject_name='$subject'  AND exam_session ='$session' AND exam_term='$term'";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    $data = array();
    if($subject == "" || $class == "" ||$session == "" ||$term == "" || $date == ""
    )
    {
      $data['message']= 'Some fields are empty please correct and resubmit';
       $data['code']= 0;
    }
  else if ($result->num_rows == 1) {

  $data['message']= 'Duplicate Entry Found';
   $data['code']= 0;
    }
    else{
      $id =  $row["id"];

      $newsql = "INSERT INTO exams(`id`, `subject_name`, `exam_time`, `exam_class`, `exam_session`, `exam_term`, `date`)
      VALUES(NULL,'$subject','$time','$class','$session','$term','$date')";
      if($resulty = $this->Mysqli_Object->query($newsql))
      {
          $data['message']= 'Registered Successfully';
           $data['code']= 1;
      }
      else{
          $data['message']= 'An Error has Occured';
          $data['code']= 0;
      }
    }
        echo json_encode($data);
}

public function UpdateExam($id,$subject,$time,$class,$session,$term,$date){
  $data = array();
  $newsql = "UPDATE exams SET subject_name ='$subject', exam_time ='$time' , exam_class ='$class' , exam_session ='$session' , exam_term ='$term' , date ='$date'  WHERE id = '$id'";
  if($resulty = $this->Mysqli_Object->query($newsql))
  {
      $data['message']= 'Updated Successfully';
       $data['code']= 1;
  }
  else{
      $data['message']= 'An Error has Occured';
      $data['code']= 0;
  }
    echo json_encode($data);
}

public function DeleteExam($id){
  $data = array();
  $newsql = "DELETE from exams WHERE id = '$id'";
  if($resulty = $this->Mysqli_Object->query($newsql))
  {
      $data['message']= 'Deleted Successfully';
       $data['code']= 1;
  }
  else{
      $data['message']= 'An Error has Occured';
      $data['code']= 0;
  }
    echo json_encode($data);
}

public function ShowCount(){
    $sql = "SELECT COUNT(*) as count FROM exams ";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {

        $count =  $row["count"];
        return $count;
    }
}

public function ShowExams(){
    $sql = "SELECT * FROM exams ORDER BY id desc";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      //  $fullname =  $row["lastname"]." ". $row["firstname"]." ". $row["middlename"];
        require '../../components/exams/show-exams-component.php';
    }


    }
}

public function ShowExamsbyClass($cname){
    $sql = "SELECT * FROM exams WHERE exam_class = '$cname' ORDER BY id desc";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      //  $fullname =  $row["lastname"]." ". $row["firstname"]." ". $row["middlename"];
        require '../../components/exams/show-exams-component.php';
    }


    }
}
public function ShowStudentExamsbyClass($cname){
    $sql = "SELECT * FROM exams WHERE exam_class = '$cname' ORDER BY id desc";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      //  $fullname =  $row["lastname"]." ". $row["firstname"]." ". $row["middlename"];
        require '../../components/exams/show-student-exams-component.php';
    }


    }
}

public function ShowInsExamsbySubject($cname){
    $sql = "SELECT * FROM exams WHERE subject_name = '$cname' ORDER BY id desc";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      //  $fullname =  $row["lastname"]." ". $row["firstname"]." ". $row["middlename"];
        require '../../components/exams/show-ins-exams-component.php';
    }


    }
}
public function ShowExamById($id){
    $sql = "SELECT * FROM exams WHERE id='$id'";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    if ($result->num_rows == 1) {

      require_once '../../components/exams/edit-exams-component.php';


    }
}

public function ShowExamQuestionsCount($id){
    $sql = "SELECT COUNT(*) as count FROM exam_questions WHERE exam_id='$id'";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {

        $count =  $row["count"];
        return $count;
    }
}
public function ShowExamTimer($id){
    $sql = "SELECT exam_time  FROM exams WHERE id='$id'";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {

        $time =  $row["exam_time"];
        $str = $time;
        $res = explode("-",$str);
        $fnum = strtotime($res[0]);
        $tnum = strtotime($res[1]);
        $timer = floatval($tnum - $fnum)/60;
        return $timer;
    }
}

public function ShowExamScore($id,$admission_id,$num){
    $sql = "SELECT count(*) as count FROM `exam_options` o ,`exam_submitted_answers` s WHERE o.exam_id = s.exam_id and o.question_id = s.question_number and o.correct_option = s.answer and s.exam_id='$id' and s.admission_id ='$admission_id'";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    $data = array();
    if ($result->num_rows > 0) {

        $count =  $row["count"];
        $percent = $count*100/$num;
        $c = "%";
        $cent = $percent.$c;
      require '../../components/exams/show-exams-score-component.php';
    }

}
public function ShowExamQuestions($id,$admission_id){
  $rsql = "SELECT * FROM exam_submitted_answers WHERE exam_id='$id' AND admission_id='$admission_id'";
  $rresult = $this->Mysqli_Object->query($rsql);
  if ($rresult->num_rows > 0) {
    echo "<div class='alert alert-success'>Exam Taken Before</div>";
  }
  else{
    $sql = "SELECT * FROM exam_questions WHERE exam_id='$id'";
    $result = $this->Mysqli_Object->query($sql);
    $rasql = "SELECT * FROM exams WHERE id='$id'";
    $raresult = $this->Mysqli_Object->query($rasql);
    $rarow = $raresult->fetch_assoc();
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
$count = 0;
      while ($row = $result->fetch_assoc()) {
        $qid = $row["id"];

        $asql = "SELECT * FROM exam_options WHERE exam_id='$id' and question_id ='$qid'";
        $aresult = $this->Mysqli_Object->query($asql);
        $arow = $aresult->fetch_assoc();
        $count++;
        //  $fullname =  $row["lastname"]." ". $row["firstname"]." ". $row["middlename"];
          require '../../components/exams/show-exams-question-component.php';

      }
    echo"  </tbody>
    </table><hr/>";
echo "<button id='submit-ans' class='btn btn-md btn-primary'>submit</button>";
    }
  }

}


public function SubmitExam($exam_id,$admission_id,$q_number,$answer){
    $sql = "SELECT * FROM exam_submitted_answers WHERE exam_id='$exam_id' AND admission_id='$admission_id' AND question_number = '$q_number'";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    $data = array();
    if($exam_id == "" || $admission_id == "" ||$q_number == "" ||$answer == ""
    )
    {
      $data['message']= 'Some fields are empty please correct and resubmit';
       $data['code']= 0;
    }
  else if ($result->num_rows == 1) {
  $data['message']= 'Duplicate exam Entry Found';
   $data['code']= 0;
    }
    else{
      $newsql = "INSERT INTO exam_submitted_answers(`id`, `exam_id`,`admission_id`, `question_number`, `answer`)
      VALUES(NULL,'$exam_id','$admission_id','$q_number','$answer')";
      if($resulty = $this->Mysqli_Object->query($newsql))
      {
          $data['message']= 'Submitted Successfully';
           $data['code']= 1;
      }
      else{
          $data['message']= 'An Error has Occured';
          $data['code']= 0;
      }
    }
        echo json_encode($data);
}



public function SubmitExamReport($exam_id,$id,$subject,$admission_id,$session,$total,$term){
  $rsql = "SELECT count(*) as count FROM `exam_options` o ,`exam_submitted_answers` s WHERE o.exam_id = s.exam_id and o.question_id = s.question_number and o.correct_option = s.answer and s.exam_id='$exam_id' and s.admission_id ='$admission_id'";
  $rresult = $this->Mysqli_Object->query($rsql);
  $rrow = $rresult->fetch_assoc();
  if ($rresult->num_rows > 0) {

      $count =  $rrow["count"];
      $percent = $count*100/$total;

  }
    $sql = "SELECT * FROM report WHERE report_id='$exam_id' AND admission_id='$admission_id'";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    $data = array();
    if($exam_id == "" || $admission_id == "")
    {
      $data['message']= 'Some fields are empty please correct and resubmit';
       $data['code']= 0;
    }
  else if ($result->num_rows == 1) {
  $data['message']= 'Duplicate Entry Found';
   $data['code']= 0;
    }
    else{
      $newsql = "INSERT INTO report(`id`, `report_id`,`report_type`, `subject`, `admission_id` ,`session`,`score`,`total`,`percentage`,`term`)
      VALUES(NULL,'$exam_id','$id','$subject','$admission_id','$session','$count','$total','$percent','$term')";
      if($resulty = $this->Mysqli_Object->query($newsql))
      {
          $data['message']= 'Submitted Successfully';
           $data['code']= 1;
      }
      else{
          $data['message']= 'An Error has Occured';
          $data['code']= 0;
      }
    }
        echo json_encode($data);
}

public function ShowReport($admission_id){
  $sql = "SELECT * FROM report WHERE  admission_id='$admission_id'";
  $result = $this->Mysqli_Object->query($sql);
  if ($result->num_rows > 0) {
    $count = 0;
    while ($row = $result->fetch_assoc()) {

      $count++;
        require '../../components/report/show-report-component.php';

      }

    }

}

}
?>

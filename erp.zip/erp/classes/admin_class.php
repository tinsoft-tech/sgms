<?php
$config = $_SERVER['DOCUMENT_ROOT']. '/erp/config/config.php';

//require_once "Mysqli_Class.php";
require_once $config;
spl_autoload_register(function ($class) {
    $path = "classes/";
    $extension = ".php";
    $fullpath = $class . $extension;
    include_once $fullpath;
});


class admin_class{
public $Mysqli_Object;
public function __construct(){
    $instanceconnection = new mysqli_class(SERVER,USER,PASSWORD,SCHOOL_DATABASE);
    $instanceconnection->OpenConnection();
    $this->Mysqli_Object =$instanceconnection->obj;
}



public function Login($login,$password){
    $sql = "SELECT * FROM admin WHERE login_id ='$login' AND password ='$password'";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    $data = array();
    if ($result->num_rows == 1) {
      $loginid =  $row["login_id"];
      $id =  $row["id"];
    //  $passport =  $row["passport"];
            session_start();
            $_SESSION["LOGGED_IN_USER"] = $loginid;
          //  $_SESSION["PASSPORT"] = $passport;
            $_SESSION["ID"] = $id;
            $data['message']='<script>window.location="pages/admin"</script>';
            $data['code'] = 1;

    } else {
        $data['message'] = 'Wrong Login_ID Entered!';
        $data['code'] = 0;
     //   require_once 'cards/login_error_card.php';
    }
    echo json_encode($data);
   // $this->Mysqli_Object->close();
}

}
?>

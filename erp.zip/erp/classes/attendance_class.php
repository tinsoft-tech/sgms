<?php
$config = $_SERVER['DOCUMENT_ROOT']. '/erp/config/config.php';

//require_once "Mysqli_Class.php";
require_once $config;
spl_autoload_register(function ($class) {
    $path = "classes/";
    $extension = ".php";
    $fullpath = $class . $extension;
    include_once $fullpath;
});


class attendance_class{
public $Mysqli_Object;
public function __construct(){
    $instanceconnection = new mysqli_class(SERVER,USER,PASSWORD,SCHOOL_DATABASE);
    $instanceconnection->OpenConnection();
    $this->Mysqli_Object =$instanceconnection->obj;
}


public function SubmitAttendance($session,$admission_id,$class,$section,$date){
    $sql = "SELECT * FROM attendance WHERE  admission_id ='$admission_id' AND date = '$date' AND session = '$session'";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    $data = array();
    if($admission_id == "" || $session == "" || $class == "" || $section == "" || $date == ""
    )
    {
      echo 'Some fields are empty please correct and resubmit';
       //$data['code']= 0;
    }
  else if ($result->num_rows == 1) {

  echo 'Attendance has been submitted before';
  // $data['code']= 0;
    }
    else{

      $newsql = "INSERT INTO `attendance` (`id`, `session`, `admission_id`, `class`, `section`,`date`, `status`)
      VALUES (NULL, '$session', '$admission_id', '$class','$section', '$date', '0')";
      if($resulty = $this->Mysqli_Object->query($newsql))
      {
          echo 'Submitted Successfully';
          // $data['code']= 1;
      }
      else{
          echo 'An Error has Occured';
          //$data['code']= 0;
      }
    }
      //  echo json_encode($data);
}



public function ShowCount(){
    $sql = "SELECT COUNT(*) as count FROM attendance ";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {

        $count =  $row["count"];
        return $count;
    }
}


public function ShowInstructorAttendanceByID($class,$section){
    $sql = "SELECT * FROM students WHERE class = '$class' and section ='$section'";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      $admission_id = $row["admission_id"];
      $this->ShowAttendanceByID($admission_id);
    }

  }

}
public function GenerateAttendance($class,$section,$date,$session){
  $sql = "SELECT * FROM students WHERE class = '$class' and section ='$section'";
  $result = $this->Mysqli_Object->query($sql);
//  $row = $result->fetch_assoc();
  if ($result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
    $admission_id = $row["admission_id"];
    $this->SubmitAttendance($session,$admission_id,$class,$section,$date);
  }
$this->ShowInstructorAttendanceByIDandDate($class,$section,$date);
}
}
public function ShowInstructorAttendanceByIDandDate($class,$section,$date){
    $sql = "SELECT * FROM students WHERE class = '$class' and section ='$section'";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      $admission_id = $row["admission_id"];
      $this->ShowInsAttendanceByIDandDate($admission_id,$date);
    }

  }
//echo $date;
}
public function ShowAttendanceByIDandDate($admission_id,$date){
    $sql = "SELECT * FROM attendance WHERE admission_id = '$admission_id' and date='$date' ORDER BY id desc";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {

        require '../../components/attendance/show-id-attendance-component.php';
    }


    }
}

public function ShowInsAttendanceByIDandDate($admission_id,$date){
    $sql = "SELECT * FROM attendance WHERE admission_id = '$admission_id' and date='$date' ORDER BY id desc";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {

        require '../../components/attendance/show-ins-id-attendance-component.php';
    }


    }
}

public function ShowAttendanceByID($admission_id){
    $sql = "SELECT * FROM attendance WHERE admission_id = '$admission_id' ORDER BY id desc";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {

        require '../../components/attendance/show-id-attendance-component.php';
    }


    }
}

public function MarkAttendanceByID($id){
    $sql = "UPDATE  attendance SET status=1  WHERE admission_id = '$id'";
    $data = array();
  if(  $result = $this->Mysqli_Object->query($sql))
  {

     $data['code']= 1;
  }
  else{
      echo 'An Error has Occured';
      $data['code']= 0;
  }
  echo json_encode($data);
}

public function UnMarkAttendanceByID($id){
    $sql = "UPDATE  attendance SET status=0  WHERE admission_id = '$id'";
    $data = array();
  if(  $result = $this->Mysqli_Object->query($sql))
  {

     $data['code']= 1;
  }
  else{
      echo 'An Error has Occured';
      $data['code']= 0;
  }
  echo json_encode($data);
}

public function ShowAttendanceByClass($cname){
    $sql = "SELECT * FROM attendance WHERE class = '$cname' ORDER BY id desc";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {

        require '../../components/subjects/show-subjects-component.php';
    }


    }
}
public function ShowSubjectsbyName($cname){
    $sql = "SELECT * FROM subjects WHERE subject_name LIKE '$cname%' ORDER BY id desc";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {

        require '../../components/subjects/show-subjects-component.php';
    }


    }
}




}
?>

<?php
$config = $_SERVER['DOCUMENT_ROOT']. '/erp/config/config.php';

//require_once "Mysqli_Class.php";
require_once $config;
spl_autoload_register(function ($class) {
    $path = "classes/";
    $extension = ".php";
    $fullpath = $class . $extension;
    include_once $fullpath;
});


class students_class{
public $Mysqli_Object;
public function __construct(){
    $instanceconnection = new mysqli_class(SERVER,USER,PASSWORD,SCHOOL_DATABASE);
    $instanceconnection->OpenConnection();
    $this->Mysqli_Object =$instanceconnection->obj;
}


public function SignUp($firstname,$middlename,$lastname,$class,$admission_id,$phone,$blood_group,$religion,$email,$address,$gender,$dob,$bio,$passport,$section,$sub_com){
    $sql = "SELECT * FROM students WHERE admission_id='$admission_id'  AND firstname ='$firstname' AND middlename='$middlename' AND lastname='$lastname'";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    $data = array();
    if($firstname == "" || $middlename == "" ||$lastname == "" ||$class == "" ||$admission_id == "" ||$blood_group == "" ||$religion == "" ||
       $email == "" ||$address == "" ||$gender == "" ||$dob == "" ||$bio == ""
    )
    {
      $data['message']= 'Some fields are empty please correct and resubmit';
       $data['code']= 0;
    }
  else if ($result->num_rows == 1) {

  $data['message']= 'Duplicate Entry Found';
   $data['code']= 0;
    }
    else{
      $id =  $row["id"];


      $newsql = "INSERT INTO students(`id`, `firstname`, `middlename`, `lastname`, `email`, `passport`, `bloodgroup`, `address`, `dob`, `class`, `admission_id`, `phone`, `religion`, `gender`, `short_bio`,`section`,`subject_combination`)
      VALUES(NULL,'$firstname','$middlename','$lastname','$email','$passport','$blood_group','$address','$dob','$class','$admission_id','$phone','$religion','$gender','$bio','$section','$sub_com')";
      if($resulty = $this->Mysqli_Object->query($newsql))
      {
          $data['message']= 'Registered Successfully';
           $data['code']= 1;
      }
      else{
          $data['message']= 'An Error has Occured';
          $data['code']= 0;
      }
    }
        echo json_encode($data);
}

public function UpdateProfile($id,$firstname,$middlename,$lastname,$class,$phone,$bloodgroup,$religion,$email,$address,$gender,$dob){
  $data = array();
  $newsql = "UPDATE students SET firstname ='$firstname', middlename ='$middlename' , lastname ='$lastname' , email ='$email' , bloodgroup ='$bloodgroup' , address ='$address' , dob ='$dob', class ='$class'
,   phone ='$phone', religion ='$religion', gender ='$gender' WHERE id = '$id'";
  if($resulty = $this->Mysqli_Object->query($newsql))
  {
      $data['message']= 'Updated Successfully';
       $data['code']= 1;
  }
  else{
      $data['message']= 'An Error has Occured';
      $data['code']= 0;
  }
    echo json_encode($data);
}

public function DeleteProfile($id){
  $data = array();
  $newsql = "DELETE from students WHERE id = '$id'";
  if($resulty = $this->Mysqli_Object->query($newsql))
  {
      $data['message']= 'Deleted Successfully';
       $data['code']= 1;
  }
  else{
      $data['message']= 'An Error has Occured';
      $data['code']= 0;
  }
    echo json_encode($data);
}
public function ShowCount(){
    $sql = "SELECT COUNT(*) as count FROM students ";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {

        $count =  $row["count"];
        return $count;
    }
}
public function ShowPassport($email){
    $sql = "SELECT * FROM staffs WHERE email='$email'";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    if ($result->num_rows == 1) {

        $fullname =  $row["passport"];
        return $fullname;
    }
}
public function UpdatePassport($admission_id,$url){
    $sql = "SELECT * FROM students WHERE admission_id='$admission_id'";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    if ($result->num_rows == 1) {

        $id =  $row["id"];
        $data = array();

        $newsql = "UPDATE students SET passport ='$url' where id = '$id'";
        if($resulty = $this->Mysqli_Object->query($newsql))
        {
            $data['message']= 'Uploaded Successfully';
        }
        else{
            $data['message']= 'An Error has Occured';
        }

    }
}
public function ShowStudents(){
    $sql = "SELECT * FROM students ORDER BY id desc";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $fullname =  $row["lastname"]." ". $row["firstname"]." ". $row["middlename"];
        require '../../components/students/show-students-component.php';
    }


    }
}
public function ShowLatestStudents(){
    $sql = "SELECT * FROM students  ORDER BY id desc Limit 0,5";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $fullname =  $row["lastname"]." ". $row["firstname"]." ". $row["middlename"];
        require '../../components/students/latest-students-component.php';
    }


    }
}
public function ShowStudentsbyLastName($lname){
    $sql = "SELECT * FROM students WHERE lastname LIKE'$lname%' ORDER BY id desc";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $fullname =  $row["lastname"]." ". $row["firstname"]." ". $row["middlename"];
        require '../../components/students/show-students-component.php';
    }


    }
}
public function ShowStudentsbyClass($cname){
    $sql = "SELECT * FROM students WHERE class = '$cname' ORDER BY id desc";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $fullname =  $row["lastname"]." ". $row["firstname"]." ". $row["middlename"];
        require '../../components/students/show-students-component.php';
    }


    }
}
public function ShowStudentsbyID($id){
    $sql = "SELECT * FROM students WHERE admission_id = '$id'";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $fullname =  $row["lastname"]." ". $row["firstname"]." ". $row["middlename"];
        require '../../components/students/show-students-component.php';
    }


    }
}

public function ShowParentsStudentsbyID($id){
    $sql = "SELECT * FROM students WHERE admission_id = '$id'";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $fullname =  $row["lastname"]." ". $row["firstname"]." ". $row["middlename"];
        require '../../components/students/show-pstudents-component.php';
    }


    }
}

public function ShowStudentsbyGender($gname){
    $sql = "SELECT * FROM students WHERE gender = '$gname' ORDER BY id desc";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $fullname =  $row["lastname"]." ". $row["firstname"]." ". $row["middlename"];
        require '../../components/students/show-students-component.php';
    }


    }
}
public function ShowProfile($id){
    $sql = "SELECT * FROM students WHERE id='$id'";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    if ($result->num_rows == 1) {

      require_once '../../components/students/edit-student-component.php';


    }
}
public function ShowFullProfile($id){
    $sql = "SELECT * FROM students WHERE id='$id'";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    if ($result->num_rows == 1) {
      $sub = $row["subject_combination"];
      $nsql = "SELECT sub_combination FROM subject_combinations WHERE id='$sub'";
      $nresult = $this->Mysqli_Object->query($nsql);
      $nrow = $nresult->fetch_assoc();
      $subname= $nrow["sub_combination"];
      require_once '../../components/students/students-profile-component.php';


    }
}

public function Login($email,$password){
    $sql = "SELECT * FROM students WHERE email='$email'";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    $data = array();
    if ($result->num_rows == 1) {

      $class =  $row["class"];
      $section =  $row["section"];
      $fullname =  $row["firstname"]." ". $row["lastname"];
      $email =  $row["email"];
      $passport =  $row["passport"];
      $id =  $row["id"];
      $admid =  $row["admission_id"];
      $sub_com =  $row["subject_combination"];
            session_start();
            $_SESSION["LOGGED_IN_USER"] = $email;
            $_SESSION["LOGGED_IN_ID"] = $id;
            $_SESSION["LOGGED_IN_ADMID"] = $admid;
            $_SESSION["CLASS"]= $class;
            $_SESSION["COM"]= $sub_com;
            $_SESSION["SECTION"]= $section;
            $_SESSION["FULLNAME"] = $fullname;
            $_SESSION["EMAIL"] = $email;
            $_SESSION["PASSPORT"] = $passport;
            $data['message']='<script>window.location="pages/student"</script>';
            $data['code'] = 1;

    } else {
      $data['message'] = 'Wrong Login_ID Entered!';
      $data['code'] = 0;
    }
    echo json_encode($data);
   // $this->Mysqli_Object->close();
}

}
?>

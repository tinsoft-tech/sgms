<?php
$config = $_SERVER['DOCUMENT_ROOT']. '/erp/config/config.php';

//require_once "Mysqli_Class.php";
require_once $config;
spl_autoload_register(function ($class) {
    $path = "classes/";
    $extension = ".php";
    $fullpath = $class . $extension;
    include_once $fullpath;
});


class assignment_class{
public $Mysqli_Object;
public function __construct(){
    $instanceconnection = new mysqli_class(SERVER,USER,PASSWORD,SCHOOL_DATABASE);
    $instanceconnection->OpenConnection();
    $this->Mysqli_Object =$instanceconnection->obj;
}


public function CreateAssignment($title,$subject,$class,$section,$date,$file,$score){
    $sql = "SELECT * FROM assignments WHERE  assignment_name ='$title' AND subject = '$subject' and class = '$class' and section='$section'";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    $data = array();
    if($title == "" || $subject == "" || $class == "" || $section == "" || $date == "" || $score == ""
    )
    {
      $data['message']=  'Some fields are empty please correct and resubmit';
       $data['code']= 0;
    }
  else if ($result->num_rows == 1) {

$data['message']= 'Assignment has been submitted before';
    $data['code']= 0;
    }
    else{
      $newsql = "INSERT INTO `assignments` (`id`, `assignment_name`, `question_url`, `class`, `section`, `subject`, `deadline`,`score`) VALUES
      (NULL, '$title', '$file', '$class', '$section', '$subject','$date','$score')";
      if($resulty = $this->Mysqli_Object->query($newsql))
      {
          $data['message']=  'Submitted Successfully';
           $data['code']= 1;
      }
      else{
        $data['message']=  'An Error has Occured';
          $data['code']= 0;
      }
    }
        echo json_encode($data);
}

public function SubmitAssignmentReport($ass_id,$type,$subject,$admission_id,$session,$score,$total,$term){

    $sql = "SELECT * FROM report WHERE report_id='$ass_id' AND report_type = '$type' AND admission_id='$admission_id'";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    $data = array();
    if($ass_id == "" || $admission_id == "" || $type == "" || $subject == ""|| $score == "" || $total == "" || $term == "")
    {
      $data['message']= 'Some fields are empty please correct and resubmit';
       $data['code']= 0;
    }
  else if ($result->num_rows == 1) {
  $data['message']= 'Duplicate Entry Found';
   $data['code']= 0;
    }
    else{
        $percent = $score*100/$total;
      $newsql = "INSERT INTO report(`id`, `report_id`,`report_type`, `subject`, `admission_id` ,`session`,`score`,`total`,`percentage`,`term`)
      VALUES(NULL,'$ass_id','$type','$subject','$admission_id','$session','$score','$total','$percent','$term')";
      if($resulty = $this->Mysqli_Object->query($newsql))
      {
          $data['message']= 'Submitted Successfully';
           $data['code']= 1;
           $nsql = "UPDATE submitted_assignments SET status = 1 Where assignment_id = '$ass_id'";
           $resultyy = $this->Mysqli_Object->query($nsql);
      }
      else{
          $data['message']= 'An Error has Occured';
          $data['code']= 0;
      }
    }
        echo json_encode($data);
}


public function SubmitAssignment($assignment_id,$admission_id,$imgpath,$date){
    $sql = "SELECT * FROM submitted_assignments WHERE  assignment_id ='$assignment_id' AND admission_id = '$admission_id'";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    $data = array();
    if($admission_id == "" || $assignment_id == ""
    )
    {
      echo 'Some fields are empty please correct and resubmit';
       //$data['code']= 0;
    }
  else if ($result->num_rows == 1) {

  echo 'Assignment has been submitted before';
  // $data['code']= 0;
    }
    else{
      $id =  $row["id"];


      $newsql = "INSERT INTO `submitted_assignments` (`id`, `assignment_id`, `admission_id`, `answer_url`, `submitted_date`, `status`) VALUES (NULL, '$assignment_id', '$admission_id', '$imgpath', '$date', '0')";
      if($resulty = $this->Mysqli_Object->query($newsql))
      {
          echo 'Submitted Successfully';
          // $data['code']= 1;
      }
      else{
          echo 'An Error has Occured';
          //$data['code']= 0;
      }
    }
      //  echo json_encode($data);
}



public function DeleteSubmittedAssignment($id){
  $data = array();
  $newsql = "DELETE from submitted_assignments WHERE id = '$id'";
  if($resulty = $this->Mysqli_Object->query($newsql))
  {
      $data['message']= 'Deleted Successfully';
       $data['code']= 1;
  }
  else{
      $data['message']= 'An Error has Occured';
      $data['code']= 0;
  }
    echo json_encode($data);
}

public function ShowCount(){
    $sql = "SELECT COUNT(*) as count FROM subjects ";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {

        $count =  $row["count"];
        return $count;
    }
}
public function ShowInstructorsAssignments($subject,$class){
  $sql = "SELECT * FROM `assignments` where class='$class' and subject='$subject'  ORDER BY id desc";
  $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
  if ($result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
      require '../../components/assignments/show-instructor-assignment-component.php';
  }


  }
}
public function ShowAssignments($class,$section,$admission_id){

    $sql = "SELECT * FROM `assignments` WHERE class ='$class' and section ='$section' AND assignments.id NOT IN (SELECT submitted_assignments.assignment_id FROM submitted_assignments where admission_id = '$admission_id') ORDER BY id desc";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {

        require '../../components/assignments/show-assignment-component.php';
    }


    }
}

public function ShowSubmittedAssignments($admission_id){

    $sql = "SELECT ass.id,ass.assignment_id,ass.admission_id,ass.answer_url,ass.submitted_date,ass.status,sub.assignment_name,sub.deadline FROM `assignments` sub , `submitted_assignments` ass WHERE  ass.admission_id = '$admission_id' AND ass.assignment_id = sub.id ORDER BY ass.submitted_date desc";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {

        require '../../components/assignments/show-sub-assignment-component.php';
    }


    }
}

public function ShowInstructorSubmittedAssignments($id){

    $sql = "SELECT ass.id,ass.assignment_id,ass.admission_id,ass.answer_url,ass.submitted_date,ass.status,sub.assignment_name,sub.deadline,sub.score,sub.subject FROM `assignments` sub , `submitted_assignments` ass WHERE  ass.assignment_id = '$id' AND ass.assignment_id = sub.id ORDER BY ass.submitted_date desc";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {

        require '../../components/assignments/show-ins-sub-assignment-component.php';
    }


    }
}


public function ShowFullSubjects(){
    $sql = "SELECT * FROM subjects ORDER BY id desc";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
$subject = $row["subject_name"];
          echo "<option value='$subject'>$subject</option>";
    }


    }
}

public function ShowSubjectsbyClass($cname){
    $sql = "SELECT * FROM subjects WHERE subject_level = '$cname' ORDER BY id desc";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {

        require '../../components/subjects/show-subjects-component.php';
    }


    }
}
public function ShowSubjectsbyName($cname){
    $sql = "SELECT * FROM subjects WHERE subject_name LIKE '$cname%' ORDER BY id desc";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {

        require '../../components/subjects/show-subjects-component.php';
    }


    }
}

public function ShowId($id){
    $sql = "SELECT * FROM subjects WHERE id='$id'";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    if ($result->num_rows == 1) {

      require_once '../../components/subjects/edit-subjects-component.php';


    }
}



}
?>

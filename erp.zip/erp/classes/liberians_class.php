<?php
$config = $_SERVER['DOCUMENT_ROOT']. '/erp/config/config.php';

//require_once "Mysqli_Class.php";
require_once $config;
spl_autoload_register(function ($class) {
    $path = "classes/";
    $extension = ".php";
    $fullpath = $class . $extension;
    include_once $fullpath;
});


class liberians_class{
public $Mysqli_Object;
public function __construct(){
    $instanceconnection = new mysqli_class(SERVER,USER,PASSWORD,SCHOOL_DATABASE);
    $instanceconnection->OpenConnection();
    $this->Mysqli_Object =$instanceconnection->obj;
}


public function SignUp($firstname,$middlename,$lastname,$phone,$blood_group,$religion,$email,$address,$employment_id,$gender,$passport){
    $sql = "SELECT * FROM liberians WHERE  firstname ='$firstname' AND middlename='$middlename' AND lastname='$lastname'";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    $data = array();
    if($firstname == "" || $middlename == "" ||$lastname == ""  ||$blood_group == "" ||$religion == "" ||
       $email == "" ||$address == "" ||$gender == ""
    )
    {
      $data['message']= 'Some fields are empty please correct and resubmit';
       $data['code']= 0;
    }
  else if ($result->num_rows == 1) {

  $data['message']= 'Duplicate Entry Found';
   $data['code']= 0;
    }
    else{
      $id =  $row["id"];


      $newsql = "INSERT INTO liberians(`id`, `firstname`, `middlename`, `lastname`, `email`, `passport`, `bloodgroup`, `address`,`employment_id`, `phone`, `religion`, `gender`)
      VALUES(NULL,'$firstname','$middlename','$lastname','$email','$passport','$blood_group','$address','$employment_id','$phone','$religion','$gender')";
      if($resulty = $this->Mysqli_Object->query($newsql))
      {
          $data['message']= 'Registered Successfully';
           $data['code']= 1;
      }
      else{
          $data['message']= 'An Error has Occured';
          $data['code']= 0;
      }
    }
        echo json_encode($data);
}



public function UpdateProfile($id,$firstname,$middlename,$lastname,$phone,$bloodgroup,$religion,$email,$address,$gender){
  $data = array();
  $newsql = "UPDATE liberians SET firstname ='$firstname', middlename ='$middlename' , lastname ='$lastname' , email ='$email' , bloodgroup ='$bloodgroup' , address ='$address',   phone ='$phone', religion ='$religion', gender ='$gender' WHERE id = '$id'";
  if($resulty = $this->Mysqli_Object->query($newsql))
  {
      $data['message']= 'Updated Successfully';
       $data['code']= 1;
  }
  else{
      $data['message']= 'An Error has Occured';
      $data['code']= 0;
  }
    echo json_encode($data);
}

public function DeleteProfile($id){
  $data = array();
  $newsql = "DELETE from liberians WHERE id = '$id'";
  if($resulty = $this->Mysqli_Object->query($newsql))
  {
      $data['message']= 'Deleted Successfully';
       $data['code']= 1;
  }
  else{
      $data['message']= 'An Error has Occured';
      $data['code']= 0;
  }
    echo json_encode($data);
}
public function ShowPassport($email){
    $sql = "SELECT * FROM staffs WHERE email='$email'";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    if ($result->num_rows == 1) {

        $fullname =  $row["passport"];
        return $fullname;
    }
}
public function ShowCount(){
    $sql = "SELECT COUNT(*) as count FROM liberians ";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {

        $count =  $row["count"];
        return $count;
    }
}
public function UpdatePassport($employment_id,$url){
    $sql = "SELECT * FROM liberians WHERE employment_id='$employment_id'";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    if ($result->num_rows == 1) {

        $id =  $row["id"];
        $data = array();

        $newsql = "UPDATE liberians SET passport ='$url' where id = '$id'";
        if($resulty = $this->Mysqli_Object->query($newsql))
        {
            $data['message']= 'Uploaded Successfully';
        }
        else{
            $data['message']= 'An Error has Occured';
        }

    }
}
public function ShowLiberians(){
    $sql = "SELECT * FROM liberians ORDER BY id desc";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $fullname =  $row["lastname"]." ". $row["firstname"]." ". $row["middlename"];
        require '../../components/liberians/show-liberians-component.php';
    }


    }
}
public function AddBook($isbn,$name,$category,$author,$publisher,$cover,$url){
    $sql = "SELECT * FROM books WHERE  isbn ='$isbn' AND title='$name'";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    $data = array();
    if($name == "" || $isbn == "" ||$category == ""  ||$author == "" ||$publisher == "")
    {
      $data['message']= 'Some fields are empty please correct and resubmit';
       $data['code']= 0;
    }
  else if ($result->num_rows == 1) {

  $data['message']= 'Duplicate Entry Found';
   $data['code']= 0;
    }
    else{
      $newsql = "INSERT INTO books(`id`, `isbn`, `title`, `category`, `author`, `publisher`, `cover`, `url`)
      VALUES(NULL,'$isbn','$name','$category','$author','$publisher','$cover','$url')";
      if($resulty = $this->Mysqli_Object->query($newsql))
      {
          $data['message']= 'Registered Successfully';
           $data['code']= 1;
      }
      else{
          $data['message']= 'An Error has Occured';
          $data['code']= 0;
      }
    }
        echo json_encode($data);
}


public function ShowBooks(){
    $sql = "SELECT * FROM books ORDER BY id desc";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      //  $fullname =  $row["lastname"]." ". $row["firstname"]." ". $row["middlename"];
        require '../../components/library/show-books-component.php';
    }


    }
}
public function ShowAllBooks(){
    $sql = "SELECT * FROM books  ORDER BY id desc";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      //  $fullname =  $row["lastname"]." ". $row["firstname"]." ". $row["middlename"];
        require '../../components/library/show-books-component.php';
    }


    }
    else{
      echo "<div><center>No Record Found</center></div>";
    }
}
public function ShowBooksByName($search){
    $sql = "SELECT * FROM books WHERE title LIKE '$search%'  ORDER BY id desc";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      //  $fullname =  $row["lastname"]." ". $row["firstname"]." ". $row["middlename"];
        require '../../components/library/show-books-component.php';
    }


    }
    else{
      echo "<div><center>No Record Found</center></div>";
    }
}
public function ShowLiberiansbyLastName($lname){
    $sql = "SELECT * FROM liberians WHERE lastname LIKE'$lname%' ORDER BY id desc";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $fullname =  $row["lastname"]." ". $row["firstname"]." ". $row["middlename"];
        require '../../components/liberians/show-liberians-component.php';
    }


    }
}
public function ShowLiberiansbyClass($cname){
    $sql = "SELECT * FROM liberians WHERE class = '$cname' ORDER BY id desc";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $fullname =  $row["lastname"]." ". $row["firstname"]." ". $row["middlename"];
        require '../../components/liberians/show-liberians-component.php';
    }


    }
}
public function ShowLiberiansbyGender($gname){
    $sql = "SELECT * FROM liberians WHERE gender = '$gname' ORDER BY id desc";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $fullname =  $row["lastname"]." ". $row["firstname"]." ". $row["middlename"];
        require '../../components/liberians/show-liberians-component.php';
    }


    }
}
public function ShowProfile($id){
    $sql = "SELECT * FROM liberians WHERE id='$id'";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    if ($result->num_rows == 1) {

      require_once '../../components/liberians/edit-liberians-component.php';


    }
}
public function ShowFullProfile($id){
    $sql = "SELECT * FROM liberians WHERE email='$id'";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    if ($result->num_rows == 1) {

      require_once '../../components/liberians/liberians-profile-component.php';


    }
}

public function Login($email,$password){
    $sql = "SELECT * FROM liberians WHERE email='$email'";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    $data = array();
    if ($result->num_rows == 1) {


      $fullname =  $row["firstname"]." ". $row["lastname"];
      $email =  $row["email"];
      $passport =  $row["passport"];
            session_start();
            $_SESSION["LOGGED_IN_LIBERIAN"] = $email;

            $_SESSION["FULLNAME"] = $fullname;
            $_SESSION["EMAIL"] = $email;
            $_SESSION["PASSPORT"] = $passport;
            $data['message']='<script>window.location="pages/liberian"</script>';
            $data['code'] = 1;

    } else {
      $data['message'] = 'Wrong Login_ID Entered!';
      $data['code'] = 0;
    }
    echo json_encode($data);
   // $this->Mysqli_Object->close();
}

}
?>

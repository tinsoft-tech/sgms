<?php
$config = $_SERVER['DOCUMENT_ROOT']. '/erp/config/config.php';

//require_once "Mysqli_Class.php";
require_once $config;
spl_autoload_register(function ($class) {
    $path = "classes/";
    $extension = ".php";
    $fullpath = $class . $extension;
    include_once $fullpath;
});


class class_and_routine_class{
public $Mysqli_Object;
public function __construct(){
    $instanceconnection = new mysqli_class(SERVER,USER,PASSWORD,SCHOOL_DATABASE);
    $instanceconnection->OpenConnection();
    $this->Mysqli_Object =$instanceconnection->obj;
}

public function AddClassRoutine($class_name,$section,$from,$to,$subject,$instructor,$date){
    $sql = "SELECT * FROM class_routine WHERE  class_name ='$class_name' AND date ='$date' AND instructor ='$instructor'";
    $result = $this->Mysqli_Object->query($sql);
    $row = $result->fetch_assoc();
    $data = array();
    if($class_name == "" || $section == "" || $subject == "" || $instructor == "" || $date == "" || $from == "" || $to == ""
    )
    {
      $data['message']= 'Some fields are empty please correct and resubmit';
       $data['code']= 0;
    }
  else if ($result->num_rows == 1) {

  $data['message']= 'Duplicate Entry Found';
   $data['code']= 0;
    }
    else{
    //  $id =  $row["id"];

       $time = $from."-".$to;
      $newsql = "INSERT INTO class_routine(`id`, `class_name`,`section`, `class_time`,`subject`, `instructor`,`date`)
      VALUES(NULL,'$class_name','$section','$time','$subject','$instructor','$date')";
      if($resulty = $this->Mysqli_Object->query($newsql))
      {
          $data['message']= 'Registered Successfully';
           $data['code']= 1;
      }
      else{
          $data['message']= 'An Error has Occured';
          $data['code']= 0;
      }
    }
        echo json_encode($data);
}
public function ShowClassRoutinebyClass($cname){
    $sql = "SELECT * FROM class_routine WHERE class_name = '$cname' ORDER BY id desc";
    $result = $this->Mysqli_Object->query($sql);
  //  $row = $result->fetch_assoc();
    if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {

        require '../../components/classes/show-class-routine-component.php';
    }


    }
}
public function UpdateClassRoutine($id,$class_name,$section,$time,$subject,$instructor,$date){
  $data = array();
  $newsql = "UPDATE class_routine SET class_name ='$class_name', section ='$section', class_time ='$time' , subject ='$subject' , instructor ='$instructor' ,date ='$date'  WHERE id = '$id'";
  if($resulty = $this->Mysqli_Object->query($newsql))
  {
      $data['message']= 'Updated Successfully';
       $data['code']= 1;
  }
  else{
      $data['message']= 'An Error has Occured';
      $data['code']= 0;
  }
    echo json_encode($data);
}

public function DeleteClassRoutine($id){
  $data = array();
  $newsql = "DELETE from class_routine WHERE id = '$id'";
  if($resulty = $this->Mysqli_Object->query($newsql))
  {
      $data['message']= 'Deleted Successfully';
       $data['code']= 1;
  }
  else{
      $data['message']= 'An Error has Occured';
      $data['code']= 0;
  }
    echo json_encode($data);
}
public function ShowClasses(){
  $sql ="SELECT * FROM class";
  $result = $this->Mysqli_Object->query($sql);
  if ($result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
$class = $row["class_name"];
      echo "<option value='$class'>$class</option>";
  }
}
else {
echo "no record found";
}
}

public function ShowSubCombination(){
  $sql ="SELECT * FROM subject_combinations";
  $result = $this->Mysqli_Object->query($sql);
  if ($result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
$id = $row["id"];
$class = $row["sub_combination"];
      echo "<option value='$id'>$class</option>";
  }
}
else {
echo "no record found";
}
}

public function ShowClassRoutine(){
  $sql ="SELECT * FROM class_routine";
  $result = $this->Mysqli_Object->query($sql);
  if ($result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {

      require '../../components/classes/show-class-routine-component.php';
  }
  }
  else {
//  echo "no record found";
  }

}

public function ShowClassRoutineById($id){
  $sql ="SELECT * FROM class_routine where id = '$id'";
  $result = $this->Mysqli_Object->query($sql);
  if ($result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {

      require '../../components/classes/edit-class-routine-component.php';
  }
  }
  else {
//  echo "no record found";
  }

}


}

?>

<?php include "layouts/index-page-layouts/header.php";?>
<body class="bg-defaultt" style="background:black;">
<!-- Navbar -->
<?php  include "layouts/index-page-layouts/navigation-bar.php";?>
<!--Navbar End -->
  <!-- Main content -->
  <div class="main-content">
    <!-- Header -->
    <div class="header bg-gradient-default py-7 py-lg-8 pt-lg-9">
      <div class="container">
        <div class="header-body text-center mb-7">
          <div class="row justify-content-center">
            <div class="col-xl-5 col-lg-6 col-md-8 px-5">
              <h1 class="text-white">Welcome!</h1>
              <p class="text-lead text-white">Key in your Login Credentials to Access the system.</p>
            </div>
          </div>
        </div>
      </div>

    </div>
    <!-- Page content -->
    <div style="margin-top:-220px !important;" class="container mt--8 pb-5">
      <div class="row justify-content-center">
        <div class="col-lg-5 col-md-7">
          <div class="card bg-secondary border-0 mb-0">
            <div class="card-header bg-transparent pb-5">
              <div class="text-muted text-center mt-2 mb-3">Sign in with Credentials
<p>
<h3>Demo Login Credentials</h3>
<h4>Login ID : TestUser@test.com</h4>
<h4>Password : Password123 </h4>

</p>

              </div>

            </div>
            <div class="card-body px-lg-5 py-lg-5">

              <form role="form" method="post" enctype="multipart/form-data" id="login-form">
                <div class="form-group mb-3">
                  <div class="input-group input-group-merge input-group-alternative">
                    <div class="input-group-prepend">
                      <span class="input-group-text"><i class="ni ni-circle-08"></i></span>
                    </div>
                    <input class="form-control" name="login_id" placeholder="Login ID" type="text">
                  </div>
                </div>
                <div class="form-group">
                  <div class="input-group input-group-merge input-group-alternative">
                    <div class="input-group-prepend">
                      <span class="input-group-text"><i class="ni ni-lock-circle-open"></i></span>
                    </div>
                    <input class="form-control" placeholder="Password" name="password" type="password">
                  </div>
                </div>
                <div class="form-group">
                      <select name="role" class="form-control" id="exampleFormControlSelect2">
                      <option>Select User Type</option>
                      <option value="student">Student</option>
                      <option value="parent">Parent</option>
                      <option value="admin">Administrator</option>
                      <option value="instructor">Instructor</option>
                      <option value="accountant">Accountant</option>
                      <option value="liberian">Liberian</option>
                      </select>
                </div>

                <div class="text-center">
                  <button type="submit" class="btn btn-primary btn-md" style="width:100%;">Sign in</button>
                  <br/>
                  <div id="response">

                  </div>
                </div>
              </form>
            </div>
          </div>
          <div class="row mt-3" style="display:none;">
            <div class="col-6">
              <a href="#" class="text-light"><small>Forgot password?</small></a>
            </div>
            <div class="col-6 text-right">
              <a href="#" class="text-light"><small>Create new account</small></a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Footer -->
  <footer class="py-5" id="footer-main">
    <div class="container">
      <div class="row align-items-center justify-content-xl-between">


      </div>
    </div>
  </footer>
  <!-- Argon Scripts -->
  <!-- Core -->
  <script src="assets/vendor/jquery/dist/jquery.min.js"></script>
  <script src="assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/js-cookie/js.cookie.js"></script>
  <script src="assets/vendor/jquery.scrollbar/jquery.scrollbar.min.js"></script>
  <script src="assets/vendor/jquery-scroll-lock/dist/jquery-scrollLock.min.js"></script>
  <script>
  var frm = $('#login-form');

      frm.submit(function (e) {

          e.preventDefault();
          var  process_url = "processes/login.php";
          $.ajax({

              url: process_url,
              type: "POST",             // Type of request to be send, called as method
              data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
              contentType: false,
              dataType: 'json',       // The content type used when sending data to the server.
              cache: false,
             // encode: true;           // To unable request pages to be cached
              processData:false,
              beforeSend: function() {
                  $("#response").html("<div class='alert alert-info' role='alert'>Please wait..........</div>");
               },
              success: function (data) {
                if(data.code == 1){
                frm.trigger("reset");
                 $("#response").html("");
                 $("#response").html("<div class='alert alert-success' role='alert'>"+data.message+"</div>");
                 setTimeout(function(){
                    $("#response").html("");
                 },3000);
              }
              else{
                 $("#response").html("");
                 $("#response").html("<div class='alert alert-danger' role='alert'>"+data.message+"</div>");
                 setTimeout(function(){
                    $("#response").html("");
                 },3000);
              }


              },
              error: function (data) {
                //  console.log('An error occurred.');
                  console.log(data);
              },
          });
      });


  </script>
  <!-- Argon JS -->
  <script src="assets/js/argon.js?v=1.2.0"></script>
</body>

</html>

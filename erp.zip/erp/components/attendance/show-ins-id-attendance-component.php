
<?php
$res = "";
$id = $row['id'] ;
switch ($row['status']) {
  case '1':
  $color = "green";
  $res = "
  <input class='mark-att' id='$id'  type='checkbox' checked>";
    break;
  case '0':
  $color = "crimson";
  $res =  "
  <input class='mark-att'  id='$id' type='checkbox'>";
    break;
  default:
    // code...
    break;
}
 ?>
<tr id="mytr<?php echo $row['id'] ;?>" style="background:<?php echo $color;?>;color:white;">


      <th scope="col" class="sort " data-sort="name"><?php echo $row['session'];?></th>
      <th scope="col" class="sort" data-sort="budget"><?php echo $row['admission_id'];?></th>
      <th scope="col" class="sort" data-sort="status"><?php echo $row['class'];?></th>
      <th scope="col" class="sort" data-sort="status"><?php echo $row['section'];?></th>
      <th scope="col" class="sort" data-sort="status"><?php echo $row['date'];?></th>
      <th scope="col" class="sort" data-sort="status">
<input type="hidde" id="mytra<?php echo $row['id'] ;?>" value="<?php echo $row['admission_id'];?>"/>
      <?php echo $res;?>
      </th>

  </tr>

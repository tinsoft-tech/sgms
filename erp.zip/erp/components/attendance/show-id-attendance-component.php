
<?php
$res = "";
switch ($row['status']) {
  case '1':
  $res = "<button class='btn btn-sm btn-success'>PRESENT</button>";
    break;
  case '0':
  $res = "<button class='btn btn-sm btn-danger'>ABSENT</button>";
    break;
  default:
    // code...
    break;
}
 ?>
<tr id="mytr<?php echo $row['id'] ;?>">


      <th scope="col" class="sort" data-sort="name"><?php echo $row['session'];?></th>
      <th scope="col" class="sort" data-sort="budget"><?php echo $row['admission_id'];?></th>
      <th scope="col" class="sort" data-sort="status"><?php echo $row['class'];?></th>
      <th scope="col" class="sort" data-sort="status"><?php echo $row['section'];?></th>
      <th scope="col" class="sort" data-sort="status"><?php echo $row['date'];?></th>
      <th scope="col" class="sort" data-sort="status"><?php echo $res;?></th>

  </tr>

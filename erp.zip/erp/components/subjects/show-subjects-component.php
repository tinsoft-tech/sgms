  
  <tr id="mytr<?php echo $row['id'] ;?>">


        <th scope="col" class="sort" data-sort="name"><?php echo $row['subject_name'];?></th>
        <th scope="col" class="sort" data-sort="budget"><?php echo $row['subject_level'];?></th>
        <th scope="col" class="sort" data-sort="status"></th>
        <th scope="col" class="sort" data-sort="status"></th>

        <th scope="col" class="sort" data-sort="name">
        <button class="btn btn-sm btn-info edit-sub" data-toggle="modal" id="<?php echo $row['id'] ;?>" data-target="#subeditmodal-form">edit</button>
        <button class="btn btn-sm btn-danger delete-sub" id="<?php echo $row['id'] ;?>">delete</button>
        </th>
    </tr>

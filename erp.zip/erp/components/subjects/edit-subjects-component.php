<div class="modal-content">

    <div class="modal-body p-0">

<div class="card-body">
  <form id="edit-inst-form" method="post">
<h2>Edit <?php echo $row["subject_name"];?></h2>
<div class="row">
<div class="col-md-4">
<label>Subject Name</label>
</div>
<div class="col-md-8">
<div class="form-group mb-3">
<div class="input-group input-group-merge input-group-alternative">
    <input class="form-control" name="subjectname" value="<?php echo $row["subject_name"];?>" placeholder="Email" type="text">
    <input class="form-control" name="id" value="<?php echo $row["id"];?>" placeholder="Email" type="hidden">
</div>
</div>
</div>

</div>
<div class="row">
<div class="col-md-4">
<label>Subject Level</label>
</div>
<div class="col-md-8">
<div class="form-group mb-3">
<div class="input-group input-group-merge input-group-alternative">
  <select class="form-control" name="subjectlevel" id="exampleFormControlSelect1">
  <?php
  switch ($row['subject_level']) {
    case 'Primary':
    echo '<option selected value="Primary">Primary</option>';
    echo '<option value="Secondary">Secondary</option>';
      break;
      case 'Secondary':
      echo '<option value="Primary">Prmary</option>';
      echo '<option selected  value="Secondary">Secondary</option>';
        break;
    default:
      # code...
      break;
  }



   ?>


  </select>
</div>
</div>
</div>

</div>






<br/>
<div class="row">
<div class="col-md-8">
<div  id="res-label"></div>
</div>
<div class="col-md-4">
<div class="form-group mb-3">
<div class="input-group input-group-merge input-group-alternative">
  <input class="form-control btn-default" value="Update" placeholder="Email" type="submit">
</div>
</div>
</div>

</div>
</form>

</div>




    </div>

</div>
</div>
<script>
$(document).ready(function (){
  var stfrm = $('#edit-inst-form');

      stfrm.submit(function (e) {

          e.preventDefault();
          var  process_url = "../../processes/admin/edit-subjects.php";
          $.ajax({

              url: process_url,
              type: "POST",             // Type of request to be send, called as method
              data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
              contentType: false,
              dataType: 'json',       // The content type used when sending data to the server.
              cache: false,
             // encode: true;           // To unable request pages to be cached
              processData:false,
              beforeSend: function() {
                  $("#res-label").html("<div class='alert alert-info' role='alert'>Please wait..........</div>");
               },
              success: function (data) {
                if(data.code == 1){
                  //  alert(data.message);
                frm.trigger("reset");
                 $("#res-label").html("");
                 $("#res-label").html("<div class='alert alert-success' role='alert'>"+data.message+"</div>");
                 setTimeout(function(){
                    $("#res-label").html("");
                 },3000);
              }
              else{
                alert(data.message);
                 $("#res-label").html("");
                 $("#res-label").html("<div class='alert alert-danger' role='alert'>"+data.message+"</div>");
                 setTimeout(function(){
                    $("#res-label").html("");
                 },3000);
              }


              },
              error: function (data) {
                //  console.log('An error occurred.');
                  console.log(data);
              },
          });
      });

});
</script>

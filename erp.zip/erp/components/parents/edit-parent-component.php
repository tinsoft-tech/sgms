<div class="modal-content">

    <div class="modal-body p-0">

<div class="card-body">
  <form id="edit-par-form" method="post">
<div class="row">
<div class="col-md-2">
<img style="width:50px;height:50px;" src="../../processes/admin/<?php echo $row['passport'];?>">
</div>
<div class="col-md-8">
<label><?php // echo $row["employment_id"];?></label>
</div>

</div>
<br/>
<div class="row">
<div class="col-md-4">
<label>First Name</label>
</div>
<div class="col-md-8">
<div class="form-group mb-3">
<div class="input-group input-group-merge input-group-alternative">
  <input class="form-control" name="firstname" value="<?php echo $row["firstname"];?>" placeholder="Email" type="text">
</div>
</div>
</div>

</div>
<div class="row">
<div class="col-md-4">
<label>Middle Name</label>
</div>
<div class="col-md-8">
<div class="form-group mb-3">
<div class="input-group input-group-merge input-group-alternative">
  <input class="form-control" name="middlename" value="<?php echo $row["middlename"];?>" placeholder="Email" type="text">
</div>
</div>
</div>

</div>
<div class="row">
<div class="col-md-4">
<label>Last Name</label>
</div>
<div class="col-md-8">
<div class="form-group mb-3">
<div class="input-group input-group-merge input-group-alternative">
  <input class="form-control" name="lastname" value="<?php echo $row["lastname"];?>" placeholder="Email" type="text">
</div>
</div>
</div>

</div>

<div class="row">
<div class="col-md-4">
<label>Occupation</label>
</div>
<div class="col-md-8">
<div class="input-group input-group-merge input-group-alternative">

<input class="form-control"  name="occupation" value="<?php echo $row["occupation"];?>" placeholder="Email" type="text">
</div>
</div>

</div>
<br/>
<div class="row">
<div class="col-md-4">
<label>Email</label>
</div>
<div class="col-md-8">
<div class="form-group mb-3">
<div class="input-group input-group-merge input-group-alternative">
  <input class="form-control"  name="email" value="<?php echo $row["email"];?>" placeholder="Email" type="email">
    <input class="form-control"  name="id" value="<?php echo $row["id"];?>" placeholder="Email" type="hidden">
</div>
</div>
</div>

</div>
<div class="row">
<div class="col-md-4">
<label>Address</label>
</div>
<div class="col-md-8">
<div class="form-group mb-3">
<div class="input-group input-group-merge input-group-alternative">
  <input class="form-control" name="address" value="<?php echo $row["address"];?>" placeholder="Email" type="text">
</div>
</div>
</div>

</div>
<div class="row">
<div class="col-md-4">
<label>Phone</label>
</div>
<div class="col-md-8">
<div class="form-group mb-3">
<div class="input-group input-group-merge input-group-alternative">
  <input class="form-control" name="phone" value="<?php echo $row["phone"];?>" placeholder="Email" type="phone">
</div>
</div>
</div>

</div>
<div class="row">
<div class="col-md-4">
<label>Religion</label>
</div>
<div class="col-md-8">
<div class="input-group input-group-merge input-group-alternative">

<select class="form-control" name="religion" id="exampleFormControlSelect1">
<?php
switch ($row["religion"]) {
  case 'Christian':
  echo '<option selected value="Christian">Christian</option>
  <option value="Islam">Islam</option>
  <option value="Hindu">Hindu</option>
  <option value="Buddish">Buddish</option>
  <option value="Others">Others</option>';
    break;
    case 'Islam':
    echo '<option  value="Christian">Christian</option>
    <option selected value="Islam">Islam</option>
    <option value="Hindu">Hindu</option>
    <option value="Buddish">Buddish</option>
    <option value="Others">Others</option>';
      break;
      case 'Hindu':
      echo '<option  value="Christian">Christian</option>
      <option  value="Islam">Islam</option>
      <option selected value="Hindu">Hindu</option>
      <option value="Buddish">Buddish</option>
      <option value="Others">Others</option>';
        break;
        case 'Buddish':
        echo '<option  value="Christian">Christian</option>
        <option value="Islam">Islam</option>
        <option value="Hindu">Hindu</option>
        <option selected value="Buddish">Buddish</option>
        <option value="Others">Others</option>';
          break;
          case 'Others':
          echo '<option  value="Christian">Christian</option>
          <option  value="Islam">Islam</option>
          <option value="Hindu">Hindu</option>
          <option value="Buddish">Buddish</option>
          <option selected value="Others">Others</option>';
            break;
  default:
    # code...
    break;
}
 ?>


</select>
</div>
</div>

</div>
<br/>
<div class="row">
<div class="col-md-4">
<label>Blood Group</label>
</div>
<div class="col-md-8">
<div class="input-group input-group-merge input-group-alternative">

<select class="form-control" name="bloodgroup" id="exampleFormControlSelect1">
  <?php
  switch ($row['bloodgroup']) {
    case 'A+':
    echo
    '
    <option selected value="A+">A+</option>
    <option value="A-">A-</option>
    <option value="B+">B+</option>
    <option value="B-">B-</option>
    <option value="O+">O+</option>
    <option value="O-">O-</option>
    ';

      break;
      case 'A-':
      echo
      '
      <option  value="A+">A+</option>
      <option selected value="A-">A-</option>
      <option value="B+">B+</option>
      <option value="B-">B-</option>
      <option value="O+">O+</option>
      <option value="O-">O-</option>
      ';

        break;
        case 'B+':
        echo
        '
        <option value="A+">A+</option>
        <option value="A-">A-</option>
        <option selected value="B+">B+</option>
        <option value="B-">B-</option>
        <option value="O+">O+</option>
        <option value="O-">O-</option>
        ';

          break;
          case 'B-':
          echo
          '
          <option  value="A+">A+</option>
          <option value="A-">A-</option>
          <option value="B+">B+</option>
          <option selected value="B-">B-</option>
          <option value="O+">O+</option>
          <option value="O-">O-</option>
          ';

            break;
            case 'O+':
            echo
            '
            <option  value="A+">A+</option>
            <option value="A-">A-</option>
            <option value="B+">B+</option>
            <option value="B-">B-</option>
            <option selected value="O+">O+</option>
            <option value="O-">O-</option>
            ';

              break;
              case 'O-':
              echo
              '
              <option  value="A+">A+</option>
              <option value="A-">A-</option>
              <option value="B+">B+</option>
              <option value="B-">B-</option>
              <option value="O+">O+</option>
              <option selected value="O-">O-</option>
              ';

                break;
    default:
      # code...
      break;
  }



   ?>

</select>
</div>
</div>

</div>
<br/>
<div class="row">
<div class="col-md-4">
<label>Gender</label>
</div>
<div class="col-md-8">
<div class="input-group input-group-merge input-group-alternative">

<select class="form-control" name="gender" id="exampleFormControlSelect1">
<?php
switch ($row['gender']) {
  case 'Male':
  echo '<option selected value="Male">Male</option>';
  echo '<option value="Female">Female</option>';
    break;
    case 'Female':
    echo '<option value="Male">Male</option>';
    echo '<option selected  value="Female">Female</option>';
      break;
  default:
    # code...
    break;
}



 ?>


</select>
</div>
</div>

</div>


<br/>
<div class="row">
<div class="col-md-8">
<div  id="res-label"></div>
</div>
<div class="col-md-4">
<div class="form-group mb-3">
<div class="input-group input-group-merge input-group-alternative">
  <input class="form-control btn-default" value="Update" placeholder="Email" type="submit">
</div>
</div>
</div>

</div>
</form>

</div>




    </div>

</div>
</div>
<script>
$(document).ready(function (){
  var stfrm = $('#edit-par-form');

      stfrm.submit(function (e) {

          e.preventDefault();
          var  process_url = "../../processes/admin/edit-parents.php";
          $.ajax({

              url: process_url,
              type: "POST",             // Type of request to be send, called as method
              data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
              contentType: false,
              dataType: 'json',       // The content type used when sending data to the server.
              cache: false,
             // encode: true;           // To unable request pages to be cached
              processData:false,
              beforeSend: function() {
                  $("#res-label").html("<div class='alert alert-info' role='alert'>Please wait..........</div>");
               },
              success: function (data) {
                if(data.code == 1){
                  //  alert(data.message);
                frm.trigger("reset");
                 $("#res-label").html("");
                 $("#res-label").html("<div class='alert alert-success' role='alert'>"+data.message+"</div>");
                 setTimeout(function(){
                    $("#res-label").html("");
                 },3000);
              }
              else{
                alert(data.message);
                 $("#res-label").html("");
                 $("#res-label").html("<div class='alert alert-danger' role='alert'>"+data.message+"</div>");
                 setTimeout(function(){
                    $("#res-label").html("");
                 },3000);
              }


              },
              error: function (data) {
                //  console.log('An error occurred.');
                  console.log(data);
              },
          });
      });

});
</script>

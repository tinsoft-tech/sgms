
  <tr id="mytr<?php echo $row['id'] ;?>">

        <th scope="col" class="sort" data-sort="status"><?php echo $row['subject'];?></th>
        <th scope="col" class="sort" data-sort="name"><?php echo $row['class_name'];?></th>
          <th scope="col" class="sort" data-sort="name"><?php echo $row['section'];?></th>
          <th scope="col" class="sort" data-sort="status"><?php echo $row['instructor'];?></th>
        <th scope="col" class="sort" data-sort="budget"><?php echo $row['class_time'];?></th>


        <th scope="col" class="sort" data-sort="status"><?php echo $row['date'];?></th>
        <th scope="col" class="sort" data-sort="name">
        <button class="btn btn-sm btn-info edit-class" data-toggle="modal" id="<?php echo $row['id'] ;?>" data-target="#classeditmodal-form">edit</button>
        <button class="btn btn-sm btn-danger delete-class" id="<?php echo $row['id'] ;?>">delete</button>
        </th>
    </tr>

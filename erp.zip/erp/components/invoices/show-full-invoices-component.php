<?php
switch ($row['invoice_type']) {
  case '1':
  $re = "Tuition fees";
    break;
    case '2':
    $re = "Exam fees";
      break;
  default:
    // code...
    break;
}
switch ($row['status']) {
  case '0':
  $id = $row['id'] ;
  $btn = "<button class='btn btn-sm btn-danger'>unpaid</button>";
    break;
    case '1':
    $btn = '<button class="btn btn-sm btn-success">paid</button>';
      break;
  default:
    // code...
    break;
}
?>
  <tr  id="mytr<?php echo $row['id'] ;?>">
  <th scope="col" class="sort" data-sort="status"><?php echo $row['invoice_no'];?></th>

    <th scope="col" id="type<?php echo $row['id'] ;?>" class="sort" data-sort="status"><?php echo $re;?></th>
      <th scope="col" id="amount<?php echo $row['id'] ;?>" class="sort" data-sort="status">&#8358;<?php echo $row['amount'];?></th>
        <th scope="col" class="sort" data-sort="status"><?php echo $row['session'];?></th>
        <th scope="col" class="sort" data-sort="name"><?php echo $row['term'];?></th>
          <th scope="col" class="sort" data-sort="status"><?php echo $row['class'];?></th>
          <th scope="col" class="sort" data-sort="name"><?php echo $row['admission_id'];?></th>
        <th scope="col" class="sort" data-sort="budget"><?php echo $row['created'];?></th>
        <th scope="col" class="sort" data-sort="status">
<?php echo $btn;?>

          </th>
<th scope="col" class="sort" data-sort="status">
<button id="<?php echo $row['id'] ;?>" class='btn btn-sm btn-danger del-inv'>delete</button>
</th>


    </tr>

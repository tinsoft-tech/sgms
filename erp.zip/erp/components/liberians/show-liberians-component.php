
<tr id="mytr<?php echo $row['id'] ;?>">

<th scope="col" class="sort" data-sort="name">
<a href="#" class="avatar rounded-circle mr-3">


                              <img style="width:50px;height:50px;" src="../../<?php echo $row['passport'] ;?>">


                        </a>
</th>
      <th scope="col" class="sort" data-sort="name"><?php echo $fullname;?></th>
      <th scope="col" class="sort" data-sort="budget"><?php echo $row['gender'] ;?></th>
        <th scope="col" class="sort" data-sort="status"><?php echo $row['email'] ;?></th>
      <th scope="col" class="sort" data-sort="name"><?php echo $row['address'] ;?></th>
      <th scope="col" class="sort" data-sort="name"><?php echo $row['phone'] ;?></th>

      <th scope="col" class="sort" data-sort="name">
      <button class="btn btn-sm btn-info edit-lib" data-toggle="modal" id="<?php echo $row['id'] ;?>" data-target="#leditmodal-form">edit</button>
      <button class="btn btn-sm btn-danger delete-lib" id="<?php echo $row['id'] ;?>">delete</button>
      </th>
  </tr>

<?php $percentage = round($row['percentage']);
switch ($row['report_type']) {
  case '1':
  $re = "Exam";
    break;
    case '2':
    $re = "C.A Test";
      break;
  default:
    // code...
    break;
}

?>
  <tr  id="mytr<?php echo $row['id'] ;?>">

        <th scope="col" class="sort" data-sort="status"><?php echo $row['session'];?></th>
        <th scope="col" class="sort" data-sort="name"><?php echo $row['term'];?></th>
          <th scope="col" class="sort" data-sort="name"><?php echo $row['admission_id'];?></th>
          <th scope="col" class="sort" data-sort="status"><?php echo $re;?></th>
        <th scope="col" class="sort" data-sort="budget"><?php echo $row['subject'];?></th>
        <th scope="col" class="sort" data-sort="status"><?php echo $row['score'];?></th>
        <th scope="col" class="sort" data-sort="status"><?php echo $percentage;?>%</th>

    </tr>

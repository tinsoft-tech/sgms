<tr>
<th scope="row">
<span class="avatar avatar-sm rounded-circle">
<img style="width:40px;height:40px;" src="../../<?php echo $row['passport'] ;?>">
</span>
</th>
<td>
<?php echo $fullname;?>
</td>
</tr>

<?php
switch ($row['invoice_type']) {
  case '1':
  $re = "Tuition fees";
    break;
    case '2':
    $re = "Exam fees";
      break;
  default:
    // code...
    break;
}
/*switch ($row['status']) {
  case '0':
  $id = $row['id'] ;
  $btn = "<button data-toggle='modal' id='$id' data-target='#modal-form' class='btn pay-fee btn-sm btn-danger'>pay</button>";
    break;
    case '1':
    $btn = '<button class="btn btn-sm btn-success">paid</button>';
      break;
  default:
    // code...
    break;
}
*/
?>
  <tr  id="mytr<?php echo $row['id'] ;?>">
      <th scope="col" class="sort" data-sort="status"><?php echo $row['reference_no'];?></th>
  <th scope="col" class="sort" data-sort="status"><?php echo $row['invoice_no'];?></th>

    <th scope="col" id="type<?php echo $row['id'] ;?>" class="sort" data-sort="status"><?php echo $re;?></th>
      <th scope="col" id="amount<?php echo $row['id'] ;?>" class="sort" data-sort="status">&#8358;<?php echo $row['amount'];?></th>
        <th scope="col" class="sort" data-sort="status"><?php echo $row['session'];?></th>
        <th scope="col" class="sort" data-sort="name"><?php echo $row['term'];?></th>

        <th scope="col" class="sort" data-sort="budget"><?php echo $row['created'];?></th>




    </tr>

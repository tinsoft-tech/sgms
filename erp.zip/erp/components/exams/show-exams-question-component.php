<?php
$caps = strtoupper($row["question"]);
 ?>

<form id="myform<?php echo $row["id"];?>" method="post" action="../../processes/student/submit-ca.php">
  <tr>
    <input type="hidden" name="q_number" value="<?php echo $row["id"];?>"/>
    <input type="hidden" name="exam_id" value="<?php echo $row["exam_id"];?>"/>
      <input type="hidden" id="subjectt" value="<?php echo $rarow["subject_name"];?>"/>
      <input type="hidden" id="session" value="<?php echo $rarow["exam_session"];?>"/>
        <input type="hidden" id="term" value="<?php echo $rarow["exam_term"];?>"/>

    <input type="hidden" name="admission_id" value="<?php echo $_SESSION["LOGGED_IN_ADMID"];?>"/>
    <th scope="col" style="width:3px !important;" class="sort" data-sort="budget"><b><?php echo $count;?></b></th>
    <th scope="col" class="sort" data-sort="status">
      <b><label style="font-size:16px;"><?php echo $caps;?></label></b>
      <br/>

      <div class="form-check form-check-inline">
        <label class="form-check-label" for="exampleRadios1">
      A :
        </label>
<input class="form-check-input" onchange="Inc(<?php echo $row["id"];?>)" type="radio" name="answer" id="check<?php echo $row["id"];?>" value="a">
<label class="form-check-label" for="exampleRadios1">
<?php echo $arow["option_a"];?>
</label>
</div>
<div class="form-check form-check-inline">
  <label class="form-check-label" for="exampleRadios1">
B :
  </label>
<input class="form-check-input" onchange="Inc(<?php echo $row["id"];?>)" type="radio" name="answer" id="check<?php echo $row["id"];?>" value="b">
<label class="form-check-label" for="exampleRadios2">
<?php echo $arow["option_b"];?>
</label>
</div>
<div class="form-check form-check-inline">
  <label class="form-check-label" for="exampleRadios1">
C :
  </label>
<input class="form-check-input" onchange="Inc(<?php echo $row["id"];?>)" type="radio" name="answer" id="check<?php echo $row["id"];?>" value="c">
<label class="form-check-label" for="exampleRadios1">
<?php echo $arow["option_c"];?>
</label>
</div>
<div class="form-check form-check-inline">
  <label class="form-check-label" for="exampleRadios1">
D :
  </label>
<input class="form-check-input" onchange="Inc(<?php echo $row["id"];?>)" type="radio" name="answer" id="check<?php echo $row["id"];?>" value="d">
<label class="form-check-label" for="exampleRadios2">
<?php echo $arow["option_d"];?>
</label>
</div>

    </th>

  </tr>
</form>


<?php
if($percent < 50)
{
  $bg = "bg-danger";
}
else{
  $bg = "bg-success";
}
?>
<div id="progress-div">
<div class="progress">
  <div class="progress-bar <?php echo $bg?>" role="progressbar" aria-valuenow="<?php echo $cent;?>" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $cent; ?>"></div>

</div>
<label class="form-check-label">
Your Score is <?php echo $count;?>
</label>
</div>

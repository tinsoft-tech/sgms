
  <tr id="mytr<?php echo $row['id'] ;?>">

        <th scope="col" class="sort" data-sort="status"><?php echo $row['subject_name'];?></th>
        <th scope="col" class="sort" data-sort="name"><?php echo $row['exam_class'];?></th>
          <th scope="col" class="sort" data-sort="name"><?php echo $row['exam_session'];?></th>
          <th scope="col" class="sort" data-sort="status"><?php echo $row['exam_term'];?></th>
        <th scope="col" class="sort" data-sort="budget"><?php echo $row['exam_time'];?></th>


        <th scope="col" class="sort" data-sort="status"><?php echo $row['date'];?></th>
        <th scope="col" class="sort" data-sort="name">
        <button class="btn btn-sm btn-info take-exam" data-toggle="modal" id="<?php echo $row['id'] ;?>" data-target="#exammodal-form">write</button>

        </th>
    </tr>

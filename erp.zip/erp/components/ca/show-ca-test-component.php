
  <tr id="mytr<?php echo $row['id'] ;?>">

        <th scope="col" class="sort" data-sort="status"><?php echo $row['subject_name'];?></th>
        <th scope="col" class="sort" data-sort="name"><?php echo $row['ca_class'];?></th>
          <th scope="col" class="sort" data-sort="name"><?php echo $row['ca_session'];?></th>
          <th scope="col" class="sort" data-sort="status"><?php echo $row['ca_term'];?></th>
        <th scope="col" class="sort" data-sort="budget"><?php echo $row['ca_time'];?></th>


        <th scope="col" class="sort" data-sort="status"><?php echo $row['date'];?></th>
        <th scope="col" class="sort" data-sort="name">
        <button class="btn btn-sm btn-info take-ca" data-toggle="modal" id="<?php echo $row['id'] ;?>" data-target="#camodal-form">take</button>

        </th>
    </tr>

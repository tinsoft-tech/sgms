<form id="myform<?php echo $row["question_number"];?>" method="post" action="../../processes/student/submit-ca.php">
  <tr>
    <input type="hidden" name="q_number" value="<?php echo $row["question_number"];?>"/>
    <input type="hidden" name="ca_id" value="<?php echo $row["ca_id"];?>"/>
    <input type="hidden" name="admission_id" value="<?php echo $_SESSION["LOGGED_IN_ADMID"];?>"/>
    <th scope="col" style="width:3px !important;" class="sort" data-sort="budget"><b><?php echo $row["question_number"];?></b></th>
    <th scope="col" class="sort" data-sort="status">
      <b><label style="font-size:16px;"><?php echo $row["question"];?></label></b>
      <div class="input-group input-group-merge input-group-alternative">

        <textarea class="form-control" style="border:0px !important;" name="answer"  placeholder="Enter Answer"></textarea>
      </div>
    </th>


    <th scope="col" class="sort" data-sort="name"><b><?php echo $row["mark"];?></b></th>
  </tr>
</form>

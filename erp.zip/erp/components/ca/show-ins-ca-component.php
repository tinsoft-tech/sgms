
  <tr id="mytr<?php echo $row['id'] ;?>">

        <th scope="col" class="sort" data-sort="status"><?php echo $row['subject_name'];?></th>
        <th scope="col" class="sort" data-sort="name"><?php echo $row['ca_class'];?></th>
          <th scope="col" class="sort" data-sort="name"><?php echo $row['ca_session'];?></th>
          <th scope="col" class="sort" data-sort="status"><?php echo $row['ca_term'];?></th>
        <th scope="col" class="sort" data-sort="budget"><?php echo $row['ca_time'];?></th>


        <th scope="col" class="sort" data-sort="status"><?php echo $row['date'];?></th>
        <th scope="col" class="sort" data-sort="name">
          <a class="btn btn-sm btn-primary" href="view-submitted-ca-test.php?id=<?php echo $row['id'] ;?>">view submitted</a>
        <a class="btn btn-sm btn-primary" href="view-submitted-ca-test.php?id=<?php echo $row['id'] ;?>">view submitted</a>
        </th>
    </tr>

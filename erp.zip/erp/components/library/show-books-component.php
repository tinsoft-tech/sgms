<!-- Light table -->


                  <tr>
                    <th scope="row">
                      <div class="media align-items-center">
                        <a href="#" class="avatar mr-3">
                          <img alt="Image placeholder" src="../../<?php echo  $row["cover"];?>">
                        </a>
                        <div class="media-body">
                          <span class="namee mb-0 text-sm"><?php echo  $row["title"];?></span>
                        </div>
                      </div>
                    </th>
                    <td class="budget">
                      <?php echo  $row["author"];?>
                    </td>
                    <td>
                      <span class="badge badge-dot mr-4">
                        <i class="bg-warning"></i>
                        <span class="status"><?php echo  $row["category"];?></span>
                      </span>
                    </td>
                    <td>
                        <?php echo  $row["publisher"];?>
                    </td>
                    <td>
                      <div class="d-flex align-items-center">
                        <?php echo  $row["isbn"];?>
                      </div>
                    </td>
                    <td class="text-right">
                    <a href="../../<?php echo  $row['url'];?>"  class="btn btn-default btn-sm">download</a>
                    </td>
                  </tr>

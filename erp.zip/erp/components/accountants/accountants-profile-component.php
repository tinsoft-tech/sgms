<form>
  <h6 class="heading-small text-muted mb-4">User information</h6>
  <div class="pl-lg-4">

    <div class="row">
      <div class="col-lg-4">
        <div class="form-group">
          <label class="form-control-label" for="input-first-name">First name</label>
          <input type="text" id="input-first-name" class="form-control" placeholder="First name" value="<?php echo $row["firstname"]; ?>">
        </div>
      </div>
      <div class="col-lg-4">
        <div class="form-group">
          <label class="form-control-label" for="input-last-name">Middle name</label>
          <input type="text" id="input-middle-name" class="form-control" placeholder="Last name" value="<?php echo $row["middlename"]; ?>">
        </div>
      </div>
      <div class="col-lg-4">
        <div class="form-group">
          <label class="form-control-label" for="input-last-name">Last name</label>
          <input type="text" id="input-last-name" class="form-control" placeholder="Last name" value="<?php echo $row["lastname"]; ?>">
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-4">
        <div class="form-group">
          <label class="form-control-label" for="input-first-name">Bloodgroup</label>
          <input type="text" id="input-first-name" class="form-control" placeholder="First name" value="<?php echo $row["bloodgroup"]; ?>">
        </div>
      </div>
      <div class="col-lg-4">
        <div class="form-group">
          <label class="form-control-label" for="input-last-name">Religion</label>
          <input type="text" id="input-middle-name" class="form-control" placeholder="Last name" value="<?php echo $row["religion"]; ?>">
        </div>
      </div>
      <div class="col-lg-4">
        <div class="form-group">
          <label class="form-control-label" for="input-first-name">Gender</label>
          <input type="text" id="input-first-name" class="form-control" placeholder="First name" value="<?php echo $row["gender"]; ?>">
        </div>
      </div>

    </div>

  </div>
  <hr class="my-4" />
  <!-- Address -->
  <h6 class="heading-small text-muted mb-4">Contact information</h6>
  <div class="pl-lg-4">
    <div class="row">
      <div class="col-md-12">
        <div class="form-group">
          <label class="form-control-label" for="input-address">Address</label>
          <input id="input-address" class="form-control" placeholder="Home Address" value="<?php echo $row["address"]; ?>" type="text">
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-4">
        <div class="form-group">
          <label class="form-control-label" for="input-city">Phone</label>
          <input type="text" id="input-phone" class="form-control" placeholder="Phone" value="<?php echo $row["phone"]; ?>">
        </div>
      </div>
      <div class="col-lg-4">
        <div class="form-group">
          <label class="form-control-label" for="input-country">Email</label>
          <input type="email" id="input-email" class="form-control" placeholder="Country" value="<?php echo $row["email"]; ?>">
        </div>
      </div>
      <div class="col-lg-4">
        <div class="form-group">
          <label class="form-control-label" for="input-country">Country</label>
          <input type="text" id="input-postal-code" value="Nigeria" class="form-control" placeholder="Postal code">
        </div>
      </div>
    </div>
  </div>
  <hr class="my-4" />
  <!-- Description -->


</form>

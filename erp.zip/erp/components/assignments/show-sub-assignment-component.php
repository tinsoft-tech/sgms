<?php
$res ="";
switch ($row['status']) {
  case '0':
  $res = "pending";
    break;
  case '1':
  $res = "marked";
      break;
  case '2':
  $res = "settled";
      break;
  default:
    // code...
    break;
}
 ?>
<tr id="mytr<?php echo $row['id'] ;?>">

  <th scope="col" class="sort" data-sort="name"><?php echo $row['assignment_name'] ;?></th>

  <th scope="col" class="sort" data-sort="status" id="<?php echo $row['id'] ;?>"><?php echo $row['admission_id'] ;?></th>
  <th scope="col" class="sort" data-sort="completion"><?php echo $row['submitted_date'] ;?></th>
  <th scope="col"><?php echo $row['deadline'] ;?></th>
  <th scope="col"><?php echo   $res; ?></th>
  <th scope="col" class="text-right"><a href="../../<?php echo $row['answer_url'];?>"  class="btn  btn-sm btn-success">view</a>
<button id="<?php echo $row['id'] ?>" class="btn delsub btn-sm btn-danger">delete</button>  </th>
</tr>

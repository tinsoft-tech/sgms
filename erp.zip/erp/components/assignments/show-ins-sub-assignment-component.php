<?php
$res ="";
$id = $row["id"];
$mark ="";
switch ($row['status']) {
  case '0':
  $res = "pending";
  $mark = "<input type='text' id='mark$id'  style='border-bottom:1px solid gainsboro;border:none;padding:5px;width:45px;' placeholder='score'/><button id='$id' class='sub-report btn btn-sm btn-primary'>mark</button>";
    break;
  case '1':
  $res = "marked";
  $mark = $res;
      break;
  case '2':
  $res = "settled";
  $mark = $res;
      break;
  default:
    // code...
    break;
}
 ?>
<tr id="mytr<?php echo $row['id'] ;?>">

  <th scope="col" class="sort" data-sort="name"><?php echo $row['assignment_name'] ;?></th>
<input type="hidden" id="adm<?php echo $row['id'] ;?>" value="<?php echo $row['admission_id'] ;?>"/>
<input type="hidden" id="ass<?php echo $row['id'] ;?>" value="<?php echo $row['assignment_id'] ;?>"/>
<input type="hidden" id="total<?php echo $row['id'] ;?>" value="<?php echo $row['score'] ;?>"/>
<input type="hidden" id="report<?php echo $row['id'] ;?>" value="2"/>
<input type="hidden" id="subject<?php echo $row['id'] ;?>" value="<?php echo $row['subject'] ;?>"/>
<input type="hidden" id="session<?php echo $row['id'] ;?>" value="2020/2021"/>
<input type="hidden" id="term<?php echo $row['id'] ;?>" value="1st Term"/>

  <th scope="col" class="sort" data-sort="status" id="<?php echo $row['id'] ;?>"><?php echo $row['admission_id'] ;?></th>
  <th scope="col" class="sort" data-sort="completion"><?php echo $row['submitted_date'] ;?></th>
  <th scope="col"><?php echo $row['deadline'] ;?></th>
  <th scope="col" id="sa<?php echo $row['id'] ?>"><?php echo   $res; ?></th>
  <th scope="col" class="text-right"><a href="../../<?php echo $row['answer_url'];?>"  class="btn  btn-sm btn-success">view</a>
<button id="<?php echo $row['id'] ?>" class="btn delsub btn-sm btn-danger">delete</button>  </th>
  <th scope="col" id="ma<?php echo $row['id'] ?>">

    <?php echo  $mark;?>

  </th>
</tr>

<tr id="mytr<?php echo $row['id'] ;?>">
  <th scope="col" class="sort" data-sort="name"><?php echo $row['subject'] ;?></th>

  <th scope="col" class="sort" data-sort="status" id="myassign_name<?php echo $row['id'] ;?>"><?php echo $row['assignment_name'] ;?></th>
  <th scope="col"><?php echo $row['class'] ;?></th>
  <th scope="col" class="sort" data-sort="completion"><?php echo $row['section'] ;?></th>
  <th scope="col"><?php echo $row['deadline'] ;?></th>
  <th scope="col" class="text-right"><a href="../../<?php echo $row['question_url'];?>" class="btn  btn-sm btn-primary">download</a>
<button id="<?php echo $row['id'] ;?>" type="button" data-toggle="modal" data-target="#uploadmodal-form" class="sub-assign btn  btn-sm btn-success">submit</button>
  </th>
</tr>

<tr id="mytr<?php echo $row['id'] ;?>">
  <th scope="col" class="sort" data-sort="name"><?php echo $row['subject'] ;?></th>

  <th scope="col" class="sort" data-sort="status" id="myassign_name<?php echo $row['id'] ;?>"><?php echo $row['assignment_name'] ;?></th>
  <th scope="col"><?php echo $row['class'] ;?></th>
  <th scope="col" class="sort" data-sort="completion"><?php echo $row['section'] ;?></th>
  <th scope="col"><?php echo $row['deadline'] ;?></th>
  <th scope="col" class="text-right"><a href="submitted-assignments.php?id=<?php echo $row['id'];?>" class="btn  btn-sm btn-primary">view submitted</a>
  </th>
</tr>

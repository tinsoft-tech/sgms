var frm = $('#instructor-form');

    frm.submit(function (e) {

        e.preventDefault();
        var  process_url = "../../processes/admin/add-instructors.php";
        $.ajax({

            url: process_url,
            type: "POST",             // Type of request to be send, called as method
            data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
            contentType: false,
            dataType: 'json',       // The content type used when sending data to the server.
            cache: false,
           // encode: true;           // To unable request pages to be cached
            processData:false,
            beforeSend: function() {
                $("#in_response_div").html("<div class='alert alert-info' role='alert'>Please wait..........</div>");
             },
            success: function (data) {
              if(data.code == 1){
              frm.trigger("reset");
               $("#in_response_div").html("");
               $("#in_response_div").html("<div class='alert alert-success' role='alert'>"+data.message+"</div>");
               setTimeout(function(){
                  $("#in_response_div").html("");
               },3000);
            }
            else{
               $("#in_response_div").html("");
               $("#in_response_div").html("<div class='alert alert-danger' role='alert'>"+data.message+"</div>");
               setTimeout(function(){
                  $("#in_response_div").html("");
               },3000);
            }


            },
            error: function (data) {
              //  console.log('An error occurred.');
                console.log(data);
            },
        });
    });



    var searchlastname  = $("#ilastname");
    searchlastname.keydown(function(){
      var  process_url = "../../processes/admin/searchinstructors.php";
      var Lastname = $(this).val();
      var formData = {'searchkey' : Lastname,'id' : '1'};
      $.ajax({

          url: process_url,
          type: "POST",             // Type of request to be send, called as method
          data: formData, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                  // To unable request pages to be cached
          beforeSend: function() {
              $("#instructor_response_div").html("<div class='spinner-border text-primary' role='status'><span class='sr-only'>Loading...</span></div>");
           },
          success: function (data) {
           $("#instructor_response_div").html(data);


          },
          error: function (data) {
            //  console.log('An error occurred.');
              console.log(data);
          },
      });
    });

    var searchclass  = $("#iclass");
    searchclass.change(function(){
      var  process_url = "../../processes/admin/searchinstructors.php";
     var selectedclass = $(this).children("option:selected").val();
      var formData = {'searchkey' : selectedclass,'id' : '2'};
      $.ajax({

          url: process_url,
          type: "POST",             // Type of request to be send, called as method
          data: formData, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                  // To unable request pages to be cached
          beforeSend: function() {
              $("#instructor_response_div").html("<div class='spinner-border text-primary' role='status'><span class='sr-only'>Loading...</span></div>");
           },
          success: function (data) {
           $("#instructor_response_div").html(data);


          },
          error: function (data) {
            //  console.log('An error occurred.');
              console.log(data);
          },
      });
    });

    var searchgender  = $("#igender");
    searchgender.change(function(){
      var  process_url = "../../processes/admin/searchinstructors.php";
     var selectedgender = $(this).children("option:selected").val();
      var formData = {'searchkey' : selectedgender,'id' : '3'};
      $.ajax({

          url: process_url,
          type: "POST",             // Type of request to be send, called as method
          data: formData, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                  // To unable request pages to be cached
          beforeSend: function() {
              $("#instructor_response_div").html("<div class='spinner-border text-primary' role='status'><span class='sr-only'>Loading...</span></div>");
           },
          success: function (data) {
           $("#instructor_response_div").html(data);


          },
          error: function (data) {
            //  console.log('An error occurred.');
              console.log(data);
          },
      });
    });



    var reset  = $("#iresetbtn");
    reset.click(function(){
      var  process_url = "../../processes/admin/searchinstructors.php";
      //var Lastname = $(this).val();
      var formData = {'id' : '0'};
      $.ajax({

          url: process_url,
          type: "POST",             // Type of request to be send, called as method
          data: formData, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                  // To unable request pages to be cached
          beforeSend: function() {
              $("#instructor_response_div").html("<div class='spinner-border text-primary' role='status'><span class='sr-only'>Loading...</span></div>");
           },
          success: function (data) {
           $("#instructor_response_div").html(data);


          },
          error: function (data) {
            //  console.log('An error occurred.');
              console.log(data);
          },
      });
    });

  /*  $('#response_div').on('click', '.edit-stud', function() {
        // Do something on an existent or future .dynamicElement
    });

*/
      //  var searchlastname  = $("#lastname");
        $('#instructor_response_div').on('click', '.edit-inst', function() {
          var  process_url = "../../processes/admin/searchinstructors.php";
          var fy = $(this).attr("id");
          var formData = {'studid' : fy,'id':'4'};
          $.ajax({

              url: process_url,
              type: "POST",             // Type of request to be send, called as method
              data: formData, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                      // To unable request pages to be cached
              beforeSend: function() {
                  $("#editshowdiv").html("<div class='spinner-border text-primary' role='status'><span class='sr-only'>Loading...</span></div>");
               },
              success: function (data) {
               $("#editshowdiv").html(data);


              },
              error: function (data) {
                //  console.log('An error occurred.');
                  console.log(data);
              },
          });
        });



        $('#instructor_response_div').on('click', '.delete-inst', function() {
          var  process_url = "../../processes/admin/delete-instructors.php";
          var fy = $(this).attr("id");
          var formData = {'id' : fy};
          var answer = prompt("Do you want to delete this instructor , Confirm by typing yes?");
          if(answer == "yes"){
            $.ajax({

                url: process_url,
                type: "POST",             // Type of request to be send, called as method
                data: formData, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                        // To unable request pages to be cached
                beforeSend: function() {
                  //  $("#editshowdiv").html("<div class='spinner-border text-primary' role='status'><span class='sr-only'>Loading...</span></div>");
                 },
                success: function (data) {
                 $("#mytr"+fy).remove();


                },
                error: function (data) {
                  //  console.log('An error occurred.');
                    console.log(data);
                },
            });
          }
          else{

          }
        });

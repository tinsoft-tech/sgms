var frm = $('#class-form');

    frm.submit(function (e) {

        e.preventDefault();
        var  process_url = "../../processes/admin/add-class-routines.php";
        $.ajax({

            url: process_url,
            type: "POST",             // Type of request to be send, called as method
            data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
            contentType: false,
            dataType: 'json',       // The content type used when sending data to the server.
            cache: false,
           // encode: true;           // To unable request pages to be cached
            processData:false,
            beforeSend: function() {
                $("#class_response_div").html("<div class='alert alert-info' role='alert'>Please wait..........</div>");
             },
            success: function (data) {
              if(data.code == 1){
              frm.trigger("reset");
               $("#class_response_div").html("");
               $("#class_response_div").html("<div class='alert alert-success' role='alert'>"+data.message+"</div>");
               setTimeout(function(){
                  $("#class_response_div").html("");
               },3000);
            }
            else{
               $("#class_response_div").html("");
               $("#class_response_div").html("<div class='alert alert-danger' role='alert'>"+data.message+"</div>");
               setTimeout(function(){
                  $("#class_response_div").html("");
               },3000);
            }


            },
            error: function (data) {
              //  console.log('An error occurred.');
                console.log(data);
            },
        });
    });




    var searchclass  = $("#class");
    searchclass.change(function(){
      var  process_url = "../../processes/admin/searchclassroutine.php";
     var selectedclass = $(this).children("option:selected").val();
      var formData = {'searchkey' : selectedclass,'id' : '2'};
      $.ajax({

          url: process_url,
          type: "POST",             // Type of request to be send, called as method
          data: formData, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                  // To unable request pages to be cached
          beforeSend: function() {
              $("#class_response_div").html("<div class='spinner-border text-primary' role='status'><span class='sr-only'>Loading...</span></div>");
           },
          success: function (data) {
           $("#class_response_div").html(data);


          },
          error: function (data) {
            //  console.log('An error occurred.');
              console.log(data);
          },
      });
    });



    var reset  = $("#resetbtn");
    reset.click(function(){
      var  process_url = "../../processes/admin/searchclassroutine.php";
      //var Lastname = $(this).val();
      var formData = {'id' : '0'};
      $.ajax({

          url: process_url,
          type: "POST",             // Type of request to be send, called as method
          data: formData, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                  // To unable request pages to be cached
          beforeSend: function() {
              $("#class_response_div").html("<div class='spinner-border text-primary' role='status'><span class='sr-only'>Loading...</span></div>");
           },
          success: function (data) {
           $("#class_response_div").html(data);


          },
          error: function (data) {
            //  console.log('An error occurred.');
              console.log(data);
          },
      });
    });

  /*  $('#class_response_div').on('click', '.edit-stud', function() {
        // Do something on an existent or future .dynamicElement
    });

*/
      //  var searchlastname  = $("#lastname");
        $('#class_response_div').on('click', '.edit-class', function() {
          var  process_url = "../../processes/admin/searchclassroutine.php";
          var fy = $(this).attr("id");
          var formData = {'studid' : fy,'id':'4'};
          $.ajax({

              url: process_url,
              type: "POST",             // Type of request to be send, called as method
              data: formData, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                      // To unable request pages to be cached
              beforeSend: function() {
                  $("#editshowdiv").html("<div class='spinner-border text-primary' role='status'><span class='sr-only'>Loading...</span></div>");
               },
              success: function (data) {
               $("#editshowdiv").html(data);


              },
              error: function (data) {
                //  console.log('An error occurred.');
                  console.log(data);
              },
          });
        });



        $('#class_response_div').on('click', '.delete-class', function() {
          var  process_url = "../../processes/admin/delete-class-routine.php";
          var fy = $(this).attr("id");
          var formData = {'id' : fy};
          var answer = prompt("Do you want to delete this routine , Confirm by typing yes?");
          if(answer == "yes"){
            $.ajax({

                url: process_url,
                type: "POST",             // Type of request to be send, called as method
                data: formData, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                        // To unable request pages to be cached
                beforeSend: function() {
                  //  $("#editshowdiv").html("<div class='spinner-border text-primary' role='status'><span class='sr-only'>Loading...</span></div>");
                 },
                success: function (data) {
                 $("#mytr"+fy).remove();


                },
                error: function (data) {
                  //  console.log('An error occurred.');
                    console.log(data);
                },
            });
          }
          else{

          }
        });

var frm = $('#accountant-form');

    frm.submit(function (e) {

        e.preventDefault();
        var  process_url = "../../processes/admin/add-accountants.php";
        $.ajax({

            url: process_url,
            type: "POST",             // Type of request to be send, called as method
            data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
            contentType: false,
            dataType: 'json',       // The content type used when sending data to the server.
            cache: false,
           // encode: true;           // To unable request pages to be cached
            processData:false,
            beforeSend: function() {
                $("#acct_response_div").html("<div class='alert alert-info' role='alert'>Please wait..........</div>");
             },
            success: function (data) {
              if(data.code == 1){
              frm.trigger("reset");
               $("#acct_response_div").html("");
               $("#acct_response_div").html("<div class='alert alert-success' role='alert'>"+data.message+"</div>");
               setTimeout(function(){
                  $("#acct_response_div").html("");
               },3000);
            }
            else{
               $("#acct_response_div").html("");
               $("#acct_response_div").html("<div class='alert alert-danger' role='alert'>"+data.message+"</div>");
               setTimeout(function(){
                  $("#acct_response_div").html("");
               },3000);
            }


            },
            error: function (data) {
              //  console.log('An error occurred.');
                console.log(data);
            },
        });
    });



        $('#accountant_response_div').on('click', '.edit-acct', function() {
          var  process_url = "../../processes/admin/searchaccountants.php";
          var fy = $(this).attr("id");
          var formData = {'studid' : fy,'id':'4'};
          $.ajax({

              url: process_url,
              type: "POST",             // Type of request to be send, called as method
              data: formData, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                      // To unable request pages to be cached
              beforeSend: function() {
                  $("#editshowdiv").html("<div class='spinner-border text-primary' role='status'><span class='sr-only'>Loading...</span></div>");
               },
              success: function (data) {
               $("#editshowdiv").html(data);


              },
              error: function (data) {
                //  console.log('An error occurred.');
                  console.log(data);
              },
          });
        });



        $('#accountant_response_div').on('click', '.delete-acct', function() {
          var  process_url = "../../processes/admin/delete-accountants.php";
          var fy = $(this).attr("id");
          var formData = {'id' : fy};
          var answer = prompt("Do you want to delete this accountant , Confirm by typing yes?");
          if(answer == "yes"){
            $.ajax({

                url: process_url,
                type: "POST",             // Type of request to be send, called as method
                data: formData, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                        // To unable request pages to be cached
                beforeSend: function() {
                  //  $("#editshowdiv").html("<div class='spinner-border text-primary' role='status'><span class='sr-only'>Loading...</span></div>");
                 },
                success: function (data) {
                 $("#mytr"+fy).remove();


                },
                error: function (data) {
                  //  console.log('An error occurred.');
                    console.log(data);
                },
            });
          }
          else{

          }
        });

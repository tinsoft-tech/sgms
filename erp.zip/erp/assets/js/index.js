ZoomMtg.setZoomJSLib('https://dmogdx0jrul3u.cloudfront.net/1.8.0/lib', '/av');
ZoomMtg.preLoadWasm();
ZoomMtg.prepareJssdk

var frm = $('#liberian-form');

    frm.submit(function (e) {

        e.preventDefault();
        var  process_url = "../../processes/admin/add-liberians.php";
        $.ajax({

            url: process_url,
            type: "POST",             // Type of request to be send, called as method
            data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
            contentType: false,
            dataType: 'json',       // The content type used when sending data to the server.
            cache: false,
           // encode: true;           // To unable request pages to be cached
            processData:false,
            beforeSend: function() {
                $("#lib_response_div").html("<div class='alert alert-info' role='alert'>Please wait..........</div>");
             },
            success: function (data) {
              if(data.code == 1){
              frm.trigger("reset");
               $("#lib_response_div").html("");
               $("#lib_response_div").html("<div class='alert alert-success' role='alert'>"+data.message+"</div>");
               setTimeout(function(){
                  $("#lib_response_div").html("");
               },3000);
            }
            else{
               $("#lib_response_div").html("");
               $("#lib_response_div").html("<div class='alert alert-danger' role='alert'>"+data.message+"</div>");
               setTimeout(function(){
                  $("#lib_response_div").html("");
               },3000);
            }


            },
            error: function (data) {
              //  console.log('An error occurred.');
                console.log(data);
            },
        });
    });



        $('#liberian_response_div').on('click', '.edit-lib', function() {
          var  process_url = "../../processes/admin/searchliberians.php";
          var fy = $(this).attr("id");
          var formData = {'studid' : fy,'id':'4'};
          $.ajax({

              url: process_url,
              type: "POST",             // Type of request to be send, called as method
              data: formData, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                      // To unable request pages to be cached
              beforeSend: function() {
                  $("#editshowdiv").html("<div class='spinner-border text-primary' role='status'><span class='sr-only'>Loading...</span></div>");
               },
              success: function (data) {
               $("#editshowdiv").html(data);


              },
              error: function (data) {
                //  console.log('An error occurred.');
                  console.log(data);
              },
          });
        });

        $('#book-search').on('keydown', function() {
          var  process_url = "../../processes/student/searchbooks.php";
          var fy = $(this).val();
          if(fy.length < 0){
            fy = "all";
          }

          var formData = {'key':fy};
          $.ajax({

              url: process_url,
              type: "POST",             // Type of request to be send, called as method
              data: formData, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                      // To unable request pages to be cached
              beforeSend: function() {

                  $("#show-book-search").html("<div class='spinner-border text-primary' role='status'><span class='sr-only'>Loading...</span></div>");
               },
              success: function (data) {
                  $("#show-book-search").html("");
               $("#show-book-search").html(data);


              },
              error: function (data) {
                //  console.log('An error occurred.');
                  console.log(data);
              },
          });
        });


        $('#liberian_response_div').on('click', '.delete-lib', function() {
          var  process_url = "../../processes/admin/delete-liberians.php";
          var fy = $(this).attr("id");
          var formData = {'id' : fy};
          var answer = prompt("Do you want to delete this liberian , Confirm by typing yes?");
          if(answer == "yes"){
            $.ajax({

                url: process_url,
                type: "POST",             // Type of request to be send, called as method
                data: formData, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                        // To unable request pages to be cached
                beforeSend: function() {
                  //  $("#editshowdiv").html("<div class='spinner-border text-primary' role='status'><span class='sr-only'>Loading...</span></div>");
                 },
                success: function (data) {
                 $("#mytr"+fy).remove();


                },
                error: function (data) {
                  //  console.log('An error occurred.');
                    console.log(data);
                },
            });
          }
          else{

          }
        });

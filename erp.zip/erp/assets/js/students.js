

$("#stud_class").change(function(){
var sel =  $("#stud_class option:selected").text();
switch (sel) {
  case 'SS 1':
  $("#sub_com").removeAttr('disabled');
    break;
  case 'SS 2':
  $("#sub_com").removeAttr('disabled');
    break;
  case 'SS 3':
  $("#sub_com").removeAttr('disabled');
    break;
  default:
$("#sub_com").prop('disabled',true);
}
})

var frm = $('#student-form');

    frm.submit(function (e) {

        e.preventDefault();
        var  process_url = "../../processes/admin/add-students.php";
        $.ajax({

            url: process_url,
            type: "POST",             // Type of request to be send, called as method
            data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
            contentType: false,
            dataType: 'json',       // The content type used when sending data to the server.
            cache: false,
           // encode: true;           // To unable request pages to be cached
            processData:false,
            beforeSend: function() {
                $("#response_div").html("<div class='alert alert-info' role='alert'>Please wait..........</div>");
             },
            success: function (data) {
              if(data.code == 1){
              frm.trigger("reset");
               $("#response_div").html("");
               $("#response_div").html("<div class='alert alert-success' role='alert'>"+data.message+"</div>");
               setTimeout(function(){
                  $("#response_div").html("");
               },3000);
            }
            else{
               $("#response_div").html("");
               $("#response_div").html("<div class='alert alert-danger' role='alert'>"+data.message+"</div>");
               setTimeout(function(){
                  $("#response_div").html("");
               },3000);
            }


            },
            error: function (data) {
              //  console.log('An error occurred.');
                console.log(data);
            },
        });
    });



    var searchlastname  = $("#lastname");
    searchlastname.keydown(function(){
      var  process_url = "../../processes/admin/searchstudents.php";
      var Lastname = $(this).val();
      var formData = {'searchkey' : Lastname,'id' : '1'};
      $.ajax({

          url: process_url,
          type: "POST",             // Type of request to be send, called as method
          data: formData, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                  // To unable request pages to be cached
          beforeSend: function() {
              $("#student_response_div").html("<div class='spinner-border text-primary' role='status'><span class='sr-only'>Loading...</span></div>");
           },
          success: function (data) {
           $("#student_response_div").html(data);


          },
          error: function (data) {
            //  console.log('An error occurred.');
              console.log(data);
          },
      });
    });

    var searchclass  = $("#class");
    searchclass.change(function(){
      var  process_url = "../../processes/admin/searchstudents.php";
     var selectedclass = $(this).children("option:selected").val();
      var formData = {'searchkey' : selectedclass,'id' : '2'};
      $.ajax({

          url: process_url,
          type: "POST",             // Type of request to be send, called as method
          data: formData, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                  // To unable request pages to be cached
          beforeSend: function() {
              $("#student_response_div").html("<div class='spinner-border text-primary' role='status'><span class='sr-only'>Loading...</span></div>");
           },
          success: function (data) {
           $("#student_response_div").html(data);


          },
          error: function (data) {
            //  console.log('An error occurred.');
              console.log(data);
          },
      });
    });

    var searchgender  = $("#gender");
    searchgender.change(function(){
      var  process_url = "../../processes/admin/searchstudents.php";
     var selectedgender = $(this).children("option:selected").val();
      var formData = {'searchkey' : selectedgender,'id' : '3'};
      $.ajax({

          url: process_url,
          type: "POST",             // Type of request to be send, called as method
          data: formData, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                  // To unable request pages to be cached
          beforeSend: function() {
              $("#student_response_div").html("<div class='spinner-border text-primary' role='status'><span class='sr-only'>Loading...</span></div>");
           },
          success: function (data) {
           $("#student_response_div").html(data);


          },
          error: function (data) {
            //  console.log('An error occurred.');
              console.log(data);
          },
      });
    });



    var reset  = $("#resetbtn");
    reset.click(function(){
      var  process_url = "../../processes/admin/searchstudents.php";
      //var Lastname = $(this).val();
      var formData = {'id' : '0'};
      $.ajax({

          url: process_url,
          type: "POST",             // Type of request to be send, called as method
          data: formData, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                  // To unable request pages to be cached
          beforeSend: function() {
              $("#student_response_div").html("<div class='spinner-border text-primary' role='status'><span class='sr-only'>Loading...</span></div>");
           },
          success: function (data) {
           $("#student_response_div").html(data);


          },
          error: function (data) {
            //  console.log('An error occurred.');
              console.log(data);
          },
      });
    });

  /*  $('#response_div').on('click', '.edit-stud', function() {
        // Do something on an existent or future .dynamicElement
    });

*/
      //  var searchlastname  = $("#lastname");
        $('#student_response_div').on('click', '.edit-stud', function() {
          var  process_url = "../../processes/admin/searchstudents.php";
          var fy = $(this).attr("id");
          var formData = {'studid' : fy,'id':'4'};
          $.ajax({

              url: process_url,
              type: "POST",             // Type of request to be send, called as method
              data: formData, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                      // To unable request pages to be cached
              beforeSend: function() {
                  $("#editshowdiv").html("<div class='spinner-border text-primary' role='status'><span class='sr-only'>Loading...</span></div>");
               },
              success: function (data) {
               $("#editshowdiv").html(data);


              },
              error: function (data) {
                //  console.log('An error occurred.');
                  console.log(data);
              },
          });
        });



        $('#student_response_div').on('click', '.delete-stud', function() {
          var  process_url = "../../processes/admin/delete-students.php";
          var fy = $(this).attr("id");
          var formData = {'id' : fy};
          var answer = prompt("Do you want to delete this student , Confirm by typing yes?");
          if(answer == "yes"){
            $.ajax({

                url: process_url,
                type: "POST",             // Type of request to be send, called as method
                data: formData, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                        // To unable request pages to be cached
                beforeSend: function() {
                  //  $("#editshowdiv").html("<div class='spinner-border text-primary' role='status'><span class='sr-only'>Loading...</span></div>");
                 },
                success: function (data) {
                 $("#mytr"+fy).remove();


                },
                error: function (data) {
                  //  console.log('An error occurred.');
                    console.log(data);
                },
            });
          }
          else{

          }
        });

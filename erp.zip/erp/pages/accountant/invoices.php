<?php include "../../layouts/accountant-layouts/header.php";?>

<body>
<?php include "../../layouts/accountant-layouts/sidebar.php";?>
  <!-- Main content -->
  <div class="main-content" id="panel">
  <?php include "../../layouts/accountant-layouts/navigation-bar.php";?>

 <!-- Page content -->
 <div style="margin-top:20px;" class="container-fluid">
   <div style="background:#172B4D;" class="container-fluid d-flex align-items-center">
     <div class="row" style="padding-top:15px;width:100%;">
       <div class="col-lg-7 col-md-10">
         <h1 class="text-white">Hello <?php  echo $_SESSION["FULLNAME"];?></h1>
         <p class="text-white mt-0 mb-5">Welcome to your invoices page.</p>
         <a href="#!" class="btn btn-neutral" style="display:none;">Edit profile</a>
       </div>
     </div>
     <button class="btn btn-sm btn-primary" data-toggle="modal" data-target="#single-modal-form" id="single-btn">Generate Single Invoice</button>
     <button class="btn btn-sm btn-primary" data-toggle="modal" data-target="#multiple-modal-form" id="multiple-btn">Generate Multiple Invoices</button>
   </div>
   <div class="row">

     <div class="col-xl-12 order-xl-1">
       <div class="card">
         <div class="card-header">
           <div class="row align-items-center">
             <div class="col-2">
               <select class="form-control" id="type">
                 <option value="n/a">Select Type</option>
               <option value="1">Tution Fee</option>
               <option value="2">Exam Fee</option>
               </select>
             </div>
             <div class="col-2 text-right">
<select class="form-control" id="session">
  <option value="n/a">Select Session</option>
<option value="2020/2021">2020/2021</option>
<option value="2021/2022">2021/2022</option>
</select>
             </div>
             <div class="col-2 text-right">
<select class="form-control" id="term">
  <option value="n/a">Select Term</option>
<option value="1st term">1st term</option>
<option value="2nd term">2nd term</option>
<option value="3rd term">3rd term</option>
</select>
             </div>
             <div class="col-2 text-right">
<select class="form-control" id="status">
  <option value="n/a">Select Status</option>
<option value="0">Unpaid</option>
<option value="1">Paid</option>
</select>
             </div>
             <div class="col-2 text-right">
<select class="form-control" id="class">
  <option value="n/a">Select Class</option>
  <?php $classes->ShowClasses();?>
</select>
             </div>
             <div class="col-2 text-right">
<button class="btn btn-md btn-primary" id="search-btn">search</button>
             </div>
           </div>
         </div>
         <div class="card-body">
           <div class="table-responsive">
             <table class="table align-items-center table-flush">
               <thead class="thead-light">
                 <tr>
                   <th scope="col">Invoice No</th>
                   <th scope="col">Invoice Type</th>
                   <th scope="col">Amount</th>
                   <th scope="col" class="sort" data-sort="name">Session</th>
                  <th scope="col" class="sort" data-sort="name">Term</th>
                  <th scope="col">Class</th>
                   <th scope="col" class="sort" data-sort="status">Admission ID</th>

                   <th scope="col">Created</th>
                   <th scope="col">Status</th>
                   <th scope="col">Options</th>

                 </tr>
               </thead>
                <tbody class="list" id="show-my-invoices">
          <?php
$invoice_receipt->ShowAllInvoicesForAccountant();
           ?>
           </tbody>
         </table>
       </div>

         </div>
       </div>
     </div>
   </div>
  </div>





      <div class="col-md-8">
              <div class="modal fade" id="single-modal-form" tabindex="-1" role="dialog" aria-labelledby="single-modal-form" aria-hidden="true">
          <div class="modal-dialog modal- modal-dialog-centered modal-sm" role="document">
              <div class="modal-content">

                  <div class="modal-body p-0">

      <div class="card bg-secondary border-0 mb-0">
          <div class="card-body px-lg-5 py-lg-5">
              <div class="text-center text-muted mb-4">
                  <small>Add New Invoice</small>
              </div>
              <form role="form" id="upload-singinv-form" method="post">
                  <div class="row">
                    <div class="form-group mb-3 col-md-6">
                        <div class="input-group input-group-merge input-group-alternative">
                          <input class="form-control" name="inv-id"  placeholder="admission id" type="text">
                        </div>
                    </div>
                    <div class="form-group col-md-6">
                    <select name="inv-class" class="form-control">
                    <?php $classes->ShowClasses();?>
                    </select>
                    </div>
                  </div>
                  <div class="row">
                    <div class="form-group mb-3 col-md-6">
                      <select name="inv-session" class="form-control">
                        <option value="2020/2021">2020/2021</option>
                        <option value="2021/2022">2021/2022</option>
                      </select>
                    </div>
                    <div class="form-group col-md-6">
                    <select name="inv-type" class="form-control">
                      <option value="1">Tution Fee</option>
                      <option value="2">Exam Fee</option>
                    </select>
                    </div>
                  </div>
                  <div class="row">
                    <div class="form-group mb-3 col-md-6">
                      <select name="inv-term" class="form-control">
                        <option value="1st term">1st term</option>
                        <option value="2nd term">2nd term</option>
                        <option value="3rd term">3rd term</option>
                      </select>
                    </div>
                    <div class="form-group col-md-6">
                      <div class="input-group input-group-merge input-group-alternative">
                        <input class="form-control" name="inv-amount"  placeholder="amount" type="text">
                      </div>
                    </div>
                  </div>
                  <div class="text-center">
                      <button type="submit" class="btn btn-primary my-4">Add Invoice</button>
                  </div>
                  <div id="response_div"></div>
              </form>
          </div>
      </div>




                  </div>

              </div>
          </div>
      </div>

        </div>



              <div class="col-md-8">
                      <div class="modal fade" id="multiple-modal-form" tabindex="-1" role="dialog" aria-labelledby="single-modal-form" aria-hidden="true">
                  <div class="modal-dialog modal- modal-dialog-centered modal-sm" role="document">
                      <div class="modal-content">

                          <div class="modal-body p-0">

              <div class="card bg-secondary border-0 mb-0">
                  <div class="card-body px-lg-5 py-lg-5">
                      <div class="text-center text-muted mb-4">
                          <small>Add New Invoice</small>
                      </div>
                      <form role="form" id="upload-mulinv-form" method="post">
                          <div class="row">
  <input class="form-control" name="inv-id" value="multiple" placeholder="admission id" type="hidden">
                            <div class="form-group col-md-12">
                            <select name="inv-class" class="form-control">
                            <?php $classes->ShowClasses();?>
                            </select>
                            </div>
                          </div>
                          <div class="row">
                            <div class="form-group mb-3 col-md-6">
                              <select name="inv-session" class="form-control">
                                <option value="2020/2021">2020/2021</option>
                                <option value="2021/2022">2021/2022</option>
                              </select>
                            </div>
                            <div class="form-group col-md-6">
                            <select name="inv-type" class="form-control">
                              <option value="1">Tution Fee</option>
                              <option value="2">Exam Fee</option>
                            </select>
                            </div>
                          </div>
                          <div class="row">
                            <div class="form-group mb-3 col-md-6">
                              <select name="inv-term" class="form-control">
                                <option value="1st term">1st term</option>
                                <option value="2nd term">2nd term</option>
                                <option value="3rd term">3rd term</option>
                              </select>
                            </div>
                            <div class="form-group col-md-6">
                              <div class="input-group input-group-merge input-group-alternative">
                                <input class="form-control" name="inv-amount"  placeholder="amount" type="text">
                              </div>
                            </div>
                          </div>
                          <div class="text-center">
                              <button type="submit" class="btn btn-primary my-4">Generate Invoices</button>
                          </div>
                          <div id="mul_response_div"></div>
                      </form>
                  </div>
              </div>




                          </div>

                      </div>
                  </div>
              </div>

                </div>



  <?php  include "../../layouts/student-layouts/footer.php";?>
  <script>
  $('#show-my-invoices').on('click', '.edit-inv', function() {
    var  process_url = "../../processes/accountant/edit-invoice.php";
    var id = $(this).attr("id");

  });
  </script>
  <script>
  $('#show-my-invoices').on('click', '.del-inv', function() {
    var  process_url = "../../processes/accountant/delete-invoice.php";
    var id = $(this).attr("id");
      var formData = {'id' : id};
    var answer = prompt("Do you want to delete this invoice , Confirm by typing yes?");
    if(answer == "yes"){
      $.ajax({

          url: process_url,
          type: "POST",             // Type of request to be send, called as method
          data: formData, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                  // To unable request pages to be cached
          beforeSend: function() {
            //  $("#show-my-invoices").html("<div class='text-primary' role='status'>Loading....</div>");
           },
          success: function (data) {
            setTimeout(function(){
                  $("#mytr"+id).remove();
            },2000)},
          error: function (data) {
            //  console.log('An error occurred.');
              console.log(data);
          },
      });
    }
  });
  </script>
<script>
  $('#search-btn').click(function() {
    var  process_url = "../../processes/accountant/search-invoice.php";
    var selectedType = $("#type"). children("option:selected"). val();
    var selectedClass = $("#class"). children("option:selected"). val();
    var selectedStatus = $("#status"). children("option:selected"). val();
    var selectedSession = $("#session"). children("option:selected"). val();
    var selectedTerm = $("#term"). children("option:selected"). val();
    var formData = {'class' :selectedClass,'invoice_type' :selectedType,'session' :selectedSession,'term' :selectedTerm,'status' :selectedStatus};
    $.ajax({

        url: process_url,
        type: "POST",             // Type of request to be send, called as method
        data: formData, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                // To unable request pages to be cached
        beforeSend: function() {
            $("#show-my-invoices").html("<div class='text-primary' role='status'>Loading....</div>");
         },
        success: function (data) {
          setTimeout(function(){
             $("#show-my-invoices").html(data);
          },3000)



        },
        error: function (data) {
          //  console.log('An error occurred.');
            console.log(data);
        },
    });
  });

</script>
<script>
var frm = $('#upload-singinv-form');
    frm.submit(function (e) {
        e.preventDefault();
        var  process_url = "../../processes/accountant/create-invoice.php";
        $.ajax({
            url: process_url,
            type: "POST",             // Type of request to be send, called as method
            data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
            contentType: false,
            dataType: 'json',       // The content type used when sending data to the server.
            cache: false,
           // encode: true;           // To unable request pages to be cached
            processData:false,
            beforeSend: function() {
                $("#response_div").html("<div class='alert alert-info' role='alert'>Please wait..........</div>");
             },
            success: function (data) {
              if(data.code == 1){
              frm.trigger("reset");
               $("#response_div").html("");
               $("#response_div").html("<div class='alert alert-success' role='alert'>"+data.message+"</div>");
               setTimeout(function(){
                  $("#response_div").html("");
               },3000);
            }
            else{
               $("#response_div").html("");
               $("#response_div").html("<div class='alert alert-danger' role='alert'>"+data.message+"</div>");
               setTimeout(function(){
                  $("#response_div").html("");
               },3000);
            }
  },
            error: function (data) {
              //  console.log('An error occurred.');
                console.log(data);
            },
        });
    });
</script>

<script>
var frm = $('#upload-mulinv-form');
    frm.submit(function (e) {
        e.preventDefault();
        var  process_url = "../../processes/accountant/create-invoice.php";
        $.ajax({
            url: process_url,
            type: "POST",             // Type of request to be send, called as method
            data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
            contentType: false,
            //dataType: 'json',       // The content type used when sending data to the server.
            cache: false,
           // encode: true;           // To unable request pages to be cached
            processData:false,
            beforeSend: function() {
                $("#mul_response_div").html("<div class='alert alert-info' role='alert'>Please wait..........</div>");
             },
            success: function (data) {
              $("#mul_response_div").html("<div class='alert alert-success' role='alert'>Created Successfully</div>");
              setTimeout(function(){
                 $("#mul_response_div").html("");
              },3000);
  },
            error: function (data) {
              //  console.log('An error occurred.');
                console.log(data);
            },
        });
    });
</script>

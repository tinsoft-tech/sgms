<?php include "../../layouts/student-layouts/header.php";
if(empty($_GET['id'])){
  echo '<script>window.location="index.php"</script>';
}
$id = $_GET['id'];
?>

<body>
<?php include "../../layouts/student-layouts/sidebar.php";?>
  <!-- Main content -->
  <div class="main-content" id="panel">
  <?php include "../../layouts/student-layouts/navigation-bar.php";?>

 <!-- Page content -->
 <div style="margin-top:20px;" class="container-fluid">
   <div style="background:#172B4D;" class="container-fluid d-flex align-items-center">
     <div class="row" style="padding-top:15px;width:100%;">
       <div class="col-lg-7 col-md-10">
         <h1 class="text-white">Hello <?php  echo $_SESSION["FULLNAME"];?></h1>
         <p class="text-white mt-0 mb-5">Welcome to your Continuos Assessment page.</p>
         <a href="#!" class="btn btn-neutral" style="display:none;">Edit profile</a>
       </div>
     </div>
   </div>
   <div class="row">

     <div class="col-xl-12 order-xl-1">
       <div class="card">
         <div class="card-header">
           <div class="row align-items-center">
             <div class="col-8">
               <h3 class="mb-0">Continuos Assessment </h3>
             </div>
             <div class="col-4 text-right">

             </div>
           </div>
         </div>
         <div class="card-body">
           <div class="table-responsive">
             <table class="table align-items-center table-flush">
               <thead class="thead-light">
                 <tr>
                   <th scope="col" class="sort" data-sort="budget"><b>s/n</b></th>
                   <th scope="col" class="sort" data-sort="status"><b>question</b></th>


                   <th scope="col" class="sort" data-sort="name"><b>Mark</b></th>
                 </tr>
               </thead>
                <tbody class="list" id="write-my-test">
          <?php
$ca->ShowCaQuestions($_GET["id"],$_SESSION["LOGGED_IN_ADMID"]);
           ?>



       </div>

         </div>
       </div>
     </div>
   </div>
  </div>



  <?php  include "../../layouts/student-layouts/footer.php";?>
  <script>
$(document).ready(function(){
  function submitass(jk){
    $.ajax({
                 url: '../../processes/student/submit-ca.php',
                 type: 'post',
                 dataType: 'json',
                 data: $("#myform"+jk).serialize(),
                 success: function(data) {

                 }
               });
  }
$("#submit-ans").click(function(){

  var count = "<?php echo $ca->ShowCaQuestionsCount($id); ?>";
  for (var i = 1; i <= count; i++) {
    submitass(i);

  }

$(".table-responsive").html("<div class='alert alert-success'>Test Submitted Successfully</div>")
  })


});

  </script>

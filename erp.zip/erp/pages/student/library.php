<?php include "../../layouts/student-layouts/header.php";?>
<body>
<?php include "../../layouts/student-layouts/sidebar.php";?>
  <!-- Main content -->
  <div class="main-content" id="panel">
  <?php include "../../layouts/student-layouts/navigation-bar.php";?>

 <!-- Page content -->
 <div style="margin-top:20px;" class="container-fluid">
   <div style="background:#172B4D;" class="container-fluid d-flex align-items-center">
     <div class="row" style="padding-top:15px;width:100%;">
       <div class="col-lg-7 col-md-10">
         <h1 class="text-white">Hello <?php  echo $_SESSION["FULLNAME"];?></h1>
         <p class="text-white mt-0 mb-5">Welcome to the library page.</p>
         <a href="#!" class="btn btn-neutral" style="display:none;">Edit profile</a>
       </div>
     </div>
   </div>
   <div class="row">

     <div class="col-xl-12 order-xl-1">
       <div class="card">
         <div class="card-header">
           <div class="row align-items-center">
             <div class="col-8">
               <h3 class="mb-0">Library </h3>
             </div>
             <div class="col-4 text-right">
               <div class="form-groupp">

                 <input type="search" id="book-search"  class="form-control" placeholder="Search for Book">
               </div>
             </div>
           </div>
         </div>
         <div class="card-body">
           <div class="table-responsive">
             <table class="table align-items-center table-flush">
               <thead class="thead-light">
                 <tr>
                   <th scope="col" class="sort" data-sort="name">Book Cover</th>

                   <th scope="col" class="sort" data-sort="status">Author</th>
                   <th scope="col">Category</th>
                   <th scope="col" class="sort" data-sort="completion">Publisher</th>
                   <th scope="col">ISBN</th>
                   <th scope="col">Download</th>
                 </tr>
               </thead>
                <tbody class="list" id="show-book-search">
          <?php
$liberian->ShowBooks();
           ?>
           </tbody>
         </table>
       </div>

         </div>
       </div>
     </div>
   </div>
  </div>
  <?php  include "../../layouts/student-layouts/footer.php";?>

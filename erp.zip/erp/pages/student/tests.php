<?php include "../../layouts/student-layouts/header.php";?>

<body>
<?php include "../../layouts/student-layouts/sidebar.php";?>
  <!-- Main content -->
  <div class="main-content" id="panel">
  <?php include "../../layouts/student-layouts/navigation-bar.php";?>

 <!-- Page content -->
 <div style="margin-top:20px;" class="container-fluid">
   <div style="background:#172B4D;" class="container-fluid d-flex align-items-center">
     <div class="row" style="padding-top:15px;width:100%;">
       <div class="col-lg-7 col-md-10">
         <h1 class="text-white">Hello <?php  echo $_SESSION["FULLNAME"];?></h1>
         <p class="text-white mt-0 mb-5">Welcome to your Continuos Assessment page.</p>
         <a href="#!" class="btn btn-neutral" style="display:none;">Edit profile</a>
       </div>
     </div>
   </div>
   <div class="row">

     <div class="col-xl-12 order-xl-1">
       <div class="card">
         <div class="card-header">
           <div class="row align-items-center">
             <div class="col-8">
               <h3 class="mb-0">Continuos Assessment </h3>
             </div>
             <div class="col-4 text-right">

             </div>
           </div>
         </div>
         <div class="card-body">
           <div class="table-responsive">
             <table class="table align-items-center table-flush">
               <thead class="thead-light">
                 <tr>
                   <th scope="col" class="sort" data-sort="budget"><b>Subject</b></th>
                   <th scope="col" class="sort" data-sort="status"><b>Class</b></th>
                     <th scope="col" class="sort" data-sort="status"><b>Session</b></th>
                       <th scope="col" class="sort" data-sort="status"><b>Term</b></th>
                   <th scope="col" class="sort" data-sort="status"><b>Time</b></th>
                     <th scope="col" class="sort" data-sort="status"><b>Date</b></th>

                   <th scope="col" class="sort" data-sort="name"><b>Options</b></th>
                 </tr>
               </thead>
                <tbody class="list" id="show-my-test">
          <?php
$ca->ShowFullCaTest($_SESSION["CLASS"],$_SESSION["COM"]);
           ?>
           </tbody>
         </table>
       </div>

         </div>
       </div>
     </div>
   </div>
  </div>

  <div class="modal fade" id="camodal-form" tabindex="-1" role="dialog" aria-labelledby="modal-form" aria-hidden="true">
  <div id="editshowdiv" class="modal-dialog modal- modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">

        <div class="modal-body p-0">

    <div class="card-body" id="card-body">
<h1>Kindly Note the following</h1>
<ul>
<li>Make sure you answer all the questions </li>
<li>Always take note of the timer </li>
<li>The test will automatically submit when time is complete </li>

</ul>
<a href="write-test.php" id="go-to" class="btn btn-sm btn-default bgbtn">Begin</a>
<input type="hidden" id="tid"/>
    </div>

  </div>

</div>



  </div>

  </div>

  <?php  include "../../layouts/student-layouts/footer.php";?>
  <script>
  $('#show-my-test').on('click', '.take-ca', function() {
  var id = $(this).attr("id");
    var tid = $("#tid").val(id);
$("#go-to").attr("href","write-test.php?id="+id);
  });
  </script>

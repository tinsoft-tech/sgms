<?php include "../../layouts/student-layouts/header.php";
if(empty($_GET['id'])){
  echo '<script>window.location="index.php"</script>';
}
$id = $_GET['id'];
?>

<body>
<?php include "../../layouts/student-layouts/sidebar.php";?>
  <!-- Main content -->
  <div class="main-content" id="panel">
  <?php include "../../layouts/student-layouts/navigation-bar.php";?>

 <!-- Page content -->
 <div style="margin-top:20px;" class="container-fluid">
   <div style="background:#172B4D;" class="container-fluid d-flex align-items-center">
     <div class="row" style="padding-top:15px;width:100%;">
       <div class="col-lg-7 col-md-10">
         <h1 class="text-white">Hello <?php  echo $_SESSION["FULLNAME"];?></h1>
         <p class="text-white mt-0 mb-5">Welcome to your Exams page.</p>
         <a href="#!" class="btn btn-neutral" style="display:none;">Edit profile</a>
       </div>
     </div>
   </div>
   <div class="row">

     <div class="col-xl-12 order-xl-1">
       <div class="card">
         <div class="card-header">
           <div class="row align-items-center">
             <div class="col-8">
               <h3 class="mb-0">Examination </h3>

             </div>
             <div class="col-4 text-right">
               <div class="progress">
                 <div id="prog-timer" class="progress-bar bg-primary progress-bar-striped progress-bar-animated" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100" style="width: 100%"></div>

               </div>
<div class="countdown"></div>

             </div>
           </div>
           <br/>
           <div id="progress-div">
           <div class="progress">
             <div id="prog" class="progress-bar bg-primary progress-bar-striped progress-bar-animated" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div>

           </div>
           <label class="form-check-label">
          <span id="qc">0</span> of <?php echo $exam->ShowExamQuestionsCount($id); ?> questions answered
           </label>
           </div>

         </div>
         <div class="card-body" style="height:500px;overflow:scroll;">

           <div class="table-responsive" id="tbquest">
             <table id="tbquest" class="table align-items-center table-flush">
               <thead class="thead-light">
                 <tr>
                   <th scope="col" class="sort" data-sort="budget"><b>s/n</b></th>
                   <th scope="col" class="sort" data-sort="status"><b>question</b></th>



                 </tr>
               </thead>
                <tbody class="list" id="write-my-test">
          <?php
$exam->ShowExamQuestions($_GET["id"],$_SESSION["LOGGED_IN_ADMID"]);
           ?>

       </div>

         </div>
       </div>
     </div>
   </div>
  </div>



  <?php  include "../../layouts/student-layouts/footer.php";?>
  <script type="text/javascript">
  var s = 0;
  var questnum = "<?php echo $exam->ShowExamQuestionsCount($id); ?>";
  var per = 100/questnum;
  var percent = 0;
  function Inc(id){
    var ch = $("#check"+id);
    if(id != s){
      s+=1;
      percent+=per;

        $("#prog").width(percent+"%");
      $("#qc").html(s);
    }

  //  alert(id);
  }
  </script>

  <script>
$(document).ready(function(){
$(window).bind('beforeunload',function(e){
  return "noooo";
    e.preventDefault();
})
var tm = "<?php echo $exam->ShowExamTimer($id); ?>";
var ti = tm * 60;
  var timer2 = tm +":00";
    //var timer2 = "01:00";
  var per = 100/ti;
  var percent = 100;
var interval = setInterval(function() {
  var timer = timer2.split(':');
  //by parsing integer, I avoid all extra string processing
  var minutes = parseInt(timer[0], 10);
  var seconds = parseInt(timer[1], 10);
  --seconds;
  minutes = (seconds < 0) ? --minutes : minutes;
  if (minutes < 0) clearInterval(interval);
  seconds = (seconds < 0) ? 59 : seconds;
  seconds = (seconds < 10) ? '0' + seconds : seconds;
  //minutes = (minutes < 10) ?  minutes : minutes;
  $('.countdown').html(minutes + ':' + seconds);
  timer2 = minutes + ':' + seconds;
    $("#prog-timer").width(percent+"%");
    percent-=per;
    if(minutes <  01){$("#prog-timer").removeClass("bg-primary");$("#prog-timer").addClass("bg-danger");}
    if ((minutes == 00)& (seconds ==  00)) {
      clearInterval(interval);
    SubmitElapsed();
    }
}, 1000);
//if(timer2 = "09:00"){alert("yes");}
var exam_id = "<?php echo $_GET['id'];?>";
var admission_id = "<?php echo $_SESSION["LOGGED_IN_ADMID"];?>";
var num = "<?php echo $exam->ShowExamQuestionsCount($id); ?>";
var session = $("#session").val();
var term = $("#term").val();
var subjectt = $("#subjectt").val();
function submitreport(){
  //alert(session);
  var postReportForm = {
   exam_id : exam_id,subject:subjectt,admission_id : admission_id,session:session,total:num,term:term
  };
  $.ajax({
               url: '../../processes/student/submit-report.php',
               type: 'post',
               dataType: 'json',
               data: postReportForm,
               success: function(data) {

               }
             });
}
function getresult(){
  setTimeout(function(){
    $.ajax({
                 url: '../../processes/student/check-exam-score.php',
                 type: 'post',
                 //dataType: 'json',
                 data: postForm,

                 success: function(data) {
                  $("#progress-div").hide();
                  $(".table-responsive").html(data);
                  submitreport();
                  clearInterval(interval);
                 }
               });
 },3000);
 //$("#progress-div").show();
  var postForm = {
   exam_id : exam_id, admission_id : admission_id,num:num
 };

}
  function submitass(jk){
    $.ajax({
                 url: '../../processes/student/submit-exam.php',
                 type: 'post',
                 dataType: 'json',
                 data: $("#myform"+jk).serialize(),
                 success: function(data) {
//alert(jk);
                 }
               });
  }
$("#submit-ans").click(function(){
  var answer = prompt("Do you want to submit this Exam , Confirm by typing yes?");
  if(answer == "yes"){
   var count = "<?php echo $exam->ShowExamQuestionsCount($id); ?>";
    for (var i = 1; i <= count; i++) {
      submitass(i);

    }


  $(".table-responsive").html("<div class='alert alert-success'>Exam Submitted Successfully</div>");
  setTimeout(function(){
   $("#progress-div").show();
   $(".table-responsive").html("");
 },3000);

getresult();

};
});

function SubmitElapsed(){
  var count = "<?php echo $exam->ShowExamQuestionsCount($id); ?>";
   for (var i = 1; i <= count; i++) {
     submitass(i);

   }


 $(".table-responsive").html("<div class='alert alert-success'>Exam Submitted Successfully</div>");
 setTimeout(function(){
  $("#progress-div").show();
  $(".table-responsive").html("");
},3000);

getresult();
}

});

  </script>

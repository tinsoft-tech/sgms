<?php include "../../layouts/instructor-layouts/header.php";?>
<style>
.progress { position:relative; width:400px; border: 1px solid #ddd; padding: 1px; border-radius: 3px; }
.bar { background-color: #B4F5B4 !important; width:0%; height:20px; border-radius: 3px; }
.percent { position:absolute; display:inline-block; top:3px; left:48%; }
</style>
<body>
<?php include "../../layouts/instructor-layouts/sidebar.php";?>
  <!-- Main content -->
  <div class="main-content" id="panel">
  <?php include "../../layouts/instructor-layouts/navigation-bar.php";?>

 <!-- Page content -->
 <div style="margin-top:20px;" class="container-fluid">
   <div style="background:#172B4D;" class="container-fluid d-flex align-items-center">
     <div class="row" style="padding-top:15px;width:100%;">
       <div class="col-lg-7 col-md-10">
         <h1 class="text-white">Hello <?php  echo $_SESSION["FULLNAME"];?></h1>
         <p class="text-white mt-0 mb-5">Welcome to your assignments page.</p>
         <a href="#!" class="btn btn-neutral" style="display:none;">Edit profile</a>
       </div>
     </div>
   </div>
   <div class="row">

     <div class="col-xl-12 order-xl-1">
       <div class="card">
         <div class="card-header">
           <div class="row align-items-center">
             <div class="col-8">
               <h3 class="mb-0">Submitted Assignments </h3>
             </div>
             <div class="col-4 text-right">

             </div>
           </div>
         </div>
         <div class="card-body">
           <div class="table-responsive">
             <table class="table align-items-center table-flush">
               <thead class="thead-light">
                 <tr>
                   <th scope="col" class="sort" data-sort="status">Name</th>
                   <th scope="col">Admission ID</th>
                   <th scope="col" class="sort" data-sort="completion">Submitted Date</th>
                   <th scope="col">Deadline</th>
                    <th scope="col">Status</th>
                   <th scope="col" class="text-right">View</th>
                   <th scope="col" class="text-right">Mark</th>
                 </tr>
               </thead>
                <tbody class="list" id="show-sub-assignment-search">
          <?php
$assignment->ShowInstructorSubmittedAssignments($_GET["id"]);
           ?>
           </tbody>
         </table>
       </div>

         </div>
       </div>
     </div>
   </div>
  </div>




  <?php  include "../../layouts/student-layouts/footer.php";?>
  <script>
  $('#show-sub-assignment-search').on('click', '.sub-report', function() {
    var  process_url = "../../processes/instructor/submit-report.php";
    var fy = $(this).attr("id");
    var adm = $("#adm"+fy).val();
    var ass = $("#ass"+fy).val();
    var score = $("#mark"+fy).val();
    var report = $("#report"+fy).val();
    var subject = $("#subject"+fy).val();
    var session = $("#session"+fy).val();
    var term = $("#term"+fy).val();
    var total = $("#total"+fy).val();
    var formData = {'id' : ass,'admission_id' : adm,'score' : score,'session' : session,'subject' : subject,'term' : term,'total' : total,'type' : report};
      $.ajax({
          url: "../../processes/instructor/submit-report.php",
          type: "POST",             // Type of request to be send, called as method
          data: formData, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
          dataType: 'json',     // To unable request pages to be cached
          beforeSend: function() {
            //  $("#editshowdiv").html("<div class='spinner-border text-primary' role='status'><span class='sr-only'>Loading...</span></div>");
           },
          success: function (data) {
          if(data.code ==1){
            $("#ma"+fy).html("marked");
            $("#sa"+fy).html("marked");

          }

          },
          error: function (data) {
            //  console.log('An error occurred.');
              console.log(data);
          },
      });

  });
  </script>

<?php include "../../layouts/instructor-layouts/header.php";?>
<body>
<?php include "../../layouts/instructor-layouts/sidebar.php";?>
  <!-- Main content -->
  <div class="main-content" id="panel">
  <?php include "../../layouts/instructor-layouts/navigation-bar.php";?>

 <!-- Page content -->
 <div style="margin-top:20px;" class="container-fluid">
   <div style="background:#172B4D;" class="container-fluid d-flex align-items-center">
     <div class="row" style="padding-top:15px;width:100%;">
       <div class="col-lg-7 col-md-10">
         <h1 class="text-white">Hello <?php  echo $_SESSION["FULLNAME"];?></h1>
         <p class="text-white mt-0 mb-5">Welcome to your assignments page.</p>
         <a href="#!" class="btn btn-neutral" style="display:none;">Edit profile</a>
       </div>
     </div>
   </div>
   <div class="row">

     <div class="col-xl-12 order-xl-1">
       <div class="card">
         <div class="card-header">
           <div class="row align-items-center">
             <div class="col-8">
               <h3 class="mb-0">Create Assignment </h3>
             </div>
             <div class="col-4 text-right">

             </div>
           </div>
         </div>
         <div class="card-body">
          <form method="post" id="ass-form" enctype="multipart/form-data">

            <div class="row">
              <div class="col-lg-4">
                <div class="form-group">
                  <label class="form-control-label" for="input-first-name">Assignment Title</label>
                  <input type="text" name="assignment_name" class="form-control" placeholder="Assignment Title">
                </div>
              </div>
              <div class="col-lg-4">
                <div class="form-group">
                  <label class="form-control-label" for="input-last-name">Subject</label>
                  <input type="text" name="subject_name" value="<?php echo $_SESSION['SUBJECT']?>" class="form-control" placeholder="Subject">
                </div>
              </div>
              <div class="col-lg-4">
                <div class="form-group">
                  <div class="form-group">
                    <label class="form-control-label" for="input-last-name">Class</label>
                    <input type="text" name="class" value="<?php echo $_SESSION['CLASS']?>" class="form-control" placeholder="Subject">
                  </div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-4">
                <div class="form-group">
                  <label class="form-control-label" for="input-last-name">Section</label>
                <select class="form-control" name="section">
<option value="A">A</option>
<option value="B">B</option>
<option value="C">C</option>
<option value="D">D</option>
                </select>
                </div>
              </div>
              <div class="col-lg-4">
                <div class="form-group">
                  <label class="form-control-label" for="input-last-name">Date</label>
      <div class="input-group input-group-alternative">
          <div class="input-group-prepend">
              <span class="input-group-text"><i class="ni ni-calendar-grid-58"></i></span>
          </div>
          <input class="form-control datepicker" name="date" id="attendance-date" placeholder="Select date" type="text" >
      </div>
  </div>
              </div>
              <div class="col-lg-4">
                <div class="form-group">
                  <label class="form-control-label" for="input-last-name">File</label>
                  <input type="file" name="image" class="form-control">
                </div>
              </div>
            </div>
<div class="row">
  <div class="col-lg-4">
    <div class="form-group">
      <label class="form-control-label" for="input-first-name">Marks</label>
      <input type="text" name="assignment_mark" class="form-control" placeholder="Assignment Mark">
    </div>
  </div>
<div class="col-lg-4">
  <button type="submit" class="btn btn-md btn-primary">Create</button>
</div>
<div class="col-lg-4" id="in_response_div">

</div>

</div>
          </form>
         </div>
       </div>
     </div>
   </div>
  </div>
<?php  include "../../layouts/instructor-layouts/footer.php";?>
<script>
var frm = $('#ass-form');

    frm.submit(function (e) {

        e.preventDefault();
        var  process_url = "../../processes/instructor/create-assignment.php";
        $.ajax({
            url: process_url,
            type: "POST",             // Type of request to be send, called as method
            data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
            contentType: false,
            dataType: 'json',       // The content type used when sending data to the server.
            cache: false,
           // encode: true;           // To unable request pages to be cached
            processData:false,
            beforeSend: function() {
                $("#in_response_div").html("<div class='alert alert-info' role='alert'>Please wait..........</div>");
             },
            success: function (data) {
              if(data.code == 1){
              frm.trigger("reset");
               $("#in_response_div").html("");
               $("#in_response_div").html("<div class='alert alert-success' role='alert'>"+data.message+"</div>");
               setTimeout(function(){
                  $("#in_response_div").html("");
               },3000);
            }
            else{
               $("#in_response_div").html("");
               $("#in_response_div").html("<div class='alert alert-danger' role='alert'>"+data.message+"</div>");
               setTimeout(function(){
                  $("#in_response_div").html("");
               },3000);
            }


            },
            error: function (data) {
              //  console.log('An error occurred.');
                console.log(data);
            },
        });
    });

</script>

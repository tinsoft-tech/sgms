<?php include "../../layouts/instructor-layouts/header.php";?>

<body>
<?php include "../../layouts/instructor-layouts/sidebar.php";?>
  <!-- Main content -->
  <div class="main-content" id="panel">
  <?php include "../../layouts/instructor-layouts/navigation-bar.php";?>

 <!-- Page content -->
 <div style="margin-top:20px;" class="container-fluid">
   <div style="background:#172B4D;" class="container-fluid d-flex align-items-center">
     <div class="row" style="padding-top:15px;width:100%;">
       <div class="col-lg-7 col-md-10">
         <h1 class="text-white">Hello <?php  echo $_SESSION["FULLNAME"];?></h1>
         <p class="text-white mt-0 mb-5">Welcome to your attendance page.</p>

         <a href="#!" class="btn btn-neutral" style="display:none;">Edit profile</a>
       </div>
       <div class="col-2 text-right">
<input type="hidden" id="idclass" value="<?php  echo $_SESSION["CLASS"];?>"/>
<input type="hidden" id="idsection" value="<?php  echo $_SESSION["SECTION"];?>"/>
       </div>
     </div>
   </div>
   <div class="row">

     <div class="col-xl-12 order-xl-1">
       <div class="card">
         <div class="card-header">
           <div class="row align-items-center">
             <div class="col-6">
               <h3 class="mb-0">Mark Attendance </h3>

             </div>
             <div class="col-6 text-right">
                <div class="form-group">
                <input type="hidden" value="<?php echo $_SESSION['CLASS'];?>" name="class" id="class"/>
                <input type="hidden" value="<?php echo $_SESSION['SECTION'];?>" name="section" id="section"/>
                <input type="hidden" value="2020/2021" name="session" id="session"/>
                <input type="hidden" value="<?php echo date('m/d/Y'); ?>" name="date" id="date"/>
             <button class="btn btn-md btn-primary" id="generateattendance">Generate Attendance for <?php echo $_SESSION["CLASS"].$_SESSION["SECTION"];?></button>
             </div>
             </div>


           </div>
         </div>
         <div class="card-body">
           <div class="table-responsive">
             <table class="table align-items-center table-flush">
               <thead class="thead-light">
                 <tr>
                   <th scope="col" class="sort" data-sort="name">Session</th>

                   <th scope="col" class="sort" data-sort="status">Admission ID</th>
                   <th scope="col">Class</th>
                   <th scope="col">Section</th>
                   <th scope="col">Date</th>
                   <th scope="col" class="sort" data-sort="completion">Status</th>


                 </tr>
               </thead>
                <tbody class="list" id="show-my-attendance">

           </tbody>
         </table>
       </div>

         </div>
       </div>
     </div>
   </div>
  </div>


  <?php  include "../../layouts/instructor-layouts/footer.php";?>
    <script>
    $('#show-my-attendance').on('click', '.mark-att', function() {
      var  process_url = "../../processes/instructor/mark-attendance.php";
      var fy = $(this).attr("id");
      var admid = $("#mytra"+fy).val();
      var formData = {'id' : admid};
      if($(this).is(":checked")){
        $.ajax({

            url: "../../processes/instructor/mark-attendance.php",
            type: "POST",             // Type of request to be send, called as method
            data: formData, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
            dataType: 'json',     // To unable request pages to be cached
            beforeSend: function() {
              //  $("#editshowdiv").html("<div class='spinner-border text-primary' role='status'><span class='sr-only'>Loading...</span></div>");
             },
            success: function (data) {
            if(data.code ==1){
              $("#mytr"+fy).css("background","green");

            }

            },
            error: function (data) {
              //  console.log('An error occurred.');
                console.log(data);
            },
        });
      }
      else{
        $.ajax({

            url: "../../processes/instructor/unmark-attendance.php",
            type: "POST",             // Type of request to be send, called as method
            data: formData, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
            dataType: 'json',     // To unable request pages to be cached
            beforeSend: function() {
              //  $("#editshowdiv").html("<div class='spinner-border text-primary' role='status'><span class='sr-only'>Loading...</span></div>");
             },
            success: function (data) {
            if(data.code ==1){
              $("#mytr"+fy).css("background","crimson");

            }

            },
            error: function (data) {
              //  console.log('An error occurred.');
                console.log(data);
            },
        });
      }
    });
    </script>
  <script>
    $('#generateattendance').click(function() {
      var  process_url = "../../processes/instructor/generate-attendance.php";

        var iclass = $("#class").val();
        var section = $("#section").val();
        var date = $("#date").val();
        var session = $("#session").val();
      var formData = {'date' :date,'class':iclass,'section':section,'session':session};
      $.ajax({

          url: process_url,
          type: "POST",             // Type of request to be send, called as method
          data: formData, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                  // To unable request pages to be cached
          beforeSend: function() {
              $("#show-my-attendance").html("<div class='text-primary' role='status'>Generatting....</div>");
           },
          success: function (data) {
            setTimeout(function(){
               $("#show-my-attendance").html(data);
            },3000)
          },
          error: function (data) {
            //  console.log('An error occurred.');
              console.log(data);
          },
      });
    });

  </script>

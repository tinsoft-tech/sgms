<?php include "../../layouts/instructor-layouts/header.php";?>

<body>
<?php include "../../layouts/instructor-layouts/sidebar.php";?>
  <!-- Main content -->
  <div class="main-content" id="panel">
  <?php include "../../layouts/instructor-layouts/navigation-bar.php";?>

 <!-- Page content -->
 <div style="margin-top:20px;" class="container-fluid">
   <div style="background:#172B4D;" class="container-fluid d-flex align-items-center">
     <div class="row" style="padding-top:15px;width:100%;">
       <div class="col-lg-7 col-md-10">
         <h1 class="text-white">Hello <?php  echo $_SESSION["FULLNAME"];?></h1>
         <p class="text-white mt-0 mb-5">Welcome to your Continuos Assessment page.</p>
         <a href="#!" class="btn btn-neutral" style="display:none;">Edit profile</a>
       </div>
     </div>
   </div>
   <div class="row">

     <div class="col-xl-12 order-xl-1">
       <div class="card">
         <div class="card-header">
           <div class="row align-items-center">
             <div class="col-8">
               <h3 class="mb-0">Continuos Assessment </h3>
             </div>
             <div class="col-4 text-right">
<button data-toggle="modal" data-target="#newcamodal-form" class="btn btn-sm btn-primary">Create </button>
             </div>
           </div>
         </div>
         <div class="card-body">
           <div class="table-responsive">
             <table class="table align-items-center table-flush">
               <thead class="thead-light">
                 <tr>
                   <th scope="col" class="sort" data-sort="budget"><b>Subject</b></th>
                   <th scope="col" class="sort" data-sort="status"><b>Class</b></th>
                     <th scope="col" class="sort" data-sort="status"><b>Session</b></th>
                       <th scope="col" class="sort" data-sort="status"><b>Term</b></th>
                   <th scope="col" class="sort" data-sort="status"><b>Time</b></th>
                     <th scope="col" class="sort" data-sort="status"><b>Date</b></th>

                   <th scope="col" class="sort" data-sort="name"><b>Options</b></th>
                 </tr>
               </thead>
                <tbody class="list" id="show-my-test">
          <?php
   $ca->ShowInstructorFullCaTest($_SESSION["SUBJECT"]);
           ?>
           </tbody>
         </table>
       </div>

         </div>
       </div>
     </div>
   </div>
  </div>
<div class="modal fade" id="camodal-form" tabindex="-1" role="dialog" aria-labelledby="modal-form" aria-hidden="true">
  <div id="editshowdiv" class="modal-dialog modal- modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">

        <div class="modal-body p-0">

    <div class="card-body" id="card-body">
<h1>Kindly Note the following</h1>
<ul>
<li>Make sure you answer all the questions </li>
<li>Always take note of the timer </li>
<li>The test will automatically submit when time is complete </li>

</ul>
<a href="write-test.php" id="go-to" class="btn btn-sm btn-default bgbtn">Begin</a>
<input type="hidden" id="tid"/>
    </div>

  </div>

</div>



  </div>

  </div>

  <div class="modal fade" id="newcamodal-form" tabindex="-1" role="dialog" aria-labelledby="modal-form" aria-hidden="true">
  <div  class="modal-dialog modal- modal-dialog-centered modal-sm" role="document">
    <div class="modal-content">

        <div class="modal-body p-0">

    <div class="card-body" id="card-body">
        <h2>New Ca Test</h2>
        <form id="create-ca" method="post">
  <input type="text" disabled class="form-control" id="subject_name" value="<?php echo $_SESSION['SUBJECT'];?>"/>
  <br/>
  <select class="form-control" id="subject_combination">
<option> Select Subject Combination</option>
<?php $ca->ShowSubjectCombinations();?>
  </select>
  <br/>
<input class="form-control"  id="from" type="time" placeholder="from"/>
<br/>
<input class="form-control" id="to" type="time" placeholder="to"/>
<br/>
<input type="text" disabled class="form-control" id="ca_class" value="<?php echo $_SESSION['CLASS'];?>"/>
<br/>
<input class="form-control" type="text" id="ca_session" placeholder="Session"/>
<br/>
<input class="form-control" type="text" id="ca_term" placeholder="Term"/>
<br/>
<input class="form-control" type="date" id="date" placeholder="to"/>
<br/>
<input class="form-control" type="number" id="ca_duration" placeholder="duration"/>
<button class="btn btn-primary" type="submit">Submit</button>
<div  id="respon-div">
</div>
</form>
    </div>

  </div>

  </div>



  </div>

  </div>


  <?php  include "../../layouts/student-layouts/footer.php";?>
  <script>
  var frm = $('#create-ca');
    frm.submit(function (e) {
         e.preventDefault();
          var  process_url = "../../processes/instructor/create-ca.php";
          var  subject = $("#subject_name").val();
          var  com = $("#subject_combination").val();
          var  from = $("#from").val();
          var  to = $("#to").val();
          var  session = $("#ca_session").val();
          var  term = $("#ca_term").val();
          var  classs = $("#ca_class").val();
          var  date = $("#date").val();
          var  duration = $("#ca_duration").val();
          var formData = {'subject_name' :subject,'subject_combination' :com,'ca_class':classs,'ca_session':session,'ca_term':term,'from':from,'to':to,'date':date,'ca_duration':duration};
          $.ajax({

              url: process_url,
              type: "POST",             // Type of request to be send, called as method
              data: formData, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
              //contentType: false,
              dataType: 'json',       // The content type used when sending data to the server.
              //cache: false,
             // encode: true;           // To unable request pages to be cached
              // processData:false,
              beforeSend: function() {
                  $("#respon-div").html("<div class='alert alert-info' role='alert'>Please wait..........</div>");
               },
              success: function (data) {
                if(data.code == 1){
                frm.trigger("reset");
                 $("#respon-div").html("");
                 $("#respon-div").html("<div class='alert alert-success' role='alert'>"+data.message+"</div>");
                 setTimeout(function(){
                    $("#respon-div").html("");
                 },3000);
              }
              else{
                 $("#respon-div").html("");
                 $("#respon-div").html("<div class='alert alert-danger' role='alert'>"+data.message+"</div>");
                 setTimeout(function(){
                    $("#respon-div").html("");
                 },3000);
              }


              },
              error: function (data) {
                //  console.log('An error occurred.');
                  console.log(data);
              },
          });
      });


  </script>
  <script>
  $('#show-my-test').on('click', '.take-ca', function() {
  var id = $(this).attr("id");
    var tid = $("#tid").val(id);
$("#go-to").attr("href","write-test.php?id="+id);
  });
  </script>

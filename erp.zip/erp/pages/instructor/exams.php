<?php include "../../layouts/instructor-layouts/header.php";?>

<body>
<?php include "../../layouts/instructor-layouts/sidebar.php";?>
  <!-- Main content -->
  <div class="main-content" id="panel">
  <?php include "../../layouts/instructor-layouts/navigation-bar.php";?>

 <!-- Page content -->
 <div style="margin-top:20px;" class="container-fluid">
   <div style="background:#172B4D;" class="container-fluid d-flex align-items-center">
     <div class="row" style="padding-top:15px;width:100%;">
       <div class="col-lg-7 col-md-10">
         <h1 class="text-white">Hello <?php  echo $_SESSION["FULLNAME"];?></h1>
         <p class="text-white mt-0 mb-5">Welcome to your Exams page.</p>
         <a href="#!" class="btn btn-neutral" style="display:none;">Edit profile</a>
       </div>
     </div>
   </div>
   <div class="row">

     <div class="col-xl-12 order-xl-1">
       <div class="card">
         <div class="card-header">
           <div class="row align-items-center">
             <div class="col-8">
               <h3 class="mb-0">Examination </h3>
             </div>
             <div class="col-4 text-right">

             </div>
           </div>
         </div>
         <div class="card-body">
           <div class="table-responsive">
             <table class="table align-items-center table-flush">
               <thead class="thead-light">
                 <tr>
                   <th scope="col" class="sort" data-sort="budget"><b>Subject</b></th>
                   <th scope="col" class="sort" data-sort="status"><b>Class</b></th>
                     <th scope="col" class="sort" data-sort="status"><b>Session</b></th>
                       <th scope="col" class="sort" data-sort="status"><b>Term</b></th>
                   <th scope="col" class="sort" data-sort="status"><b>Time</b></th>
                     <th scope="col" class="sort" data-sort="status"><b>Date</b></th>

                   <th scope="col" class="sort" data-sort="name"><b>Options</b></th>
                 </tr>
               </thead>
                <tbody class="list" id="show-my-test">
          <?php
$exam->ShowInsExamsbySubject($_SESSION["SUBJECT"]);
           ?>
           </tbody>
         </table>
       </div>

         </div>
       </div>
     </div>
   </div>
  </div>

  <div class="modal fade" id="uploadmodal-form" tabindex="-1" role="dialog" aria-labelledby="modal-form" aria-hidden="true">
  <div id="uploaddiv" class="modal-dialog modal- modal-dialog-centered modal-md" role="document">
    <div class="modal-content">

        <div class="modal-body p-0">
<div class="card-header" style="height:100px;background:#172B4D;">
  <div><label class="text-white">Upload <?php  echo $_SESSION["SUBJECT"]?> Questions</label></div>
    <div><label class="text-white mt-0 mb-5" id="assign_name"></label></div>

</div>
    <div class="card-body">
      <form action="../../processes/student/submit-assignment.php" id="fileUpload" method="post" enctype="multipart/form-data">
      <input type="file" class="btn btn-sm btn-default" name="image"><br/><br/>
      <input type="button" class="btn btn-sm btn-success" id="uploadFile" value="Submit">
      <br/><br/>
    <input type="hidden" name="exam_id" id="input-exam-id"/>
    <input type="hidden" name="admission_id" value="<?php // echo $_SESSION["LOGGED_IN_ADMID"]?>" id="input-adm-id"/>
      </form>
      <div class="progress">
      <div class="bar"></div >
        <br/>
        <br/>
      <div class="percent">0%</div >
    </div>

    <div id="status"></div>

</div>
</div>
</div>



  </div>

  </div>


  <?php  include "../../layouts/student-layouts/footer.php";?>
  <script type="text/javascript">
    function uploadProgressHandler(event) {
      //  $("#loaded_n_total").html("Uploaded " + event.loaded + " bytes of " + event.total);
        var percent = (event.loaded / event.total) * 100;
        var progress = Math.round(percent);
        $("#percent").html(progress + "%");
        $("#bar").css("width", progress + "%");
        $("#status").html(progress + "% uploaded... please wait");
    }

    function loadHandler(event) {
        $("#status").html(event.target.responseText);
        setTimeout(function(){
           $("#status").html("");
        },3000);
        $("#bar").css("width", "0%");
    }

    function errorHandler(event) {
        $("#status").html("Upload Failed");
    }

    function abortHandler(event) {
        $("#status").html("Upload Aborted");
    }

    $("#uploadFile").click(function (event) {
        event.preventDefault();
      //  var file = $("#fileUpload")[0].files[0];
    var id =  $("#qa").val();
     $("#input-exam-id").val(id);
        var formData = new FormData(document.getElementById("fileUpload"),document.getElementById("exam_id"));
        //formData.append("file1", file);

        $.ajax({
            url: '../../testimport.php',
            method: 'POST',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            xhr: function () {
                var xhr = new window.XMLHttpRequest();
                xhr.upload.addEventListener("progress",
                    uploadProgressHandler,
                    false
                );
                xhr.addEventListener("load", loadHandler, false);
                xhr.addEventListener("error", errorHandler, false);
                xhr.addEventListener("abort", abortHandler, false);
                return xhr;

            }
        });
        document.getElementById("fileUpload").reset();
    });
  </script>

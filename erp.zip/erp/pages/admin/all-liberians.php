
<?php include "../../layouts/admin-page-layouts/header.php";?>
<body>
<?php include "../../layouts/admin-page-layouts/sidebar.php";?>
  <!-- Main content -->
  <div class="main-content" id="panel">
  <?php include "../../layouts/admin-page-layouts/navigation-bar.php";?>
    <div class="header bg-default pb-6">
      <div class="container-fluid">
        <div class="header-body">
          <div class="row align-items-center py-4">
            <div class="col-lg-6 col-7">
              <h6 class="h2 text-white d-inline-block mb-0">All Liberians</h6>
            </div>

          </div>

        </div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--6">
<div class="card">
      <div class="row">
      <div class="col-xl-12">
          <div class="card">
            <div class="card-header border-0">
              <div class="row align-items-center">
                <div class="col">
                  <h3 class="mb-0">Liberians</h3>
                </div>
                <div class="col text-right">
                  <a href="#!" class="btn btn-sm btn-success">Reset</a>
                </div>
              </div>
            </div>
          </div>
      </div>
      </div>


<div class="table-responsive">
  <div>
      <table class="table align-items-center">
          <thead class="thead-light">
              <tr>

                  <th scope="col" class="sort" data-sort="name"><b>Passport</b></th>
                  <th scope="col" class="sort" data-sort="name"><b>Name</b></th>
                  <th scope="col" class="sort" data-sort="budget"><b>Gender</b></th>

                  <th scope="col" class="sort" data-sort="status"><b>Email</b></th>
                  <th scope="col" class="sort" data-sort="name"><b>Address</b></th>
                  <th scope="col" class="sort" data-sort="name"><b>Phone</b></th>

                  <th scope="col" class="sort" data-sort="name"><b>Options</b></th>

              </tr>
          </thead>
          <tbody class="list" id="liberian_response_div">
          <?php
$liberian->ShowLiberians();
           ?>
            </tbody>
          </table>
        </div>

</div>















</div>

    </div>

</div>

<div class="modal fade" id="leditmodal-form" tabindex="-1" role="dialog" aria-labelledby="modal-form" aria-hidden="true">
<div id="editshowdiv" class="modal-dialog modal- modal-dialog-centered modal-md" role="document">

</div>

</div>

      <?php  include "../../layouts/admin-page-layouts/footer.php";?>

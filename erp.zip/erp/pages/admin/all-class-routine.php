
<?php include "../../layouts/admin-page-layouts/header.php";?>
<body>
<?php include "../../layouts/admin-page-layouts/sidebar.php";?>
  <!-- Main content -->
  <div class="main-content" id="panel">
  <?php include "../../layouts/admin-page-layouts/navigation-bar.php";?>
    <div class="header bg-default pb-6">
      <div class="container-fluid">
        <div class="header-body">
          <div class="row align-items-center py-4">
            <div class="col-lg-6 col-7">
              <h6 class="h2 text-white d-inline-block mb-0">All Class Routine</h6>
            </div>

          </div>

        </div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--6">
<div class="card">
      <div class="row">
      <div class="col-xl-12">
          <div class="card">
            <div class="card-header border-0">
              <div class="row align-items-center">
                <div class="col">
                  <h3 class="mb-0">Class Routine</h3>
                </div>
                <div class="col text-right">
                  <a href="#!" class="btn btn-sm btn-success">Reset</a>
                </div>
              </div>
            </div>
          </div>
      </div>
      </div>

      <div class="row" style="margin:0 5px;">

        <div class="col-xl-3" style="margin:0px;">
        <div class="form-group">

              <div class="input-group input-group-merge input-group-alternative">

                <select name="class" class="form-control" id="exampleFormControlSelect1">
                <option>Please Select Class</option>

              <?php $classes->ShowClasses();?>
              </select>
              </div>
            </div>
        </div>
        <div class="col-xl-3">
        <div class="form-group" style="margin:0px;">

              <div class="input-group input-group-merge input-group-alternative">

                <input class="form-control btn btn-default"  value="Reset" type="submit">
              </div>
            </div>
        </div>


        </div>

<div class="table-responsive">
  <div>
      <table class="table align-items-center">
          <thead class="thead-light">
              <tr>



                  <th scope="col" class="sort" data-sort="budget"><b>Subject</b></th>
                  <th scope="col" class="sort" data-sort="status"><b>Class</b></th>
                    <th scope="col" class="sort" data-sort="status"><b>Section</b></th>
                      <th scope="col" class="sort" data-sort="status"><b>Instructor</b></th>
                  <th scope="col" class="sort" data-sort="status"><b>Time</b></th>
                    <th scope="col" class="sort" data-sort="status"><b>Date</b></th>

                  <th scope="col" class="sort" data-sort="name"><b>Options</b></th>

              </tr>
          </thead>
          <tbody class="list" id="class_response_div">
          <?php
$classes->ShowClassRoutine();
           ?>
            </tbody>
          </table>
        </div>

</div>















</div>

    </div>

</div>

<div class="col-md-4">
      <div class="modal fade" id="classeditmodal-form" tabindex="-1" role="dialog" aria-labelledby="modal-form" aria-hidden="true">
    <div id="editshowdiv" class="modal-dialog modal- modal-dialog-centered modal-md" role="document">

</div>

  </div>
</div>


      <?php  include "../../layouts/admin-page-layouts/footer.php";?>

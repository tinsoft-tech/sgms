
<?php include "../../layouts/admin-page-layouts/header.php";?>
<body>
<?php include "../../layouts/admin-page-layouts/sidebar.php";?>
  <!-- Main content -->
  <div class="main-content" id="panel">
  <?php include "../../layouts/admin-page-layouts/navigation-bar.php";?>
    <div class="header bg-default pb-6">
      <div class="container-fluid">
        <div class="header-body">
          <div class="row align-items-center py-4">
            <div class="col-lg-6 col-7">
              <h6 class="h2 text-white d-inline-block mb-0">Add New Class Routine</h6>
            </div>

          </div>

        </div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--6">
        <form id="class-form" method="post" enctype="multipart/form-data">
<div class="card">
      <div class="row">
      <div class="col-xl-12">
          <div class="card">
            <div class="card-header border-0">
              <div class="row align-items-center">
                <div class="col">
                  <h3 class="mb-0">New Routine</h3>
                </div>
                <div class="col text-right">
                  <button type="submit" class="btn btn-md btn-success">Submit</button>
                </div>
              </div>
            </div>
          </div>
      </div>
      </div>


      <div class="row" style="margin:0 5px;">

        <div class="col-xl-6">
          <div style="margin-bottom:5px;"><label>Class Name</label></div>
        <div class="form-group" style="margin:0px;">

              <div class="input-group input-group-merge input-group-alternative">

                <select class="form-control" name="class_name" id="exampleFormControlSelect1">
                <option>Please Select Class</option>
                <?php  $classes->ShowClasses();?>
              </select>
              </div>
            </div>
        </div>
        <div class="col-xl-6" style="margin:0px;">
        <div style="margin-bottom:5px;"><label>Time of Class</label></div>
        <div class="form-group">

              <div class="input-group input-group-merge input-group-alternative">

                <input class="form-control" name="from"  placeholder="From 12.00 pm to 2.00pm" type="time">
                  <input class="form-control"  name="to" placeholder="From 12.00 pm to 2.00pm" type="time">
              </div>
            </div>
        </div>





      </div>




        <div class="row" style="margin:0 5px;">

          <div class="col-xl-6">
            <div style="margin-bottom:5px;"><label>Subject</label></div>
          <div class="form-group" style="margin:0px;">

                <div class="input-group input-group-merge input-group-alternative">

                <select class="form-control" name="subject" id="exampleFormControlSelect1">
                <option>Please Select Subject</option>
                <?php $subject->ShowFullSubjects(); ?>
              </select>
                </div>
              </div>
          </div>
          <div class="col-xl-6">
            <div style="margin-bottom:5px;"><label>Subject Instructor</label></div>
          <div class="form-group" style="margin:0px;">

                <div class="input-group input-group-merge input-group-alternative">

                <select class="form-control" name="instructor" id="exampleFormControlSelect1">
                <option>Please Select Instructor</option>
                <?php $instructor->ShowFullProfile();?>
              </select>
                </div>
              </div>
          </div>




          </div>
<br/>
          <div class="row" style="margin:0 5px;">
            <div class="col-xl-6">
              <div style="margin-bottom:5px;"><label>Section</label></div>
            <div class="form-group" style="margin:0px;">

                  <div class="input-group input-group-merge input-group-alternative">

                  <select class="form-control" name="section" id="exampleFormControlSelect1">
                  <option>Please Select Section</option>
                  <option value="A">A</option>
                  <option value="B">B</option>
                  <option value="C">C</option>
                  <option value="D">D</option>
                  <option value="E">E</option>
                </select>
                  </div>
                </div>
            </div>

            <div class="col-xl-6">
              <div style="margin-bottom:5px;"><label>Date</label></div>
            <div class="form-group" style="margin:0px;">

                  <div class="input-group input-group-merge input-group-alternative">

                  <input class="form-control" name="date"  placeholder="From 12.00 pm to 2.00pm" type="date">
                  </div>
                </div>
            </div>




            </div>

<br/>
<br/>
























</div>
</form>

<div class="row"  style="margin:0 5px 5px 0;">
<div id="class_response_div" class="col-xl-12" style="height:100px;">

</div>
</div>

    </div>

</div>



      <?php  include "../../layouts/admin-page-layouts/footer.php";?>

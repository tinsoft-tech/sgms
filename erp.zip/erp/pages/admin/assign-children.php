
<?php include "../../layouts/admin-page-layouts/header.php";?>
<body>
<?php include "../../layouts/admin-page-layouts/sidebar.php";?>
  <!-- Main content -->
  <div class="main-content" id="panel">
  <?php include "../../layouts/admin-page-layouts/navigation-bar.php";?>
    <div class="header bg-default pb-6">
      <div class="container-fluid">
        <div class="header-body">
          <div class="row align-items-center py-4">
            <div class="col-lg-6 col-7">
              <h6 class="h2 text-white d-inline-block mb-0">Assign Children</h6>
            </div>

          </div>

        </div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--6">
<div class="card">
      <div class="row">
      <div class="col-xl-12">
          <div class="card">
            <div class="card-header border-0">
              <div class="row align-items-center">
                <div class="col">
                  <h3 class="mb-0">Parent</h3>
                </div>
                <div class="col text-right">
                  <a href="#!" class="btn btn-sm btn-success">Reset</a>
                </div>
              </div>
            </div>
          </div>
      </div>
      </div>



<form>
  <div class="row" style="margin:0 5px;">

    <div class="col-xl-4">
      <div style="margin-bottom:5px;"><label>Parent Email</label></div>
    <div class="form-group" style="margin:0px;">

          <div class="input-group input-group-merge input-group-alternative">

            <input class="form-control" name="email"  placeholder="Enter Email" type="text">
          </div>
        </div>
    </div>
    <div class="col-xl-4" style="margin:0px;">
    <div style="margin-bottom:5px;"><label>Admission id</label></div>
    <div class="form-group">

          <div class="input-group input-group-merge input-group-alternative">

            <input class="form-control" name="admission_id"  placeholder="Enter Admission_id" type="text">
          </div>
        </div>
    </div>
  <div class="col-xl-4" style="margin:0px;">
    <div style="margin-bottom:15px;"><label></label></div>
  <button type="submit" class="btn btn-md btn-success">Submit</button>
  </div>




  </div>


</form>














</div>

    </div>

</div>



      <?php  include "../../layouts/admin-page-layouts/footer.php";?>

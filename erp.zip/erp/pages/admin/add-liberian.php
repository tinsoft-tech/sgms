
<?php include "../../layouts/admin-page-layouts/header.php";?>
<body>
<?php include "../../layouts/admin-page-layouts/sidebar.php";?>
  <!-- Main content -->
  <div class="main-content" id="panel">
  <?php include "../../layouts/admin-page-layouts/navigation-bar.php";?>
    <div class="header bg-default pb-6">
      <div class="container-fluid">
        <div class="header-body">
          <div class="row align-items-center py-4">
            <div class="col-lg-6 col-7">
              <h6 class="h2 text-white d-inline-block mb-0">Add New Liberian</h6>
            </div>

          </div>

        </div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--6">
<div class="card">
    <form id="liberian-form" method="post" enctype="multipart/form-data">
      <div class="row">
      <div class="col-xl-12">
          <div class="card">
            <div class="card-header border-0">
              <div class="row align-items-center">
                <div class="col">
                  <h3 class="mb-0">New Liberian</h3>
                </div>
                <div class="col text-right">
                  <a href="#!" class="btn btn-sm btn-success">Reset</a>
                </div>
              </div>
            </div>
          </div>
      </div>
      </div>


      <div class="row" style="margin:0 5px;">

        <div class="col-xl-4">
          <div style="margin-bottom:5px;"><label>First Name</label></div>
        <div class="form-group" style="margin:0px;">

              <div class="input-group input-group-merge input-group-alternative">

                <input class="form-control" name="firstname"  placeholder="Enter Firstname" type="text">
              </div>
            </div>
        </div>
        <div class="col-xl-4" style="margin:0px;">
        <div style="margin-bottom:5px;"><label>Middle Name</label></div>
        <div class="form-group">

              <div class="input-group input-group-merge input-group-alternative">

                <input class="form-control" name="middlename"  placeholder="Enter Middlename" type="text">
              </div>
            </div>
        </div>

        <div class="col-xl-4">
        <div style="margin-bottom:5px;"><label>Last Name</label></div>
        <div class="form-group" style="margin:0px;">

              <div class="input-group input-group-merge input-group-alternative">

                <input class="form-control" name="lastname" placeholder="Enter Lastname" type="text">
              </div>
            </div>
        </div>



      </div>




        <div class="row" style="margin:0 5px;">


          <div class="col-xl-4" style="margin:0px;">
          <div style="margin-bottom:5px;"><label>Employment ID</label></div>
          <div class="form-group">

                <div class="input-group input-group-merge input-group-alternative">
                <input class="form-control" name="employment_id"  placeholder="Enter Admission ID" type="text">

                </div>
              </div>
          </div>

          <div class="col-xl-4">
          <div style="margin-bottom:5px;"><label>Phone</label></div>
          <div class="form-group" style="margin:0px;">

                <div class="input-group input-group-merge input-group-alternative">

                  <input class="form-control" name="phone" placeholder="Enter Phone" type="phone">
                </div>
          </div>
          </div>
          <div class="col-xl-4">
            <div style="margin-bottom:5px;"><label>Address</label></div>
          <div class="form-group" style="margin:0px;">

                <div class="input-group input-group-merge input-group-alternative">

                  <input class="form-control" name="address" placeholder="Enter Address" type="text">
                </div>
              </div>
          </div>


          </div>



            <div class="row" style="margin:0 5px;">

              <div class="col-xl-4">
                <div style="margin-bottom:5px;"><label>Blood Group</label></div>
              <div class="form-group" style="margin:0px;">

                    <div class="input-group input-group-merge input-group-alternative">

                    <select class="form-control" name="bloodgroup" id="exampleFormControlSelect1">
                    <option>Please Select Bloodgroup</option>
                    <option value="A+">A+</option>
                    <option value="A-">A-</option>
                    <option value="B+">B+</option>
                    <option value="B-">B-</option>
                    <option value="O+">O+</option>
                    <option value="O-">O-</option>
                  </select>
                    </div>
                  </div>
              </div>
              <div class="col-xl-4" style="margin:0px;">
              <div style="margin-bottom:5px;"><label>Religion</label></div>
              <div class="form-group">

                    <div class="input-group input-group-merge input-group-alternative">

                    <select class="form-control" name="religion" id="exampleFormControlSelect1">
                    <option>Please Select a Religion</option>
                    <option value="Christian">Christian</option>
                    <option value="Islam">Islam</option>
                    <option value="Hindu">Hindu</option>
                    <option value="Buddish">Buddish</option>
                    <option value="Others">Others</option>

                  </select>
                    </div>
                  </div>
              </div>

              <div class="col-xl-4">
              <div style="margin-bottom:5px;"><label>Email</label></div>
              <div class="form-group" style="margin:0px;">

                    <div class="input-group input-group-merge input-group-alternative">

                      <input class="form-control" name="email" placeholder="Enter Email" type="email">
                    </div>
                  </div>
              </div>



              </div>



                          <div class="row" style="margin:0 5px;">


                            <div class="col-xl-4" style="margin:0px;">
                            <div style="margin-bottom:5px;"><label>Gender</label></div>
                            <div class="form-group">

                                  <div class="input-group input-group-merge input-group-alternative">

                                  <select class="form-control" name="gender" id="exampleFormControlSelect1">
                                  <option>Please Select Gender</option>
                                  <option value="Male">Male</option>
                                  <option value="Female">Female</option>


                                </select>
                                  </div>
                                </div>
                            </div>

                            <div class="col-xl-4">
                              <div style="margin-bottom:5px;"><label>Passport</label></div>
                              <div class="form-group">

                                    <div class="input-group input-group-merge input-group-alternative">
                                    <input class="form-control" name="image" placeholder="Enter Email" type="file">

                                    </div>
                                  </div>
                            </div>

                            <div class="col-xl-4" style="margin:0px;">

                                <div class="form-group">

<br/>
                                      <div class="input-group input-group-merge input-group-alternative">
                                      <input class="form-control btn btn-success"  placeholder="Enter Email" type="submit">

                                      </div>
                                    </div>

                            </div>


                            </div>











            <div class="row"  style="margin:0 5px 5px 0;">
            <div id="lib_response_div" class="col-xl-12" style="height:100px;">

            </div>
            </div>








</form>


</div>

    </div>

</div>



      <?php  include "../../layouts/admin-page-layouts/footer.php";?>

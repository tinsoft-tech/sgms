
<?php include "../../layouts/admin-page-layouts/header.php";?>
<body>
<?php include "../../layouts/admin-page-layouts/sidebar.php";?>
  <!-- Main content -->
  <div class="main-content" id="panel">
  <?php include "../../layouts/admin-page-layouts/navigation-bar.php";?>
    <div class="header bg-default pb-6">
      <div class="container-fluid">
        <div class="header-body">
          <div class="row align-items-center py-4">
            <div class="col-lg-6 col-7">
              <h6 class="h2 text-white d-inline-block mb-0">Add New Subject</h6>
            </div>

          </div>

        </div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--6">
        <form id="subject-form" method="post" enctype="multipart/form-data">
<div class="card">
      <div class="row">
      <div class="col-xl-12">
          <div class="card">
            <div class="card-header border-0">
              <div class="row align-items-center">
                <div class="col">
                  <h3 class="mb-0">New Subject</h3>
                </div>
                <div class="col text-right">
                  <button type="submit" class="btn btn-md btn-success">Submit</button>
                </div>
              </div>
            </div>
          </div>
      </div>
      </div>


      <div class="row" style="margin:0 5px;">

        <div class="col-xl-6">
          <div style="margin-bottom:5px;"><label>Subject Name</label></div>
        <div class="form-group" style="margin:0px;">

              <div class="input-group input-group-merge input-group-alternative">

                <input class="form-control" name="subjectname"  placeholder="Enter Firstname" type="text">
              </div>
            </div>
        </div>
        <div class="col-xl-6" style="margin:0px;">
        <div style="margin-bottom:5px;"><label>Subject Code</label></div>
        <div class="form-group">

              <div class="input-group input-group-merge input-group-alternative">

                <input class="form-control" name="subjectlevel"  placeholder="Enter Middlename" type="text">
              </div>
            </div>
        </div>





      </div>




        <div class="row" style="margin:0 5px;">

          <div class="col-xl-6">
            <div style="margin-bottom:5px;"><label>Subject Level</label></div>
          <div class="form-group" style="margin:0px;">

                <div class="input-group input-group-merge input-group-alternative">

                <select class="form-control" id="exampleFormControlSelect1">
                <option>Please Select Level</option>
                <option value="A+">Accountant 1</option>
                <option value="A-">Accountant 2</option>
              </select>
                </div>
              </div>
          </div>
          <div class="col-xl-6">
            <div style="margin-bottom:5px;"><label>Subject Instructor</label></div>
          <div class="form-group" style="margin:0px;">

                <div class="input-group input-group-merge input-group-alternative">

                <select class="form-control" id="exampleFormControlSelect1">
                <option>Please Select Instructor</option>
                <option value="A+">Accountant 1</option>
                <option value="A-">Accountant 2</option>
              </select>
                </div>
              </div>
          </div>




          </div>



<br/>
<br/>

















<div class="row"  style="margin:0 5px 5px 0;">
<div id="subject_response_div" class="col-xl-12" style="height:100px;">

</div>
</div>






</div>
</form>
    </div>

</div>



      <?php  include "../../layouts/admin-page-layouts/footer.php";?>

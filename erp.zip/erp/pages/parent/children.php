<?php include "../../layouts/parent-layouts/header.php";?>

<body>
<?php include "../../layouts/parent-layouts/sidebar.php";?>
  <!-- Main content -->
  <div class="main-content" id="panel">
  <?php include "../../layouts/parent-layouts/navigation-bar.php";?>

 <!-- Page content -->
 <div style="margin-top:20px;" class="container-fluid">
   <div style="background:#172B4D;" class="container-fluid d-flex align-items-center">
     <div class="row" style="padding-top:15px;width:100%;">
       <div class="col-lg-7 col-md-10">
         <h1 class="text-white">Hello <?php  echo $_SESSION["FULLNAME"];?></h1>
         <p class="text-white mt-0 mb-5">Welcome to your children page.</p>
         <a href="#!" class="btn btn-neutral" style="display:none;">Edit profile</a>
       </div>
     </div>
   </div>
   <div class="row">

     <div class="col-xl-12 order-xl-1">
       <div class="card">
         <div class="card-header">
           <div class="row align-items-center">
             <div class="col-9">
               <h3 class="mb-0">Reports </h3>
             </div>
             <div class="col-3 text-right">
<select class="form-control" id="children">
  <?php $parent->ShowParentsStudents($_SESSION["LOGGED_IN_PARENT_ID"]);?>
</select>
             </div>
           </div>
         </div>
         <div class="card-body">
           <div class="table-responsive">
             <table class="table align-items-center table-flush">
               <thead class="thead-light">
                 <tr>
                   <th scope="col" class="sort" data-sort="name"><b>Passport</b></th>
                   <th scope="col" class="sort" data-sort="name"><b>Name</b></th>
                   <th scope="col" class="sort" data-sort="budget"><b>Gender</b></th>
                   <th scope="col" class="sort" data-sort="status"><b>Class</b></th>
                   <th scope="col" class="sort" data-sort="name"><b>Address</b></th>
                   <th scope="col" class="sort" data-sort="name"><b>Phone</b></th>



                 </tr>
               </thead>
                <tbody class="list" id="show-my-children">
          <?php
$parent->ShowMyChildren($_SESSION["LOGGED_IN_PARENT_ID"]);
           ?>
           </tbody>
         </table>
       </div>

         </div>
       </div>
     </div>
   </div>
  </div>


  <?php  include "../../layouts/student-layouts/footer.php";?>

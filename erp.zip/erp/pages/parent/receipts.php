<?php include "../../layouts/parent-layouts/header.php";?>

<body>
<?php include "../../layouts/parent-layouts/sidebar.php";?>
  <!-- Main content -->
  <div class="main-content" id="panel">
  <?php include "../../layouts/parent-layouts/navigation-bar.php";?>

 <!-- Page content -->
 <div style="margin-top:20px;" class="container-fluid">
   <div style="background:#172B4D;" class="container-fluid d-flex align-items-center">
     <div class="row" style="padding-top:15px;width:100%;">
       <div class="col-lg-7 col-md-10">
         <h1 class="text-white">Hello <?php  echo $_SESSION["FULLNAME"];?></h1>
         <p class="text-white mt-0 mb-5">Welcome to your receipts page.</p>
         <a href="#!" class="btn btn-neutral" style="display:none;">Edit profile</a>
       </div>
     </div>
   </div>
   <div class="row">

     <div class="col-xl-12 order-xl-1">
       <div class="card">
         <div class="card-header">
           <div class="row align-items-center">
             <div class="col-9">
               <h3 class="mb-0">Receipts </h3>
             </div>
             <div style="display:none;" class="col-3 text-right">
<select class="form-control" id="children">
  <?php $parent->ShowParentsStudents($_SESSION["LOGGED_IN_PARENT_ID"]);?>
</select>
             </div>
           </div>
         </div>
         <div class="card-body">
           <div class="table-responsive">
             <table class="table align-items-center table-flush">
               <thead class="thead-light">
                 <tr>
                   <th scope="col">Reference No</th>
                   <th scope="col">Invoice No</th>
                   <th scope="col">Invoice Type</th>
                   <th scope="col">Amount</th>
                   <th scope="col" class="sort" data-sort="name">Session</th>
                  <th scope="col" class="sort" data-sort="name">Term</th>
                   <th scope="col">Date paid</th>


                 </tr>
               </thead>
                <tbody class="list" id="show-my-receipts">
          <?php
$parent->ShowMyChildrenReceipts($_SESSION["LOGGED_IN_PARENT_ID"]);
           ?>
           </tbody>
         </table>
       </div>

         </div>
       </div>
     </div>
   </div>
  </div>


  <div class="col-md-4">
          <div class="modal fade" id="modal-form" tabindex="-1" role="dialog" aria-labelledby="modal-form" aria-hidden="true">
      <div class="modal-dialog modal- modal-dialog-centered modal-sm" role="document">
          <div class="modal-content">

              <div class="modal-body p-0">

  <div class="card bg-secondary border-0 mb-0">
      <div class="card-body px-lg-5 py-lg-5">
          <div class="text-center text-muted mb-4">
              <small>Secure Payment</small>
          </div>
          <form role="form" method="post" action="../../processes/parent/pay.php">
              <div class="form-group mb-3">
                  <div class="input-group input-group-merge input-group-alternative">
                      <div class="input-group-prepend">
                          <span class="input-group-text"><i class="ni ni-email-83"></i></span>
                      </div>
                      <input class="form-control" name="email" id="email" placeholder="Email" type="email">
                  </div>
              </div>
              <div class="form-group">
                  <div class="input-group input-group-merge input-group-alternative">
                      <div class="input-group-prepend">
                          <span class="input-group-text"><i class="ni ni-lock-circle-open"></i></span>
                      </div>
                      <input class="form-control" name="amount" id="amount" placeholder="amount" type="text">
                      <input class="form-control" name="id" id="id" placeholder="amount" type="hidden">
                  </div>
              </div>
              <div class="form-group">
                  <div class="input-group input-group-merge input-group-alternative">
                      <div class="input-group-prepend">
                          <span class="input-group-text"><i class="ni ni-lock-circle-open"></i></span>
                      </div>
                      <input class="form-control" id="type" placeholder="type" type="text">
                  </div>
              </div>
              <div class="text-center">
                  <button type="submit" class="btn btn-primary my-4">Pay now</button>
              </div>
          </form>
      </div>
  </div>




              </div>

          </div>
      </div>
  </div>

    </div>

  <?php  include "../../layouts/student-layouts/footer.php";?>
  <script>
  $('#show-my-invoices').on('click', '.pay-fee', function() {
    var  process_url = "../../processes/admin/searchclassroutine.php";
    var id = $(this).attr("id");
  var amnt =  $("#amount"+id).html();
  var type =  $("#type"+id).html();
  var email = "<?php echo $_SESSION["LOGGED_IN_PARENT"];?>"
  $("#amount").val(amnt);
  $("#type").val(type);
  $("#email").val(email);
  $("#id").val(id);
  });
  </script>
<script>
  $('#children').change(function() {
    var  process_url = "../../processes/parent/check-my-child-reports.php";
    var selectedChild = $(this). children("option:selected"). val();
    var formData = {'admission_id' :selectedChild};
    $.ajax({

        url: process_url,
        type: "POST",             // Type of request to be send, called as method
        data: formData, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                // To unable request pages to be cached
        beforeSend: function() {
            $("#show-my-invoices").html("<div class='text-primary' role='status'>Loading....</div>");
         },
        success: function (data) {
          setTimeout(function(){
             $("#show-my-invoices").html(data);
          },3000)



        },
        error: function (data) {
          //  console.log('An error occurred.');
            console.log(data);
        },
    });
  });

</script>

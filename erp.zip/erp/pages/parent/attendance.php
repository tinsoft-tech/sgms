<?php include "../../layouts/parent-layouts/header.php";?>

<body>
<?php include "../../layouts/parent-layouts/sidebar.php";?>
  <!-- Main content -->
  <div class="main-content" id="panel">
  <?php include "../../layouts/parent-layouts/navigation-bar.php";?>

 <!-- Page content -->
 <div style="margin-top:20px;" class="container-fluid">
   <div style="background:#172B4D;" class="container-fluid d-flex align-items-center">
     <div class="row" style="padding-top:15px;width:100%;">
       <div class="col-lg-7 col-md-10">
         <h1 class="text-white">Hello <?php  echo $_SESSION["FULLNAME"];?></h1>
         <p class="text-white mt-0 mb-5">Welcome to your attendance page.</p>
         <a href="#!" class="btn btn-neutral" style="display:none;">Edit profile</a>
       </div>
     </div>
   </div>
   <div class="row">

     <div class="col-xl-12 order-xl-1">
       <div class="card">
         <div class="card-header">
           <div class="row align-items-center">
             <div class="col-9">
               <h3 class="mb-0">Attendance </h3>
             </div>
             <div class="col-3 text-right">
<select class="form-control" id="children">
  <?php $parent->ShowParentsStudents($_SESSION["LOGGED_IN_PARENT_ID"]);?>
</select>
             </div>
           </div>
         </div>
         <div class="card-body">
           <div class="table-responsive">
             <table class="table align-items-center table-flush">
               <thead class="thead-light">
                 <tr>
                   <th scope="col" class="sort" data-sort="name">Session</th>

                   <th scope="col" class="sort" data-sort="status">Admission ID</th>
                   <th scope="col">Class</th>
                   <th scope="col">Section</th>
                   <th scope="col">Date</th>
                   <th scope="col" class="sort" data-sort="completion">Status</th>


                 </tr>
               </thead>
                <tbody class="list" id="show-my-attendance">
          <?php
//$attendance->ShowAttendanceByID("ADM/2020/SS/0001");
           ?>
           </tbody>
         </table>
       </div>

         </div>
       </div>
     </div>
   </div>
  </div>


  <?php  include "../../layouts/student-layouts/footer.php";?>
  <script>

$(document).ready(function(){
  var  process_url = "../../processes/parent/check-my-child-attendance.php";
  var selectedChild = $("#children"). children("option:selected"). val();
  var formData = {'admission_id' :selectedChild};
  $.ajax({

      url: process_url,
      type: "POST",             // Type of request to be send, called as method
      data: formData, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
              // To unable request pages to be cached
      beforeSend: function() {
          $("#show-my-attendance").html("<tr><th><center><div class='alert-primary'>Loading....</div></center></th></tr>");
       },
      success: function (data) {
        setTimeout(function(){
           $("#show-my-attendance").html(data);
        },3000)



      },
      error: function (data) {
        //  console.log('An error occurred.');
          console.log(data);
      },
  });
})
  </script>
<script>
  $('#children').change(function() {
    var  process_url = "../../processes/parent/check-my-child-attendance.php";
    var selectedChild = $(this). children("option:selected"). val();
    var formData = {'admission_id' :selectedChild};
    $.ajax({

        url: process_url,
        type: "POST",             // Type of request to be send, called as method
        data: formData, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                // To unable request pages to be cached
        beforeSend: function() {
            $("#show-my-attendance").html("<div class='text-primary' role='status'>Loading....</div>");
         },
        success: function (data) {
          setTimeout(function(){
             $("#show-my-attendance").html(data);
          },3000)



        },
        error: function (data) {
          //  console.log('An error occurred.');
            console.log(data);
        },
    });
  });

</script>

<?php include "../../layouts/liberian-layouts/header.php";?>
<body>
<?php include "../../layouts/liberian-layouts/sidebar.php";?>
  <!-- Main content -->
  <div class="main-content" id="panel">
  <?php include "../../layouts/liberian-layouts/navigation-bar.php";?>

 <!-- Page content -->
 <div style="margin-top:20px;" class="container-fluid">
   <div style="background:#172B4D;" class="container-fluid d-flex align-items-center">
     <div class="row" style="padding-top:15px;width:100%;">
       <div class="col-lg-7 col-md-10">
         <h1 class="text-white">Hello <?php  echo $_SESSION["FULLNAME"];?></h1>
         <p class="text-white mt-0 mb-5">Welcome to the library page.</p>
         <a href="#!" class="btn btn-neutral" style="display:none;">Edit profile</a>
       </div>
     </div>
   </div>
   <div class="row">

     <div class="col-xl-12 order-xl-1">
       <div class="card">
         <div class="card-header">
           <div class="row align-items-center">
             <div class="col-4">
                <input class="form-control"  id="booksearch" placeholder="bookname" type="search">
             </div>
             <div class="col-8 text-right">

<button data-toggle='modal' data-target='#book-modal-form' class="btn btn-md btn-primary">Add New Book</button>
             </div>
           </div>
         </div>
         <div class="card-body">
           <div class="table-responsive">
             <table class="table align-items-center table-flush">
               <thead class="thead-light">
                 <tr>
                   <th scope="col" class="sort" data-sort="name">Book Cover</th>

                   <th scope="col" class="sort" data-sort="status">Author</th>
                   <th scope="col">Category</th>
                   <th scope="col" class="sort" data-sort="completion">Publisher</th>
                   <th scope="col">ISBN</th>
                   <th scope="col">Download</th>
                 </tr>
               </thead>
                <tbody class="list" id="show-book-search">
          <?php
 $liberian->ShowBooks();
           ?>
           </tbody>
         </table>
       </div>

         </div>
       </div>
     </div>
   </div>
  </div>





    <div class="col-md-4">
            <div class="modal fade" id="book-modal-form" tabindex="-1" role="dialog" aria-labelledby="book-modal-form" aria-hidden="true">
        <div class="modal-dialog modal- modal-dialog-centered modal-sm" role="document">
            <div class="modal-content">

                <div class="modal-body p-0">

    <div class="card bg-secondary border-0 mb-0">
        <div class="card-body px-lg-5 py-lg-5">
            <div class="text-center text-muted mb-4">
                <small>Add New Book</small>
            </div>
            <form role="form" id="upload-book-form" method="post" enctype="multipart/form-data">
                <div class="form-group mb-3">
                    <div class="input-group input-group-merge input-group-alternative">

                        <input class="form-control" name="bookname" id="bookname" placeholder="bookname" type="text">
                    </div>
                </div>
                <div class="form-group">
                    <div class="input-group input-group-merge input-group-alternative">

                        <input class="form-control" name="author" id="author" placeholder="author" type="text">

                    </div>
                </div>

                <div class="form-group">
                    <div class="input-group input-group-merge input-group-alternative">

                        <input class="form-control" name="publisher" id="publisher" placeholder="publisher" type="text">

                    </div>
                </div>

                <div class="form-group">
                    <div class="input-group input-group-merge input-group-alternative">

                        <input class="form-control" name="isbn" id="isbn" placeholder="isbn" type="text">

                    </div>
                </div>
                <div class="form-group">
<select name="category" class="form-control">
<option value="Arts">Arts</option>
<option value="Science">Science</option>
<option value="Social Science">Social Science</option>
<option value="Commercial">Commercial</option>
<option value="Documentary">Documentary</option>
<option value="Journal">Journal</option>
<option value="General">General</option>

</select>
                </div>
                <div class="form-group">
                    <div class="input-group input-group-merge input-group-alternative">

                        <input class="form-control" name="file" id="publisher" placeholder="publisher" type="file">

                    </div>
                </div>
                <div class="text-center">
                    <button type="submit" class="btn btn-primary my-4">Upload Book</button>
                </div>
                <div id="response_div"></div>
            </form>
        </div>
    </div>




                </div>

            </div>
        </div>
    </div>

      </div>

      <?php  include "../../layouts/liberian-layouts/footer.php";?>
      <script>
      $('#booksearch').on('keydown', function() {
        var  process_url = "../../processes/liberian/searchbooks.php";
        var fy = $(this).val();
        if(fy.length < 0){
          fy = "all";
        }

        var formData = {'key':fy};
        $.ajax({

            url: process_url,
            type: "POST",             // Type of request to be send, called as method
            data: formData, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                    // To unable request pages to be cached
            beforeSend: function() {

                $("#show-book-search").html("<div class='spinner-border text-primary' role='status'><span class='sr-only'>Loading...</span></div>");
             },
            success: function (data) {
                $("#show-book-search").html("");
             $("#show-book-search").html(data);


            },
            error: function (data) {
              //  console.log('An error occurred.');
                console.log(data);
            },
        });
      });

      </script>
      <script>
      var frm = $('#upload-book-form');

          frm.submit(function (e) {

              e.preventDefault();
              var  process_url = "../../processes/liberian/upload-new-book.php";
              $.ajax({

                  url: process_url,
                  type: "POST",             // Type of request to be send, called as method
                  data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                  contentType: false,
                  dataType: 'json',       // The content type used when sending data to the server.
                  cache: false,
                 // encode: true;           // To unable request pages to be cached
                  processData:false,
                  beforeSend: function() {
                      $("#response_div").html("<div class='alert alert-info' role='alert'>Please wait..........</div>");
                   },
                  success: function (data) {
                    if(data.code == 1){
                    frm.trigger("reset");
                     $("#response_div").html("");
                     $("#response_div").html("<div class='alert alert-success' role='alert'>"+data.message+"</div>");
                     setTimeout(function(){
                        $("#response_div").html("");
                     },3000);
                  }
                  else{
                     $("#response_div").html("");
                     $("#response_div").html("<div class='alert alert-danger' role='alert'>"+data.message+"</div>");
                     setTimeout(function(){
                        $("#response_div").html("");
                     },3000);
                  }


                  },
                  error: function (data) {
                    //  console.log('An error occurred.');
                      console.log(data);
                  },
              });
          });

      </script>
